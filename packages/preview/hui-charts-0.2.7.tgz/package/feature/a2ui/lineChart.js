function getLineDefOpt(iChartOpt) {
  var defOption = {
    padding: [32, 2, 0, 2],
    theme: iChartOpt.theme,
    adaptive: true,
    tooltip: {
      show: true
    },
    yAxis: {
      splitNumber: 4
    },
    xAxis: {
      axisLabel: {
        interval: 'auto'
      }
    }
  };
  var dataLen = Object.keys(iChartOpt.data[0]) || 0;
  if (dataLen < 5) {
    defOption.area = true;
  }
  return defOption;
}
export { getLineDefOpt as default };
