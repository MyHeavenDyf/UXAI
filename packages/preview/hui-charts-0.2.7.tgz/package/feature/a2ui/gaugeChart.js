function getGaugeDefOpt(iChartOpt) {
  var defOption = {
    padding: [20, 0, 10, 1],
    theme: iChartOpt.theme,
    itemStyle: {
      outerGauge: {
        show: false
      }
    },
    adaptive: true
  };
  return defOption;
}
export { getGaugeDefOpt as default };
