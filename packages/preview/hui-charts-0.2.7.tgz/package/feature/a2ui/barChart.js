function getBarDefOpt(iChartOpt) {
  var defOption = {
    padding: [32, 2, 0, 2],
    theme: iChartOpt.theme,
    adaptive: true,
    datazoom: {
      left: 0
    },
    tooltip: {
      show: true
    },
    yAxis: {
      splitNumber: 4
    },
    xAxis: {
      axisLabel: {
        interval: 'auto'
      }
    }
  };
  if (iChartOpt.direction === 'horizontal') {
    defOption.yAxis.axisLabel = {
      alignMaxLabel: 'right'
    };
  }
  return defOption;
}
export { getBarDefOpt as default };
