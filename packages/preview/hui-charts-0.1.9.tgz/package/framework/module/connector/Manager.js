import Connector from './index.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var ConnectorManager = /*#__PURE__*/function () {
  function ConnectorManager(chartInstance, lineData, option) {
    var _this = this;
    // 所有数据
    this.data = {};
    // 所有实例
    this.instances = {};
    // 连接点所有数据
    lineData.forEach(function (line) {
      var startConnector = line.startConnector,
        endConnector = line.endConnector;
      _this.data[startConnector.id] = startConnector;
      _this.data[endConnector.id] = endConnector;
    });
    this.createInstance(option, chartInstance, this.data);
  }

  //创建连接点实例对象
  var _proto = ConnectorManager.prototype;
  _proto.createInstance = function createInstance(option, chartInstance, data) {
    var _option$connector,
      _this2 = this;
    var showConnector = (option == null ? void 0 : (_option$connector = option.connector) == null ? void 0 : _option$connector.show) || false;
    Object.keys(data).forEach(function (key) {
      var item = _this2.data[key];
      if (showConnector) {
        _this2.instances[item.id] = new Connector(item, option, chartInstance, data);
      }
    });
  }

  // exist(connector){
  //     return connector.index > 0;
  // }
  ;
  _proto.getData = function getData() {
    return this.data;
  };
  _proto.getInstances = function getInstances() {
    return this.instances;
  };
  _proto.reCreate = function reCreate(chartInstance, lineData, option) {
    var _this3 = this;
    Object.keys(this.instances).forEach(function (key) {
      var item = _this3.instances[key];
      item.uninstall(key);
    });
    //连接点所有数据
    lineData.forEach(function (line) {
      var startConnector = line.startConnector,
        endConnector = line.endConnector;
      _this3.data[startConnector.id] = startConnector;
      _this3.data[endConnector.id] = endConnector;
    });
    this.createInstance(option, chartInstance, this.data);
  };
  _proto.refresh = function refresh(chartInstance, lineData, option) {
    var _option$connector2,
      _this4 = this;
    var showConnector = (option == null ? void 0 : (_option$connector2 = option.connector) == null ? void 0 : _option$connector2.show) || false;
    if (showConnector) {
      // 旧连接点数据
      var oldData = this.data;
      // 新连接点数据
      var newData = [];
      lineData.forEach(function (line) {
        var startConnector = line.startConnector,
          endConnector = line.endConnector;
        newData[startConnector.id] = startConnector;
        newData[endConnector.id] = endConnector;
      });
      // 更新连接点
      Object.keys(newData).forEach(function (key) {
        // 新增的连接点处理
        if (!oldData[key]) {
          _this4.createInstance(option, chartInstance, newData[key]);
        }
        // 对连接点进行更新处理
        _this4.instances[key] && _this4.instances[key].update(key, newData[key], option);
      });
      // 删除的连接点处理
      Object.keys(this.data).forEach(function (key) {
        if (!newData[key]) {
          _this4.instances[key] && _this4.instances[key].uninstall(key, _this4.instances);
        }
      });
    }
  };
  return ConnectorManager;
}();
export { ConnectorManager as default };
