import AnimationGroup from '../../animation/AnimationGroup.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

function getIcon(isOpen) {
  var iconKey = isOpen ? 'open' : 'close';
  var Icon = {
    open: 'M20,11.25 C20.4142136,11.25 20.75,11.5857864 20.75,12 C20.75,12.3796958 20.4678461,12.693491 20.1017706,12.7431534 L20,12.75 L4,12.75 C3.58578644,12.75 3.25,12.4142136 3.25,12 C3.25,11.6203042 3.53215388,11.306509 3.89822944,11.2568466 L4,11.25 L20,11.25 Z',
    close: 'M12,3.25 C12.3796958,3.25 12.693491,3.53215388 12.7431534,3.89822944 L12.75,4 L12.75,11.25 L20,11.25 C20.4142136,11.25 20.75,11.5857864 20.75,12 C20.75,12.3796958 20.4678461,12.693491 20.1017706,12.7431534 L20,12.75 L12.75,12.75 L12.75,20 C12.75,20.4142136 12.4142136,20.75 12,20.75 C11.6203042,20.75 11.306509,20.4678461 11.2568466,20.1017706 L11.25,20 L11.25,12.75 L4,12.75 C3.58578644,12.75 3.25,12.4142136 3.25,12 C3.25,11.6203042 3.53215388,11.306509 3.89822944,11.2568466 L4,11.25 L11.25,11.25 L11.25,4 C11.25,3.58578644 11.5857864,3.25 12,3.25 Z'
  };
  var expandIcon = "\n        <svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" width=\"16px\" height=\"16px\" viewBox=\"0 0 24 24\" version=\"1.1\">\n            <g stroke-width=\"1\" fill=\"none\" fill-rule=\"evenodd\">\n                <g>\n                    <rect fill=\"#191919\" opacity=\"0\" x=\"0\" y=\"0\" width=\"16\" height=\"16\"></rect>\n                    <path d=\"" + Icon[iconKey] + "\" id=\"\u5F62\u72B6\u7ED3\u5408\" fill=\"#191919\"></path>\n                </g>\n            </g>\n        </svg>";
  return expandIcon;
}
var Expand = /*#__PURE__*/function () {
  function Expand(data, chartInstance) {
    // connector数据
    this.data = void 0;
    // 是否展开
    this.isOpen = true;
    // 图表实例
    this.chartInstance = void 0;
  }
  var _proto = Expand.prototype;
  _proto.render = function render(data, chartInstance) {
    var _this = this;
    this.data = data;
    this.chartInstance = chartInstance;
    var canExpand = this.hasChildren(chartInstance.nodeManager.getData().edges, data.nodeId);
    if (data.port === 'start' && canExpand) {
      this.dom = document.createElement('div');
      this.dom.setAttribute('class', "connector-expand");
      this.dom.innerHTML = getIcon(this.isOpen);
      this.dom.addEventListener("click", function () {
        _this.toggleIcon();
        _this.setAnimation();
      });
    }
    return this.dom;
  }

  // 切换图标
  ;
  _proto.toggleIcon = function toggleIcon() {
    this.isOpen = !this.isOpen;
    this.dom.innerHTML = getIcon(this.isOpen);
  }

  // 执行展开收起动画
  ;
  _proto.setAnimation = function setAnimation() {
    var _this2 = this;
    var _this$chartInstance = this.chartInstance,
      lineManager = _this$chartInstance.lineManager,
      nodeManager = _this$chartInstance.nodeManager;
    var nodesData = nodeManager.getData();
    var edges = nodesData.edges;
    var startNode = nodeManager.getNodeData(this.data.nodeId);
    var animateNodes = [];
    this.findAnimateNodes(this.data.id, edges, animateNodes);
    var group = new AnimationGroup();
    var updateStartConnector = function updateStartConnector(animateLine, params, isOpen) {
      for (var lineId in edges) {
        var line = edges[lineId];
        if (line.start === animateLine.end) {
          line.startConnector.absolute.x = (!isOpen ? animateLine.startConnector.x : line.startConnector.x) + params.left;
          line.startConnector.absolute.y = (!isOpen ? animateLine.startConnector.y : line.startConnector.y) + params.top;
        }
      }
    };
    var _loop = function _loop() {
      var id = animateNodes[index];
      // 需要位移的节点
      var endNode = nodeManager.getNodeData(id);
      var endNodeDom = nodeManager.getDom(id);
      // 以该节点为end的连线
      var endLine = edges.filter(function (obj) {
        return obj.end === id;
      })[0];
      var nodeStart = {
        left: _this2.isOpen ? startNode.x : endNode.x,
        top: _this2.isOpen ? startNode.y : endNode.y,
        opacity: _this2.isOpen || endNode.fold ? 0 : 1
      };
      // 记录该次折叠信息
      _this2.collapseRecord(startNode, endNode, _this2.data);
      // 如果折叠状态不存在，初次操作时为折叠---用于后续设置 透明度 和 样式 ‘pointer-events’
      if (endNode.fold == undefined) endNode.fold = true;
      // actionsId 记录初次操作折叠的节点id
      // 如果操作id与actionsId相同，且isOpen为true，则该节点已展开至记录的起始位置；删除节点状态 fold和actionsId
      if (_this2.isOpen && endNode.actionsId == _this2.data.nodeId) {
        delete endNode.fold;
        delete endNode.actionsId;
      } else if (!endNode.actionsId) {
        endNode.actionsId = _this2.data.nodeId;
      }
      // 根据isOpen使用折叠信息记录的起始位置
      var nodeEnd = {
        left: _this2.isOpen ? endNode.actions[_this2.data.nodeId].start.x : endNode.actions[_this2.data.nodeId].end.x,
        top: _this2.isOpen ? endNode.actions[_this2.data.nodeId].start.y : endNode.actions[_this2.data.nodeId].end.y,
        opacity: _this2.isOpen && !endNode.actions[_this2.data.nodeId].fold && !endNode.fold ? 1 : 0
      };
      group.add(endNodeDom, {
        start: nodeStart,
        end: nodeEnd,
        duration: lineManager.RE_CREATE_TIME,
        onAfterUpdate: function onAfterUpdate(params, elapsed, element) {
          var animateLine = Object.assign({}, endLine);
          animateLine.endConnector.absolute.x = animateLine.endConnector.x + params.left;
          animateLine.endConnector.absolute.y = animateLine.endConnector.y + params.top;
          updateStartConnector(animateLine, params, _this2.isOpen);
          lineManager.update(animateLine);
        },
        onFinish: function onFinish() {
          var _endNode$actions$_thi;
          endNode.x = nodeEnd.left;
          endNode.y = nodeEnd.top;
          !_this2.isOpen && lineManager.hide(endLine);
          if (endNodeDom) endNodeDom.style['pointer-events'] = _this2.isOpen ? 'auto' : 'none';
          if (_this2.isOpen && !((_endNode$actions$_thi = endNode.actions[_this2.data.nodeId]) != null && _endNode$actions$_thi.fold) && endNode.fold && endNodeDom) endNodeDom.style['pointer-events'] = 'none';
          //折叠完成，删除该次折叠信息
          if (_this2.isOpen) delete endNode.actions[_this2.data.nodeId];
        }
      });
    };
    for (var index = 0; index < animateNodes.length; index++) {
      _loop();
    }
    group.start();
  }

  // 查找所有需要展开收起的节点的id集合
  ;
  _proto.findAnimateNodes = function findAnimateNodes(id, edges, animateNodes, endId) {
    var _this3 = this;
    edges.forEach(function (item) {
      var splitID = item.id.split("-to-");
      if (item.start == endId || splitID[0] == id) {
        animateNodes.push(item.end);
        _this3.findAnimateNodes(splitID[1], edges, animateNodes, item.end);
      }
    });
  }

  //递归查找子节点
  ;
  _proto.childId = function childId(id, edgeData, childIdArr) {
    var _this4 = this;
    edgeData.forEach(function (item) {
      if (item.start == id) {
        childIdArr.push(item.end);
        _this4.childId(item.end, edgeData, childIdArr);
      }
    });
  }

  // 查询节点是否存在子节点
  ;
  _proto.hasChildren = function hasChildren(edgeData, id) {
    var childIdArr = [];
    // 获取所有节点id下面的子节点,放到childIdArr
    this.childId(id, edgeData, childIdArr);
    // 去除相同的节点
    childIdArr = [].concat(new Set(childIdArr));
    if (childIdArr.length > 0) {
      var singleNum = 0; // 只有一个父节点的数量
      childIdArr.forEach(function (child) {
        var num = 0;
        for (var k = 0; k < edgeData.length; k++) {
          if (edgeData[k].end === child) {
            num++;
          }
          // 子节点的父节点数量大于1，则终止循环
          if (num > 1) {
            break;
          }
          if (k == edgeData.length - 1) {
            singleNum++;
          }
        }
      });
      // 如果所有的子节点的父节点都是唯一的
      if (singleNum == childIdArr.length) {
        return true;
      } else {
        return false;
      }
    }
  }

  // 记录折叠信息，折叠操作的id，起始坐标, 节点对于该操作记录的折叠状态
  ;
  _proto.collapseRecord = function collapseRecord(startNode, endNode, data) {
    if (!endNode.actions) endNode.actions = {};
    if (!endNode.actions[data.nodeId]) {
      endNode.actions[data.nodeId] = {
        fold: true,
        start: {
          x: endNode.x,
          y: endNode.y
        },
        end: {
          x: startNode.x,
          y: startNode.y
        }
      };
    } else {
      endNode.actions[data.nodeId].fold = false;
    }
  };
  return Expand;
}();
export { Expand as default };
