import merge from '../../../util/merge.js';
import { isObject } from '../../../util/type.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

var SVG_TYPE = {
  DOT: 'dot',
  MESH: 'mesh',
  DOUBLE_MESH: 'doubleMesh'
};
var Grid = /*#__PURE__*/function () {
  function Grid(container, option) {
    // 画布容器
    this.container = null;
    // 默认样式配置
    this.defaultOption = {
      type: SVG_TYPE.DOT,
      show: false,
      size: 30,
      config: {
        color: '#aaaaaa',
        unitSize: 1
      }
    };
    // 双线网格默认配置
    this.doubleMeshDefaultConfig = [{
      color: '#eee',
      // 主网格线颜色
      unitSize: 1 // 主网格线宽度
    }, {
      color: '#ddd',
      // 次网格线颜色
      unitSize: 1,
      // 次网格线宽度
      factor: 4 // 主次网格线间隔
    }];
    if (option && isObject(option)) {
      //配置doubleMesh默认值
      if ((option == null ? void 0 : option.type) === SVG_TYPE.DOUBLE_MESH) this.defaultOption.config = this.doubleMeshDefaultConfig;
      merge(this.defaultOption, option);
    }
    this.container = container;
    this.bgCanvas = document.createElement('canvas');
    this.bgCanvas.setAttribute('class', 'huicharts-canvas-bg');
    this.bgCanvas.width = this.container.offsetWidth;
    this.bgCanvas.height = this.container.offsetHeight;
    this.bgCanvasCtx = this.bgCanvas.getContext('2d');
    this.container.appendChild(this.bgCanvas);
    this.draw({
      scale: 1,
      offset: {
        x: 0,
        y: 0
      }
    });
  }

  // 绘制网格
  var _proto = Grid.prototype;
  _proto.draw = function draw(option) {
    var _this$defaultOption, _this$defaultOption2;
    var scale = option.scale;
    var offset = option.offset;
    //画布清空
    this.bgCanvasCtx.clearRect(0, 0, this.bgCanvas.width, this.bgCanvas.height);
    //保存初始状态
    this.bgCanvasCtx.save();
    //画布原点进行偏移
    //间隔
    var step = this.defaultOption.size;
    this.scale = scale;
    //视口放缩后的宽高
    var viewportWidth = this.bgCanvas.width / scale;
    var viewportHeight = this.bgCanvas.height / scale;
    this.bgCanvasCtx.translate(offset.x + this.bgCanvas.width / 2, offset.y + this.bgCanvas.height / 2);
    //画布放缩
    this.bgCanvasCtx.scale(scale, scale);
    //刻度线的起始位置

    //小于或等于的整数
    var startX = Math.floor(-offset.x / scale / step) * step - viewportWidth / 2;
    var startY = Math.floor(-offset.y / scale / step) * step - viewportHeight / 2;
    var endX = startX + viewportWidth + step;
    var endY = startY + viewportHeight + step;
    var drawOption = {
      startX: startX,
      endX: endX,
      startY: startY,
      endY: endY,
      step: step
    };
    if (((_this$defaultOption = this.defaultOption) == null ? void 0 : _this$defaultOption.type) === SVG_TYPE.MESH) {
      // 绘制网格
      this.drawMesh(drawOption);
    } else if (((_this$defaultOption2 = this.defaultOption) == null ? void 0 : _this$defaultOption2.type) === SVG_TYPE.DOT) {
      // 绘制点
      this.drawDOT(drawOption);
    } else {
      // 绘制双层网格
      this.drawDoubleMesh(drawOption);
    }
  }

  // 绘制点背景
  ;
  _proto.drawDOT = function drawDOT(option) {
    var startX = option.startX,
      endX = option.endX,
      startY = option.startY,
      endY = option.endY,
      step = option.step;
    // 绘制底图
    var size = (this.defaultOption.config.unitSize || 1) * this.scale; // 点的大小
    this.bgCanvasCtx.fillStyle = this.defaultOption.config.color;
    this.bgCanvasCtx.beginPath();
    for (var x = 0; x > startX; x -= step) {
      for (var y = 0; y > startY; y -= step) {
        this.drawPoint(x, y, size);
      }
      for (var _y = 0; _y <= endY; _y += step) {
        this.drawPoint(x, _y, size);
      }
    }
    for (var _x = step; _x <= endX; _x += step) {
      for (var _y2 = 0; _y2 > startY; _y2 -= step) {
        this.drawPoint(_x, _y2, size);
      }
      for (var _y3 = 0; _y3 <= endY; _y3 += step) {
        this.drawPoint(_x, _y3, size);
      }
    }
    this.bgCanvasCtx.fill();
    this.bgCanvasCtx.restore();
  }

  // 绘制点
  ;
  _proto.drawPoint = function drawPoint(x, y, size) {
    this.bgCanvasCtx.moveTo(x, y);
    // 缩放值小于0.9时，使用rect渲染，减少性能消耗
    if (this.scale < 0.9) {
      this.bgCanvasCtx.rect(x - size, y - size, size * 2, size * 2);
    } else {
      this.bgCanvasCtx.arc(x, y, size, 0, Math.PI * 2);
    }
  }

  // 绘制网格背景
  ;
  _proto.drawMesh = function drawMesh(option) {
    var startX = option.startX,
      endX = option.endX,
      startY = option.startY,
      endY = option.endY,
      step = option.step;
    this.bgCanvasCtx.strokeStyle = this.defaultOption.config.color;
    this.bgCanvasCtx.lineWidth = (this.defaultOption.config.unitSize || 1) * this.scale;
    this.bgCanvasCtx.beginPath();
    for (var x = 0; x > startX; x -= step) {
      this.bgCanvasCtx.moveTo(x, startY);
      this.bgCanvasCtx.lineTo(x, endY);
    }
    for (var _x2 = step; _x2 <= endX; _x2 += step) {
      this.bgCanvasCtx.moveTo(_x2, startY);
      this.bgCanvasCtx.lineTo(_x2, endY);
    }
    for (var y = 0; y > startY; y -= step) {
      this.bgCanvasCtx.moveTo(startX, y);
      this.bgCanvasCtx.lineTo(endX, y);
    }
    for (var _y4 = 0; _y4 <= endY; _y4 += step) {
      this.bgCanvasCtx.moveTo(startX, _y4);
      this.bgCanvasCtx.lineTo(endX, _y4);
    }
    this.bgCanvasCtx.stroke();
    this.bgCanvasCtx.restore();
  }

  // 绘制双层网格背景
  ;
  _proto.drawDoubleMesh = function drawDoubleMesh(option) {
    var _this$defaultOption$c, _this$defaultOption$c2, _this$defaultOption$c3, _this$defaultOption$c4, _this$defaultOption$c5;
    var startX = option.startX,
      endX = option.endX,
      startY = option.startY,
      endY = option.endY,
      step = option.step;
    // 绘制第一层网格
    this.bgCanvasCtx.strokeStyle = (_this$defaultOption$c = this.defaultOption.config[0]) == null ? void 0 : _this$defaultOption$c.color;
    this.bgCanvasCtx.lineWidth = ((_this$defaultOption$c2 = this.defaultOption.config[0]) == null ? void 0 : _this$defaultOption$c2.unitSize) * this.scale;
    var secondGridSize = step * (((_this$defaultOption$c3 = this.defaultOption.config[1]) == null ? void 0 : _this$defaultOption$c3.factor) || 4);
    this.bgCanvasCtx.beginPath();
    for (var x = 0; x > startX; x -= step) {
      this.bgCanvasCtx.moveTo(x, startY);
      this.bgCanvasCtx.lineTo(x, endY);
    }
    for (var _x3 = step; _x3 <= endX; _x3 += step) {
      this.bgCanvasCtx.moveTo(_x3, startY);
      this.bgCanvasCtx.lineTo(_x3, endY);
    }
    for (var y = 0; y > startY; y -= step) {
      this.bgCanvasCtx.moveTo(startX, y);
      this.bgCanvasCtx.lineTo(endX, y);
    }
    for (var _y5 = 0; _y5 <= endY; _y5 += step) {
      this.bgCanvasCtx.moveTo(startX, _y5);
      this.bgCanvasCtx.lineTo(endX, _y5);
    }
    this.bgCanvasCtx.stroke();
    // 绘制第二层网格
    this.bgCanvasCtx.beginPath();
    this.bgCanvasCtx.strokeStyle = (_this$defaultOption$c4 = this.defaultOption.config[1]) == null ? void 0 : _this$defaultOption$c4.color;
    this.bgCanvasCtx.lineWidth = ((_this$defaultOption$c5 = this.defaultOption.config[1]) == null ? void 0 : _this$defaultOption$c5.unitSize) * this.scale;
    for (var _x4 = 0; _x4 > startX; _x4 -= secondGridSize) {
      this.bgCanvasCtx.moveTo(_x4, startY);
      this.bgCanvasCtx.lineTo(_x4, endY);
    }
    for (var _x5 = 0; _x5 <= endX; _x5 += secondGridSize) {
      this.bgCanvasCtx.moveTo(_x5, startY);
      this.bgCanvasCtx.lineTo(_x5, endY);
    }
    for (var _y6 = 0; _y6 > startY; _y6 -= secondGridSize) {
      this.bgCanvasCtx.moveTo(startX, _y6);
      this.bgCanvasCtx.lineTo(endX, _y6);
    }
    for (var _y7 = 0; _y7 <= endY; _y7 += secondGridSize) {
      this.bgCanvasCtx.moveTo(startX, _y7);
      this.bgCanvasCtx.lineTo(endX, _y7);
    }
    this.bgCanvasCtx.stroke();
    this.bgCanvasCtx.restore();
  };
  _proto.roundDownGridSize = function roundDownGridSize(num, GridSize) {
    // 判断是否有余数，有余数则取小于当前值的最近值
    if (num % GridSize !== 0) {
      num = Math.floor(num / GridSize) * GridSize;
    }
    return num;
  }

  // 获取网格大小
  ;
  _proto.getSize = function getSize() {
    return this.defaultOption.size;
  }

  // 设置网格大小
  ;
  _proto.setSize = function setSize(size) {
    this.defaultOption.size = size;
  }

  // 显示网格
  ;
  _proto.show = function show() {
    if (this.container) {
      this.draw();
    }
  }

  // 隐藏网格
  ;
  _proto.hide = function hide() {
    if (this.container && this.bgCanvas) {
      this.clear();
    }
  }

  // 清除网格
  ;
  _proto.clear = function clear() {
    if (this.container && this.bgCanvas) {
      this.bgCanvasCtx.clearRect(0, 0, this.bgCanvas.width, this.bgCanvas.height);
    }
  };
  _proto.setGrid = function setGrid(option, scale, offset) {
    if (option && isObject(option)) {
      //配置doubleMesh默认值
      if ((option == null ? void 0 : option.type) === SVG_TYPE.DOUBLE_MESH) this.defaultOption.config = this.doubleMeshDefaultConfig;
      merge(this.defaultOption, option);
    }
    this.draw({
      scale: scale,
      offset: offset
    });
  };
  return Grid;
}();
export { Grid as default };
