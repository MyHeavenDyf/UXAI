var _LineFactory;
import Tag from './Tag.js';
import Round from './type/Round.js';
import Direct from './type/Direct.js';
import Bezier from './type/Bezier.js';
import Circle from './type/Circle.js';
import Ellipse from './type/Ellipse.js';
import Animation from './Animation.js';
import { createDom, attr, addClass } from '../../../util/dom.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

var TYPE_ROUND = 'Round'; // 折线
var TYPE_BEZIER = 'Bezier'; // 贝塞尔曲线
var TYPE_DIRECT = 'Direct'; // 直线
var TYPE_CIRCLE = 'Circle'; // 半圆
var TYPE_ELLIPSE = 'Ellipse'; // 椭圆

var EVENT_CLICK = 'click'; // 点击事件
var EVENT_HOVER = 'hover'; // hover事件
var EVENT_MOUSEENTER = 'mouseenter'; // 鼠标移入事件
var EVENT_MOUSELEAVE = 'mouseleave'; // 鼠标移出事件

var LINE_STATUS_DEFAULT = 'default';
var LINE_STATUS_HOVER = 'hover';
var LINE_STATUS_ACTIVE = 'active';
var LINE_STATUS_DISABLE = 'disable';
var TAG_DEFAULT = {
  background: '#656565',
  color: '#fff',
  radius: '3',
  position: 0.5
};
var LineFactory = (_LineFactory = {}, _LineFactory[TYPE_ROUND] = Round, _LineFactory[TYPE_DIRECT] = Direct, _LineFactory[TYPE_BEZIER] = Bezier, _LineFactory[TYPE_CIRCLE] = Circle, _LineFactory[TYPE_ELLIPSE] = Ellipse, _LineFactory);
var Line = /*#__PURE__*/function () {
  function Line(data, ArrowManager, option) {
    // 标签管理器
    this.TagManager = void 0;
    // 线动效管理器
    this.AnimationManager = {};
    // 连线是否已渲染
    this.hasRender = void 0;
    this.data = data;
    this.lineOption = data.lineOption;
    this.style = data.lineOption.style;
    this.ArrowManager = ArrowManager;
    this.option = option;
    this.hasRender = false;
  }

  // 创建连线dom
  var _proto = Line.prototype;
  _proto.create = function create(d) {
    var _this = this;
    var g = createDom('g');
    var path = createDom('path');
    var id = this.data.id;
    attr(path, 'startNode', this.data.start);
    attr(path, 'endNode', this.data.end);
    attr(path, 'd', d);
    attr(path, 'id', id);
    attr(path, 'stroke', this.style.color);
    addClass(path, 'huicharts-line');
    addClass(g, 'huicharts-line-wrap');
    if (this.style.mode === 'dash') {
      attr(path, 'stroke-dasharray', 5);
    }
    attr(path, 'stroke-width', this.style.width + 'px');
    g.appendChild(path);
    // 线动效需要1s的时间，延时生成箭头(虚线无生长动效，无需延时生成箭头)
    if (this.style.mode === 'dash') {
      this.creatMarker(path);
    } else {
      setTimeout(function () {
        _this.creatMarker(path);
      }, 1000);
    }
    // 创建线的热区，便于hover、click触发
    this.createTriggerPath(path, g);
    // 创建tag标签
    this.createTag(this.data, g);
    return g;
  };
  _proto.createTriggerPath = function createTriggerPath(path, g) {
    var triggerPath = path.cloneNode(true);
    var removeAttr = ['id', 'stroke', 'stroke-width', 'marker-end', 'marker-start'];
    // 循环遍历并删除属性
    removeAttr.forEach(function (attr) {
      triggerPath.removeAttribute(attr);
    });
    addClass(triggerPath, 'huicharts-line-trigger');
    g.appendChild(triggerPath);
  }

  // 创建Tag标签
  ;
  _proto.createTag = function createTag(edge, g) {
    if (!edge.tag) return;
    var defaultStyle = Object.assign({}, this.lineOption.style.tag, edge.tag);
    edge.tag.style = Object.assign({}, TAG_DEFAULT, defaultStyle);
    this.TagManager = new Tag(edge);
    var tagDom = this.TagManager.render();
    g.appendChild(tagDom);
    this.TagManager.setPosition(g, edge);
  }

  // 创建首尾箭头
  ;
  _proto.creatMarker = function creatMarker(path) {
    // 用户配置了startMarker，则给path增加marker-start标签，并使用对应的url
    var startMarker = this.ArrowManager.lineOption.startMarker;
    // 用户配置了endMarker，则给path增加marker-end标签，并使用对应的url
    var endMarker = this.ArrowManager.lineOption.endMarker;
    this.ArrowManager.hasStartMarker && this.ArrowManager.render(path, startMarker, 'start');
    this.ArrowManager.hasEndMarker && this.ArrowManager.render(path, endMarker, 'end');
  }

  // 拼接连线信息
  ;
  _proto.render = function render() {
    var CreatorClass = LineFactory[this.lineOption.type || TYPE_DIRECT];
    this.lineCreator = new CreatorClass(this.data);
    var path = this.lineCreator.creatPath(this.data, this.option);
    // 设置节点为已渲染
    this.hasRender = true;
    this.AnimationManager = new Animation();
    this.path = this.create(path);
    return this.path;
  }

  // 连线绑定事件
  ;
  _proto.bindEvent = function bindEvent(path, event, callback) {
    var linePath = path.firstChild;
    var self = this;
    if (event === EVENT_CLICK) {
      path.addEventListener(EVENT_CLICK, function () {
        if (self.style.active) {
          self.isClick = true;
          self.setActiveStatus(linePath);
        }
        callback && callback(linePath);
      });
    } else if (event === EVENT_HOVER) {
      path.addEventListener(EVENT_MOUSEENTER, function () {
        if (self.style.hover && !self.isClick) {
          self.setHoverStatus(linePath);
        }
        callback && callback(linePath);
      });
      path.addEventListener(EVENT_MOUSELEAVE, function () {
        if (self.style.hover && !self.isClick) {
          self.setDefaultStatus(linePath);
        }
      });
    }
  };
  _proto.setDefaultStatus = function setDefaultStatus(path) {
    this.setStatus(path, LINE_STATUS_DEFAULT);
  };
  _proto.setActiveStatus = function setActiveStatus(path) {
    this.setStatus(path, LINE_STATUS_ACTIVE);
  };
  _proto.setHoverStatus = function setHoverStatus(path) {
    this.setStatus(path, LINE_STATUS_HOVER);
  };
  _proto.setDisableStatus = function setDisableStatus(path) {
    this.setStatus(path, LINE_STATUS_DISABLE);
  }

  // 设定连线到指定状态
  ;
  _proto.setStatus = function setStatus(path, status) {
    if (status === LINE_STATUS_DEFAULT) {
      attr(path, 'stroke', this.style.color);
      attr(path, 'stroke-width', this.style.width + 'px');
    } else {
      this.style[status].color && attr(path, 'stroke', this.style[status].color);
      this.style[status].width && attr(path, 'stroke-width', this.style[status].width + 'px');
    }
    this.ArrowManager.hasStartMarker && this.ArrowManager.setMarker(path, 'start', status);
    this.ArrowManager.hasEndMarker && this.ArrowManager.setMarker(path, 'end', status);
  }

  // 连线动效
  ;
  _proto.animation = function animation(option) {
    option.color && this.ArrowManager.changeMarkerColor(option.path, option.color);
    this.AnimationManager.start(option);
  }

  // 更新连线
  ;
  _proto.update = function update(line) {
    var lineDom = document.getElementById(line.id);
    if (!lineDom) return;
    var dasharray = lineDom.getTotalLength();
    var triggerLine = lineDom.nextSibling;
    var CreatorClass = LineFactory[line.lineOption.type || TYPE_DIRECT];
    this.lineCreator = new CreatorClass(this.data);
    var path = this.lineCreator.creatPath(line, this.option);
    attr(lineDom, 'd', path);
    attr(lineDom, 'stroke-dasharray', dasharray);
    attr(lineDom, 'stroke', line.lineOption.style.color);
    if (line.lineOption.style.mode === 'dash') {
      attr(lineDom, 'stroke-dasharray', 5);
    }
    attr(lineDom, 'stroke-width', line.lineOption.style.width + 'px');
    attr(triggerLine, 'd', path);
    this.updateTransPath(line, path);
    this.updateTag(lineDom, line);
  }

  // 隐藏连线,一般用于折叠后，终点折叠到起点的另一边后，线仍然显示在页面中的问题
  ;
  _proto.hide = function hide(line) {
    var lineDom = document.getElementById(line.id);
    if (!lineDom) return;
    var triggerLine = lineDom.nextSibling;
    attr(lineDom, 'd', '');
    attr(triggerLine, 'd', '');
  }

  // 更新流光的路径
  ;
  _proto.updateTransPath = function updateTransPath(line, path) {
    var transDom = document.getElementById(line.id + "-trans-streamer");
    if (!transDom) return;
    for (var i = 0; i < transDom.children.length; i++) {
      var child = transDom.children[i];
      child.style.offsetPath = "path(\"" + path + "\")";
    }
  }

  // 更新tag标签位置
  ;
  _proto.updateTag = function updateTag(line, lineData) {
    var _this$TagManager;
    var g = line.parentNode;
    (_this$TagManager = this.TagManager) == null ? void 0 : _this$TagManager.setPosition(g, lineData);
  }

  // 删除连线
  ;
  _proto.unmount = function unmount(id) {
    var line = document.getElementById(id);
    if (line) {
      line.parentNode.remove();
      this.AnimationManager.unmount();
    }
  };
  return Line;
}();
export { Line as default };
