import Animate from './Animate.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var Animation = /*#__PURE__*/function () {
  //动画模块

  function Animation(element, options) {
    this.end = false;
    //是否结束
    this.animate = void 0;
    this.end = false;
    options.onUpdate = options.onUpdate || this.onUpdate;
    this.animate = new Animate(options, element);
  }

  // 开始任务
  var _proto = Animation.prototype;
  _proto.start = function start() {
    var _this$animate;
    (_this$animate = this.animate) == null ? void 0 : _this$animate.start();
    this.step();
  }

  // 结束任务
  ;
  _proto.stop = function stop() {
    var _this$animate2;
    (_this$animate2 = this.animate) == null ? void 0 : _this$animate2.stop();
  }

  // 循环
  ;
  _proto.step = function step(time) {
    var _this = this;
    !this.end && requestAnimationFrame(function (timestamp) {
      _this.step(timestamp);
    });
    !this.end && this.update(time, false);
  }

  // 调用动画模块更新
  ;
  _proto.update = function update(time, preserve) {
    var _this$animate3;
    if (time === void 0) {
      time = performance.now();
    }
    this.end = !((_this$animate3 = this.animate) != null && _this$animate3.update(time));
  }

  // 默认更新节点方法
  ;
  _proto.onUpdate = function onUpdate(params, value, element) {
    if (element) {
      var s = element.style;
      s.position = 'absolute';
      var matchUnit = {
        'font-size': 'px',
        'line-height': 'px',
        'rotate': 'deg',
        'width': 'px',
        'height': 'px',
        'left': 'px',
        'top': 'px',
        'bottom': 'px',
        'right': 'px'
      };
      for (var key in params) {
        if (Object.hasOwnProperty.call(params, key)) {
          s[key] = matchUnit[key] ? params[key] + matchUnit[key] : params[key];
        }
      }
    }
  };
  return Animation;
}();
export { Animation as default };
