function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import init from '../../option/init/index.js';
import miniProcess from '../../feature/mini/miniProcessChart.js';
import RectCoordSys from '../../option/RectSys/index.js';
import { CHARTTYPENAME, PROCESSBARTYPE } from './BaseOption.js';
import handleData from './handleData.js';
import { handleGrid, handleYaxis, handleXaxis, handleDataZoom, handleLegend, handleTooltip } from './handleOption.js';
import handleSeries, { setNameSeriesWidth } from './handleSeries.js';
import cloneDeep from '../../util/cloneDeep.js';
import { CHART_TYPE } from '../../util/constants.js';
import { mergeSeries } from '../../util/merge.js';
import setA2ui from '../../feature/a2ui/index.js';
import updateWidth from '../BarChart/barChartOption.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var ProcessChart = /*#__PURE__*/function () {
  function ProcessChart(iChartOption, chartInstance) {
    // 保存初始的iChartOption
    this.initIchartOption = cloneDeep(iChartOption);
    this.baseOption = {};
    this.iChartOption = {};
    this.chartInstance = chartInstance;
    this.chartName = CHART_TYPE.PROCESS;
    this.dom = chartInstance._dom;
    // 组装 iChartOption, 补全默认值
    this.iChartOption = init(iChartOption);
    // 根据 iChartOption 组装 baseOption
    this.updateOption();
  }
  var _proto = ProcessChart.prototype;
  _proto.updateOption = function updateOption() {
    var iChartOption = this.iChartOption;
    if (!iChartOption.name) {
      throw new Error('ProcessChart must have a name');
    }
    // 加载默认的直角坐标系
    RectCoordSys(this.baseOption, iChartOption, iChartOption.name, this.chartInstance);
    // 是否是基础双向进度图
    var doubleSide = iChartOption.name === CHARTTYPENAME.ProcessBarChart && iChartOption.type && iChartOption.type === PROCESSBARTYPE;
    var dataSet = handleData(iChartOption, doubleSide);
    this.dataSet = dataSet;
    if (!dataSet) return;
    handleGrid(this.baseOption, iChartOption, doubleSide, this.chartInstance);
    handleYaxis(this.baseOption, iChartOption, dataSet, doubleSide);
    handleXaxis(this.baseOption, doubleSide, iChartOption);
    // datazoom和legend会在init配置默认值做特殊处理手动用初始值做混合
    handleDataZoom(this.baseOption, this.initIchartOption);
    handleLegend(this.baseOption, dataSet, doubleSide, this.initIchartOption);
    handleSeries(this.baseOption, iChartOption, dataSet, doubleSide, this.chartInstance);
    handleTooltip(this.baseOption, iChartOption, dataSet, doubleSide);
    // 合并用户自定义series
    mergeSeries(iChartOption, this.baseOption);
    // 处理特性
    miniProcess(iChartOption, this.baseOption);
  };
  _proto.getOption = function getOption() {
    return this.baseOption;
  };
  _proto.setOption = function setOption(option) {
    this.baseOption = option;
  }

  // 更新name的宽度
  ;
  _proto.resize = function resize(callback) {
    var nameSeries;
    this.baseOption.series.forEach(function (element) {
      if (element.name === 'seriesName') {
        nameSeries = element;
      }
    });
    if (this.iChartOption.a2ui) {
      setA2ui(this.iChartOption, this);
      updateWidth(this.baseOption, this.chartInstance, _extends({}, this.iChartOption, {
        type: 'contain',
        direction: 'horizontal',
        rawBarwidth: 20
      }));
      miniProcess(this.iChartOption, this.baseOption);
    }
    setNameSeriesWidth(nameSeries, this.dataSet, this.iChartOption, this.chartInstance);
    callback(this.baseOption, {
      notMerge: false
    });
  };
  return ProcessChart;
}();
_defineProperty(ProcessChart, "name", CHART_TYPE.PROCESS);
export { ProcessChart as default };
