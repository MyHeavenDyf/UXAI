function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import { calcColumnX, createSvgElement, setEllipsisWithTooltip, handleEvents, updateSvgs, unbindAllEvents } from './utils.js';
import { showTooltip, hideTooltip } from './handleTooltip.js';
import { getRowStyles, getRankColor } from './style.js';
import { TEXT, ROW } from './constants.js';
import chartToken from './chartToken.js';
var ContentRow = /*#__PURE__*/function () {
  function ContentRow(option) {
    var data = option.data,
      index = option.index,
      rowWidth = option.rowWidth,
      rowHeight = option.rowHeight,
      colorArray = option.colorArray;
    this.data = data;
    this.index = index;
    this.rowWidth = rowWidth;
    this.rowHeight = rowHeight;
    this.colorArray = colorArray;
    this.padding = TEXT.PADDING;
    this.textBaselineY = ROW.TEXTBASELINEY;
    this.rankBgSize = ROW.RANKBGSIZE;
    this.init();
  }
  var _proto = ContentRow.prototype;
  _proto.init = function init() {
    this.styles = getRowStyles(chartToken);
    this.progressBarWidth = this.rowWidth - 2 * this.padding;
    this.progressBarHeight = chartToken.row.progressBarHeight;
    // 计算文本x坐标
    this.columnX = calcColumnX(TEXT.FLEX_SPACE, this.rowWidth, this.padding);
  }

  // 获取进度条颜色
  ;
  _proto.getProgressBarColor = function getProgressBarColor() {
    // 如果data中有颜色，直接使用
    if (this.data.color) {
      return this.data.color;
    }

    // 否则使用colorArray中的颜色
    if (this.colorArray && this.colorArray.length > 0) {
      return this.colorArray[this.index % this.colorArray.length];
    }
  };
  _proto.render = function render() {
    // 创建行容器
    this.row = createSvgElement('g', this.styles.getRowContainer(this.index, this.rowHeight));
    this.renderRowBg(); // 渲染行背景
    this.renderRank(); // 渲染排名
    this.renderName(); // 渲染名称
    this.renderValue(); // 渲染数值
    this.renderPercent(); // 渲染百分比
    this.renderProgressBar(); // 渲染进度条

    return this.row;
  };
  _proto.renderRowBg = function renderRowBg() {
    this.rowBg = createSvgElement('rect', this.styles.getRowBg(this.rowWidth, this.rowHeight), this.row);
  };
  _proto.renderRank = function renderRank() {
    var rankColor = getRankColor(this.index + 1);
    this.rankBg = createSvgElement('rect', this.styles.getRankBg(this.columnX[0], this.textBaselineY, this.rankBgSize, rankColor), this.row);
    this.rankText = createSvgElement('text', this.styles.getRankText(this.columnX[0], this.textBaselineY, this.rankBgSize), this.row);
    this.rankText.textContent = "" + (this.index + 1);
  };
  _proto.renderName = function renderName() {
    this.nameText = createSvgElement('text', this.styles.getNameText(this.padding, this.rankBgSize, this.textBaselineY), this.row);
    // 判断是否省略文本和挂载tooltip
    setEllipsisWithTooltip(this.nameText, this.data.name || '', TEXT.MAX_NAME_LENGTH);
  };
  _proto.renderValue = function renderValue() {
    this.valueText = createSvgElement('text', this.styles.getValueText(this.columnX[1], this.textBaselineY), this.row);
    this.valueText.textContent = this.data.value || 0;
  };
  _proto.renderPercent = function renderPercent() {
    this.percentText = createSvgElement('text', this.styles.getPercentText(this.columnX[2], this.textBaselineY), this.row);
    this.percentText.textContent = this.data.percent ? this.data.percent + "%" : '';
  };
  _proto.renderProgressBar = function renderProgressBar() {
    this.progressBarBg = createSvgElement('rect', this.styles.getProgressBarBg(this.padding, this.rowHeight, this.progressBarWidth, this.progressBarHeight), this.row);
    this.addTooltipEvents(this.progressBarBg);
    var progressBarColor = this.getProgressBarColor();
    this.progressBar = createSvgElement('rect', this.styles.getProgressBar(this.padding, this.rowHeight, this.progressBarHeight, progressBarColor), this.row);
    this.addTooltipEvents(this.progressBar);

    // 进度条动画
    var animate = createSvgElement('animate', this.styles.getAnimation(this.progressBarWidth, this.data.percent || 0), this.progressBar);
    animate.beginElement();
  };
  _proto.addTooltipEvents = function addTooltipEvents(el) {
    var _this = this;
    var handleMouseOver = function handleMouseOver(e) {
      // data在handleData中已做处理
      var data = {
        name: _this.data.name,
        value: _this.data.value,
        percent: _this.data.percent,
        color: _this.data.color,
        content: _this.data.content || ''
      };
      showTooltip(data, e);
    };
    var handleMouseOut = function handleMouseOut() {
      hideTooltip();
    };
    handleEvents(el, 'mouseenter', [handleMouseOver], true);
    handleEvents(el, 'mouseleave', [handleMouseOut], true);
  }

  //自适应计算布局
  ;
  _proto.resize = function resize(newWidth) {
    this.rowWidth = newWidth;
    this.progressBarWidth = this.rowWidth - 2 * this.padding;
    this.columnX = calcColumnX(TEXT.FLEX_SPACE, this.rowWidth, this.padding);

    // 移除原有的动画
    if (this.progressBar) {
      var anim = this.progressBar.querySelector('animate');
      if (anim) anim.remove();
    }
    var textX = this.styles.updateText(this.columnX);
    updateSvgs([{
      el: this.rowBg,
      attrs: this.styles.updateRowBg(newWidth)
    }, {
      el: this.rankBg,
      attrs: this.styles.updateRank(this.columnX[0], this.textBaselineY, this.rankBgSize)
    }, {
      el: this.rankText,
      attrs: this.styles.updateRankText(this.columnX[0], this.textBaselineY, this.rankBgSize)
    }, {
      el: this.valueText,
      attrs: textX[0]
    }, {
      el: this.percentText,
      attrs: textX[1]
    }, {
      el: this.progressBarBg,
      attrs: this.styles.updateProgressBarBg(this.progressBarWidth)
    }, {
      el: this.progressBar,
      attrs: this.styles.updateProgressBar(this.progressBarWidth, this.data.percent)
    }]);
  }

  // 更新样式和颜色
  ;
  _proto.updateStyles = function updateStyles(latestChartToken, colorArray) {
    // 更新样式对象
    this.styles = getRowStyles(latestChartToken);
    var newStyles = this.styles.getThemeUpdates();

    // 更新colorArray
    if (colorArray) {
      this.colorArray = colorArray;
    }
    var progressBarColor = this.getProgressBarColor();
    updateSvgs([{
      el: this.rowBg,
      attrs: newStyles.rowBackground
    }, {
      el: this.rankText,
      attrs: newStyles.rankText
    }, {
      el: this.nameText,
      attrs: newStyles.nameText
    }, {
      el: this.valueText,
      attrs: newStyles.valueText
    }, {
      el: this.percentText,
      attrs: newStyles.percentText
    }, {
      el: this.progressBar,
      attrs: _extends({}, newStyles.progressBar, {
        fill: progressBarColor,
        width: this.progressBarWidth * ((this.data.percent || 0) / 100)
      })
    }, {
      el: this.progressBarBg,
      attrs: _extends({}, newStyles.progressBarBackground, {
        width: this.progressBarWidth
      })
    }]);
  };
  _proto.destroy = function destroy() {
    // 组件卸载时移除事件监听
    if (this.progressBar) {
      unbindAllEvents(this.progressBar);
    }
    if (this.progressBarBg) {
      unbindAllEvents(this.progressBarBg);
    }
    if (this.nameText) {
      unbindAllEvents(this.nameText);
    }
  };
  return ContentRow;
}();
export { ContentRow };
