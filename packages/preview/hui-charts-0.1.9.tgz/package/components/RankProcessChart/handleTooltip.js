import getTooltipContentHtmlStr from '../../option/config/tooltip/formatter.js';
import { TOOLTIP } from './constants.js';
import { getTooltipStyles } from './style.js';
import { handleEvents } from './utils.js';

// 全局tooltip实例
var tooltip = null;
var Tooltip = /*#__PURE__*/function () {
  function Tooltip(dom, theme, tooltipConfig) {
    this.dom = dom;
    this.theme = theme;
    this.config = tooltipConfig;
    this.tooltip = null;
    this.offset = TOOLTIP.OFFSET;

    // 获取样式配置
    this.styles = getTooltipStyles();
    if (this.config.show) {
      this.createTooltip();
      this.followMouse();
    }
  }
  var _proto = Tooltip.prototype;
  _proto.createTooltip = function createTooltip() {
    this.tooltip = document.createElement('div');
    this.tooltip.style.cssText = this.styles.getBaseStyles(this.theme);
    this.tooltip.style.visibility = 'hidden';
    document.body.appendChild(this.tooltip);
  };
  _proto.getContent = function getContent(data) {
    var config = {
      title: '',
      children: []
    };
    var displayValue = '';
    if (data.value) {
      displayValue += data.value;
    }
    if (data.percent) {
      displayValue += ' ' + data.percent + '%';
    }
    config.children.push({
      name: data.name,
      value: displayValue,
      iconColor: data.color
    });

    // 用户自定义内容
    if (data.content) {
      config.children.push({
        name: '',
        value: data.content
      });
    }
    return getTooltipContentHtmlStr(config);
  }

  // 绑定鼠标跟随事件
  ;
  _proto.followMouse = function followMouse() {
    var _this = this;
    if (!this.tooltip) return;
    this.mouseMoveHandler = function (e) {
      // 只有当tooltip可见时才跟随
      if (!_this.tooltip || _this.tooltip.style.visibility !== 'visible') return;
      _this.updateTooltipPosition(e);
    };
    handleEvents(this.dom, 'mousemove', [this.mouseMoveHandler], true);
  }

  // 更新tooltip位置
  ;
  _proto.updateTooltipPosition = function updateTooltipPosition(e) {
    if (!this.tooltip || !this.dom) return;

    // 获取容器边界信息，同时做一些默认处理
    var domRect = this.dom.getBoundingClientRect();
    var domLeft = domRect.left || 0;
    var domTop = domRect.top || 0;
    var domWidth = domRect.width || 0;
    var domHeight = domRect.height || 0;
    var maxX = domLeft + domWidth; // 容器右边界
    var maxY = domTop + domHeight; // 容器下边界

    // 获取tooltip尺寸，同样做一些默认处理
    var tooltipRect = this.tooltip.getBoundingClientRect();
    var tooltipWidth = tooltipRect.width || 200;
    var tooltipHeight = tooltipRect.height || 100;
    var left = e.clientX + this.offset; // 初始left位置
    var top = e.clientY + this.offset; // 初始top位置

    // 边界检测和调整
    if (left + tooltipWidth >= maxX) {
      left = e.clientX - tooltipWidth - this.offset;
    }
    if (top + tooltipHeight >= maxY) {
      top = e.clientY - tooltipHeight - this.offset;
    }
    var position = this.styles.getPosition(left, top);
    Object.assign(this.tooltip.style, position);
  };
  _proto.show = function show(data, e) {
    var _this2 = this;
    // show方法封装后只暴露给row，row的data经过handleData的处理，已具有默认值
    if (!this.tooltip || !this.config.show) return;
    var content;
    if (this.config.formatter && typeof this.config.formatter === 'function') {
      var params = {
        name: data.name,
        value: data.value,
        percent: data.percent,
        color: data.color,
        content: data.content
      };
      content = this.config.formatter(params);
    } else {
      content = this.getContent(data);
    }
    this.tooltip.innerHTML = content;

    // 初始定位
    if (e) {
      this.updateTooltipPosition(e);
    }
    requestAnimationFrame(function () {
      var visibilityStyles = _this2.styles.getVisibility(true);
      Object.assign(_this2.tooltip.style, visibilityStyles);
    });
  };
  _proto.hide = function hide() {
    var _this3 = this;
    if (!this.tooltip) return;
    requestAnimationFrame(function () {
      var visibilityStyles = _this3.styles.getVisibility(false);
      Object.assign(_this3.tooltip.style, visibilityStyles);
    });
  }

  // 更新主题
  ;
  _proto.updateStyles = function updateStyles(newTheme) {
    this.theme = newTheme;
    if (this.tooltip) {
      this.tooltip.style.cssText = this.styles.getThemeUpdate(newTheme);
    }
  };
  _proto.destroy = function destroy() {
    if (this.dom) {
      handleEvents(this.dom, 'mousemove', [this.mouseMoveHandler], false);
    }
    if (this.tooltip && this.tooltip.parentNode) {
      this.tooltip.parentNode.removeChild(this.tooltip);
      this.tooltip = null;
    }
  };
  return Tooltip;
}();
function createTooltip(dom, theme, tooltipConfig) {
  if (tooltip) {
    tooltip.destroy();
  }
  tooltip = new Tooltip(dom, theme, tooltipConfig);
  return tooltip;
}
function showTooltip(data, e) {
  if (tooltip) {
    tooltip.show(data, e);
  }
}
function hideTooltip() {
  if (tooltip) {
    tooltip.hide();
  }
}
export { createTooltip, hideTooltip, showTooltip };
