function _inheritsLoose(t, o) { t.prototype = Object.create(o.prototype), t.prototype.constructor = t, _setPrototypeOf(t, o); }
function _setPrototypeOf(t, e) { return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) { return t.__proto__ = e, t; }, _setPrototypeOf(t, e); }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import BaseChart from '../BaseChart/index.js';
import NodeManager from './Node.js';
import { initContainer } from './insertDom.js';
import Token from '../../feature/token/index.js';
import { CHART_TYPE } from '../../util/constants.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var MilestoneChart = /*#__PURE__*/function (_BaseChart) {
  function MilestoneChart() {
    var _this;
    _this = _BaseChart.call(this) || this;
    // 图表渲染容器
    // 图表渲染容器
    _this.dom = void 0;
    // 图表所需数据
    _this.data = void 0;
    // 生成节点和计算位置
    _this.Node = void 0;
    _this.dom = null;
    // 图表配置项
    _this.option = null;
    // 图表容器的宽高变化监听器
    _this.resizeObserver = null;
    return _this;
  }

  // 初始化图表渲染容器
  _inheritsLoose(MilestoneChart, _BaseChart);
  var _proto = MilestoneChart.prototype;
  _proto.init = function init(dom) {
    this.dom = dom;
  }

  // 初始化图表渲染配置
  ;
  _proto.setSimpleOption = function setSimpleOption(chartName, option) {
    this.option = option;
  }

  // 图表渲染回调
  ;
  _proto.render = function render() {
    this.createDom();
    this.setResizeObserver();
  }

  // 图表渲染完成时回调
  ;
  _proto.onRenderReady = function onRenderReady(callback) {
    this.renderCallBack = callback;
  };
  _proto.createDom = function createDom() {
    this.dom.innerHTML = '';
    initContainer(this.dom, this.option);
    this.data = this.option.data;
    var container = this.dom.getElementsByClassName('mc-container')[0];
    this.Node = new NodeManager(this.data, this.option, container);
    this.Node.create(this.data, this.option, Token);
    container.style.setProperty('--operationButtonBgColor', Token.config.colorBoard.blue.colorBlue50);
    container.style.setProperty('--tooltipBgColor', Token.config.tooltipBg);
    container.style.setProperty('--tooltipBoxShadow', "0 " + Token.config.tooltipShadowOffsetY + "px " + Token.config.tooltipShadowBlur + "px 0 " + Token.config.tooltipShadowColor);
    container.style.setProperty('--currentTextColor', Token.config.titleTextColor);
    container.style.setProperty('--newPitch', this.option.padding || '0, 20px');
    container.style.setProperty('--maxWidth', this.option.itemStyle.maxWidth + 'px' || '160px');
    container.style.setProperty('--maxHeight', this.option.itemStyle.maxHeight + 'px' || '120px');
    this.renderCallBack && this.renderCallBack(this);
  }

  // 图表刷新，刷新配置项
  ;
  _proto.refresh = function refresh(option) {
    this.option = option;
    this.createDom();
  }

  // 图表刷新，仅刷新数据
  ;
  _proto.refreshData = function refreshData() {
    this.createDom();
  }

  // 刷新图表自适应宽度
  ;
  _proto.setResize = function setResize() {
    this.createDom();
  }

  // 监听容器变化
  ;
  _proto.setResizeObserver = function setResizeObserver() {
    var _this2 = this;
    this.resizeObserver = new ResizeObserver(function (entries) {
      _this2.setResize();
    });
    this.resizeObserver.observe(this.dom);
  }

  // 销毁图表
  ;
  _proto.uninstall = function uninstall() {
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
      this.resizeObserver = null;
    }
    this.dom.innerHTML = '';
  };
  return MilestoneChart;
}(BaseChart);
_defineProperty(MilestoneChart, "name", CHART_TYPE.MILESTONE);
export { MilestoneChart as default };
