import { CHARTTYPE } from './BaseOption.js';
import { getColor, codeToRGB } from '../../util/color.js';
import chartToken from './chartToken.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

function handleSeriesData(iChartOption, baseOpt, chartType) {
  var sourceData = [{
    depth: 0,
    id: 'option',
    value: 1255,
    type: undefined,
    label: undefined
  }];
  var legendData = [];
  var loopData = function loopData(data, depth, parentInfo) {
    if (depth === void 0) {
      depth = 1;
    }
    if (parentInfo === void 0) {
      parentInfo = {
        id: 'option'
      };
    }
    data.forEach(function (item, index) {
      item.depth = depth;
      item.id = parentInfo.id + "." + index;
      item.textColor = chartToken.labelColor;
      if (depth === 1) {
        var hasRecordIndex = legendData.findIndex(function (v) {
          return v === item.type;
        });
        item.color = getColor(iChartOption.color, hasRecordIndex !== -1 ? hasRecordIndex : legendData.length);
        item.borderColor = item.color;
      } else {
        item.type = parentInfo.type;
        item.color = parentInfo.color;
        item.borderColor = parentInfo.borderColor;
      }
      sourceData.push(item);
      if (!legendData.includes(item.type)) {
        legendData.push(item.type);
      }
      if (chartType === CHARTTYPE.NESTED && item.children && item.children.length) {
        if (item.depth === 1) {
          item.color = codeToRGB(item.color, .2);
        }
        loopData(item.children, depth + 1, item);
      }
    });
  };
  loopData(iChartOption.data);
  baseOpt.dataset[0].source = sourceData;
  baseOpt.legend.data = legendData;
  [].concat(legendData).reverse().forEach(function (item) {
    baseOpt.series.unshift({
      name: item,
      type: 'pie',
      data: [],
      radius: ['0%', '0%'],
      colorBy: 'data'
    });
  });
}
export { handleSeriesData };
