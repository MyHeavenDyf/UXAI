function _inheritsLoose(t, o) { t.prototype = Object.create(o.prototype), t.prototype.constructor = t, _setPrototypeOf(t, o); }
function _setPrototypeOf(t, e) { return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) { return t.__proto__ = e, t; }, _setPrototypeOf(t, e); }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import BaseChart from '../BaseChart/index.js';
import * as echarts from 'echarts';
import 'echarts/extension/bmap/bmap';
import { CHART_TYPE } from '../../util/constants.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 判断map资源加载的flag
var mapApiLoaded = false;
var BaiduMapChart = /*#__PURE__*/function (_BaseChart) {
  function BaiduMapChart() {
    var _this;
    _this = _BaseChart.call(this) || this;
    // 图表echarts实例
    _this.echartsIns = null;
    // 图表渲染容器
    _this.dom = null;
    // 图表配置项
    _this.option = null;
    // 图表所需数据
    _this.data = null;
    // 图表容器的宽高变化监听器
    _this.resizeObserver = null;
    return _this;
  }

  // 初始化图表渲染容器
  _inheritsLoose(BaiduMapChart, _BaseChart);
  var _proto = BaiduMapChart.prototype;
  _proto.init = function init(dom) {
    this.uninstall();
    this.dom = dom;
  }

  // 初始化图表渲染配置
  ;
  _proto.setSimpleOption = function setSimpleOption(chartName, option) {
    this.option = option;
  };
  _proto.loadMap = function loadMap(_ref) {
    var key = _ref.key,
      version = _ref.version,
      url = _ref.url;
    return new Promise(function (resolve) {
      if (mapApiLoaded) {
        resolve(window.BMap);
        return;
      }
      var cbName = 'bmap' + Date.now();
      var script = document.createElement('script');
      var ver = version || '2.0';
      window[cbName] = function () {
        mapApiLoaded = true;
        resolve(window.BMap);
      };
      script.src = [url + "?" + ver, "ak=" + key, "callback=" + cbName].join('&');
      document.body.appendChild(script);
    });
  }

  // 加载百度api，并渲染图表
  ;
  _proto.render = function render() {
    var _this2 = this;
    var url = this.option.url;
    var ver = this.option.v || '2.0';
    var key = this.option.key;
    this.loadMap({
      key: key,
      version: ver,
      url: url
    }).then(function () {
      _this2.renderInit();
    });
  }

  // 渲染图表
  ;
  _proto.renderInit = function renderInit() {
    this.echartsIns = echarts.init(this.dom);
    // 渲染
    this.setOption(this.option);
    this.setResizeObserver();
    // 图表渲染完成时回调
    this.renderCallBack && this.renderCallBack(this.echartsIns);
  }

  // 第一次渲染: 调用echarts原生的setOption
  ;
  _proto.setOption = function setOption(option) {
    this.echartsIns.setOption(option);
  }

  // 图表渲染完成时回调
  ;
  _proto.onRenderReady = function onRenderReady(callback) {
    this.renderCallBack = callback;
  }

  // 监听容器变化
  ;
  _proto.setResizeObserver = function setResizeObserver() {
    var _this3 = this;
    this.resizeObserver = new ResizeObserver(function (entries) {
      _this3.resizeDom();
    });
    this.resizeObserver.observe(this.dom);
  };
  _proto.resizeDom = function resizeDom() {
    this.echartsIns && this.echartsIns.resize && this.echartsIns.resize();
  }

  // 图表刷新，包括刷新配置和数据
  ;
  _proto.refresh = function refresh(iChartOption) {
    this.iChartOption = iChartOption;
    this.setSimpleOption(this.chartName, iChartOption);
    this.render();
  }

  // 图表刷新，仅刷新数据
  ;
  _proto.refreshData = function refreshData(data) {
    this.iChartOption.series[0].data = data;
    this.refresh(this.iChartOption);
  }

  // 刷新图表自适应宽度
  ;
  _proto.setResize = function setResize() {
    this.resizeDom();
  }

  // 销毁图表
  ;
  _proto.uninstall = function uninstall() {
    // 卸载window resize监听功能
    window.removeEventListener('resize', this.throttleResize);
    // 卸载container容器变化监听
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
      this.resizeObserver = null;
    }
    this.echartsDisposed();
    this.echartsIns = null;
    // 销毁dom
    this.dom = null;
  }

  // 销毁ECharts实例
  ;
  _proto.echartsDisposed = function echartsDisposed() {
    if (this.echartsIns && !this.echartsIns.isDisposed()) {
      this.echartsIns.dispose();
    }
  };
  return BaiduMapChart;
}(BaseChart);
_defineProperty(BaiduMapChart, "name", CHART_TYPE.BAIDU_MAP);
export { BaiduMapChart as default };
