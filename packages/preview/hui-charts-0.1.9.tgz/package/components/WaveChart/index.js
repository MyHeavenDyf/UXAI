function _createForOfIteratorHelperLoose(r, e) { var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (t) return (t = t.call(r)).next.bind(t); if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var o = 0; return function () { return o >= r.length ? { done: !0 } : { done: !1, value: r[o++] }; }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
function _inheritsLoose(t, o) { t.prototype = Object.create(o.prototype), t.prototype.constructor = t, _setPrototypeOf(t, o); }
function _setPrototypeOf(t, e) { return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) { return t.__proto__ = e, t; }, _setPrototypeOf(t, e); }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import BaseChart from '../BaseChart/index.js';
import { initContainer } from './insert.js';
import RadarChart from '../RadarChart/index.js';
import CoreChart from '../../core.js';
import defendXSS from '../../util/defendXSS.js';
import { percentToDecimal } from '../../util/math.js';
import { getTextWidth } from '../../util/dom.js';
import { isArray } from '../../util/type.js';
import { insertStateDom, removeStateDom } from '../../util/init/insert.js';
import chartToken from './chartToken.js';
import { CHART_TYPE } from '../../util/constants.js';
import Token from '../../feature/token/index.js';
import { codeToRGB } from '../../util/color.js';
import merge from '../../util/merge.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

var LARGE_SYMBOL_SIZE = 12;
var SMALL_SYMBOL_SIZE = 8;
var LARGE_BORDER_WIDTH = 2;
var SMALL_BORDER_WIDTH = 1.5;
var LARGE_LINE_WIDTH = 3;
var SMALL_LINE_WIDTH = 2;
var HEALTH_RGBA = '130,204,51,';
var WARNING_RGBA = '255,183,0,';
var RISK_RGBA = '242,48,48,';
var WaveChart = /*#__PURE__*/function (_BaseChart) {
  function WaveChart() {
    var _this;
    _this = _BaseChart.call(this) || this;
    // 图表渲染容器
    _this.dom = null;
    // 图表配置项
    _this.option = null;
    // 图表所需数据
    _this.data = null;
    // 自定义dom容器
    _this.domContainer = null;
    // 自定义innerdom容器
    _this.innerContainer = null;
    // radar容器
    _this.rContainer = null;
    // loading状态容器
    _this.loadingContainer = null;
    // 位置
    _this.center = null;
    // 大小
    _this.radius = null;
    // 阈值线的数量
    _this.splitNumber = null;
    // 坐标系配置
    _this.radar = null;
    // 刻度值的最大值
    _this.radarMax = null;
    // loading文本容器
    _this.loadingDom = null;
    // 图表容器的宽高变化监听器
    _this.resizeObserver = null;
    // 是否显示波纹
    _this.showWave = null;
    // 是否开启自适应
    _this.adaptive = false;
    return _this;
  }

  // 初始化图表渲染容器
  _inheritsLoose(WaveChart, _BaseChart);
  var _proto = WaveChart.prototype;
  _proto.init = function init(dom) {
    this.dom = dom;
  }

  // 图表渲染回调
  ;
  _proto.render = function render() {
    this.data = this.option.data;
    // 渲染dom
    this.initDom();
    // 位置定位
    this.setPosition();
    // 初始化Radar
    this.data && this.setRadar();
    this.setResizeObserver();
    this.renderCallBack && this.renderCallBack(this);
  }

  // 初始化图表渲染配置
  ;
  _proto.setSimpleOption = function setSimpleOption(chartName, option) {
    this.option = option;
  }

  // 渲染dom
  ;
  _proto.initDom = function initDom() {
    initContainer(this.dom);
    this.domContainer = this.dom.getElementsByClassName('wave_dom_container')[0];
    this.innerContainer = this.dom.getElementsByClassName('wave_inner_container')[0];
    this.rContainer = this.dom.getElementsByClassName('wave_radar_container')[0];
    this.loadingContainer = this.dom.getElementsByClassName('wave_loading_container')[0];
    this.loadingDom = this.dom.getElementsByClassName('loading_dom')[0];
  }

  // 设置dom位置
  ;
  _proto.setPosition = function setPosition() {
    var basePosition = {
      center: ['50%', '50%'],
      radius: ['35%', '70%']
    };
    var position = this.option.position;
    this.radius = position && position.radius || basePosition.radius;
    this.center = position && position.center || basePosition.center;

    // 1.自适应处理中心点位置，开启adaptive就会强行覆盖用户的radius
    if (this.option.adaptive && this.option.theme.includes('hdesign')) {
      this.radarWidth = Math.max(200, this.rContainer.clientWidth * 0.8);
      this.radius = (Math.max(200, this.rContainer.clientWidth * 0.8) / this.rContainer.clientWidth * 100).toString() + "%";
    }

    // 处理只有外半径的情况 仅波纹图 前提是百分比 内环一定是外环的一半才行
    if (!isArray(this.radius)) {
      var innerRadius = (percentToDecimal(this.radius) / 2 * 100).toString() + "%";
      this.radius = [innerRadius, this.radius];
    }
    var newPosition = this.center.map(function (item) {
      if (item.indexOf('px') === -1 && item.indexOf('%') === -1) {
        item = item + "px";
      }
      return item;
    });
    this.setPointAndLineStyle();
    var left = newPosition[0];
    var top = newPosition[1];
    var tokenConfig = Token.config;
    // 根据主题动态设置主副文本颜色token 前提得用规范的class
    this.domContainer.style = "--wave-text-color:" + tokenConfig.titleTextColor + ";--wave-subtext-color:" + tokenConfig.titleSubTextColor + ";";
    this.domContainer.style.left = left;
    this.domContainer.style.top = top;
    this.loadingContainer.style.left = left;
    this.loadingContainer.style.top = top;
    this.innerContainer.style.left = left;
    this.innerContainer.style.top = top;
  }

  // 设置雷达图点和线的样式随着尺寸自适应
  ;
  _proto.setPointAndLineStyle = function setPointAndLineStyle() {
    this.clientWidth = this.rContainer.clientWidth;
    this.clientHeight = this.rContainer.clientHeight;
    this.innerRadiusDecimal = percentToDecimal(this.radius[0]);
    this.outerRadiusDecimal = percentToDecimal(this.radius[1]);
    var trueWidth = Math.min(this.clientWidth, this.clientHeight) * this.outerRadiusDecimal;
    if (trueWidth > 280) {
      this.symbolSize = LARGE_SYMBOL_SIZE;
      this.borderitemStyleWidth = LARGE_BORDER_WIDTH;
      this.lineStyleWidth = LARGE_LINE_WIDTH;
    } else {
      this.symbolSize = SMALL_SYMBOL_SIZE;
      this.borderitemStyleWidth = SMALL_BORDER_WIDTH;
      this.lineStyleWidth = SMALL_LINE_WIDTH;
    }
  }

  // 初始化radar
  ;
  _proto.setRadar = function setRadar() {
    var _this$option$tooltip, _this$option$tooltip2;
    var _this$option = this.option,
      _this$option$type = _this$option.type,
      type = _this$option$type === void 0 ? 'health' : _this$option$type,
      _this$option$theme = _this$option.theme,
      theme = _this$option$theme === void 0 ? 'light' : _this$option$theme;
    var axisLineColor = chartToken.axisLineColor,
      axisLabelColor = chartToken.axisLabelColor,
      splitLineColor = chartToken.splitLineColor,
      axisNameColor = chartToken.axisNameColor;
    this.splitNumber = 3;
    this.radar = this.option.radar;
    this.radarMax = this.option.radarMax;
    this.radarMark = this.option.radarMark;
    // 创建图表实例
    var chartIns = new CoreChart();
    chartIns.init(this.rContainer);
    this.setAreaColor(type, this.splitNumber);
    var chartOption = {
      isWaveRadar: null,
      radarMark: false,
      radarMax: 100,
      position: {},
      legend: {
        show: false
      },
      data: {
        label: {}
      },
      radar: {
        axisName: {
          formatter: function formatter(indicatorName) {
            return "{a|" + indicatorName + "}";
          },
          rich: {
            a: {
              color: axisNameColor,
              align: 'center',
              fontSize: 12,
              lineHeight: 12
            }
          }
        },
        axisLabel: {
          color: axisLabelColor,
          showMinLabel: false,
          formatter: function formatter(value) {
            return Math.round(value);
          }
        },
        axisLine: {
          lineStyle: {
            color: codeToRGB(axisLineColor, 0.1)
          }
        },
        splitLine: {
          show: false,
          lineStyle: {
            type: 'solid',
            color: splitLineColor
          }
        },
        splitArea: {
          show: true,
          areaStyle: {
            color: this.colorArr
          }
        }
      },
      series: [{
        name: 'data',
        symbol: '',
        symbolSize: this.symbolSize,
        itemStyle: {
          borderWidth: this.borderitemStyleWidth
        },
        lineStyle: {
          width: this.lineStyleWidth
        }
      }],
      tooltip: {
        show: true
      }
    };
    // 设置雷达图覆盖颜色
    if (type === 'health') {
      chartOption.color = Token.config.colorState.colorSuccess;
      chartOption.radar.axisLine.lineStyle.color = codeToRGB(Token.config.colorState.colorSuccess, 0.1);
    } else if (type === 'warning') {
      chartOption.color = Token.config.colorAlarms.colorAlarmSecondary;
      chartOption.radar.axisLine.lineStyle.color = codeToRGB(Token.config.colorAlarms.colorAlarmSecondary, 0.1);
    } else if (type === 'risk') {
      chartOption.color = Token.config.colorState.colorError;
      chartOption.radar.axisLine.lineStyle.color = codeToRGB(Token.config.colorState.colorError, 0.1);
    }
    // 雷达图数据为空时，显示分割线
    if (isArray(this.data)) {
      this.data.forEach(function (item) {
        chartOption.data.label[item] = 0;
      });
    } else {
      chartOption.data = this.data;
    }
    // 继承属性
    chartOption.isMobile = this.option.isMobile;
    chartOption.adaptive = this.option.adaptive;
    if ((_this$option$tooltip = this.option.tooltip) != null && _this$option$tooltip.alwaysShowContent) {
      chartOption.tooltip.alwaysShowContent = true;
    }
    if ((_this$option$tooltip2 = this.option.tooltip) != null && _this$option$tooltip2.enterable) {
      chartOption.tooltip.enterable = true;
    }
    chartOption.isWaveRadar = true; // 波纹图标识
    theme && (chartOption.theme = this.option.theme);

    // 2.自适应尺寸到达200裁剪坐标和名称
    if (this.option.adaptive && this.option.theme.includes('hdesign')) {
      if (this.radarWidth === 200) {
        this.radarMark = false;
        chartOption.radar.axisName.show = false;
      }
    }
    this.radarMark && (chartOption.radarMark = this.radarMark);
    this.radarMax && (chartOption.radarMax = this.radarMax);
    chartOption.position.center = this.center;
    chartOption.position.radius = this.radius;
    chartOption.radar.splitNumber = this.splitNumber;

    // 是否显示背景
    this.showWave = this.option.showWave !== undefined ? this.option.showWave : true;
    if (!this.showWave) {
      chartOption.radar.splitArea.show = false;
      this.innerContainer.style.backgroundColor = '#fff';
      chartOption.radar.splitLine.show = true;
      chartOption.series[0].symbol = 'none';
      chartOption.series[0].lineStyle.width = 0;
      chartOption.series[0]['areaStyle'] = {
        opacity: 0
      };
      chartOption.series[0]['emphasis'] = {
        areaStyle: {
          opacity: 0
        }
      };
      this.innerContainer.style.display = 'none';
      chartOption['tooltip'] = {
        show: false
      };
    }
    merge(chartOption.radar, this.radar);
    chartIns.setSimpleOption(RadarChart, chartOption);
    // 开始渲染
    chartIns.render();
  }

  // 根据分割段和健康类型设置分割段颜色
  ;
  _proto.setAreaColor = function setAreaColor(type, splitNumber) {
    if (type === 'health') {
      this.rgba = HEALTH_RGBA;
    } else if (type === 'warning') {
      this.rgba = WARNING_RGBA;
    } else if (type === 'risk') {
      this.rgba = RISK_RGBA;
    }
    var arr = [];
    var base = type === 'risk' ? 0.08 : 0.1;
    for (var i = 1; i <= splitNumber + 1; i++) {
      var opacity = base * i;
      var rgba = "rgba(" + this.rgba + opacity + ")";
      arr.push(rgba);
    }
    this.backgroundColor = arr.reverse().shift();
    this.colorArr = arr;
  };
  _proto.resizeDom = function resizeDom() {
    this.setPointAndLineStyle();
    var loadingSvg = this.dom.getElementsByClassName('wave_loading_svg')[0];
    var scaleWidth = Math.min(this.clientWidth, this.clientHeight) * this.innerRadiusDecimal - Math.min(this.clientWidth, this.clientHeight) * (this.outerRadiusDecimal - this.innerRadiusDecimal) * (1 / this.splitNumber) + "px";
    var innerWidth = Math.min(this.clientWidth, this.clientHeight) * this.innerRadiusDecimal + 1 + "px";
    this.domContainer.style.width = scaleWidth;
    this.domContainer.style.height = scaleWidth;
    this.innerContainer.style.width = innerWidth;
    this.innerContainer.style.height = innerWidth;
    this.innerContainer.style.backgroundColor = this.backgroundColor;
    this.loadingDom.style.width = scaleWidth;
    this.loadingDom.style.height = scaleWidth;
    loadingSvg.style.width = scaleWidth;
    loadingSvg.style.height = scaleWidth;
    this.setCenterDom(this.domContainer);
  }

  // 插入中心内容
  ;
  _proto.setCenterDom = function setCenterDom(domContainer) {
    if (!this.option.centerDom || !domContainer) return;
    this.insertCenterDom(this.option.centerDom, domContainer);
  }

  // 自定义centerDom插入容器dom
  ;
  _proto.insertCenterDom = function insertCenterDom(centerDom, dom) {
    var htmlContent = typeof centerDom === 'function' ? centerDom(dom) : centerDom;
    if (!htmlContent || !dom) return;
    // 3.自适应设置中心文本字体大小
    if (this.option.adaptive && this.option.theme.includes('hdesign')) {
      htmlContent = this.setTitleFontSize(htmlContent, dom);
    }
    // 插入内容（清空旧内容）
    if (typeof htmlContent === 'string') {
      dom.innerHTML = htmlContent;
    } else if (htmlContent instanceof Node) {
      dom.innerHTML = '';
      dom.appendChild(htmlContent);
    }
  }

  // 获取中心文本设置字体大小
  ;
  _proto.setTitleFontSize = function setTitleFontSize(htmlString, dom) {
    var waveSize = this.radarWidth;
    var domSize = this.domContainer.clientWidth;
    // 创建临时容器解析 HTML 字符串
    var tempContainer = document.createElement('div');
    tempContainer.innerHTML = htmlString;

    // 查找关键元素
    var valueEl = tempContainer.querySelector('.wave_value');
    var unitEl = tempContainer.querySelector('.wave_unit');
    var subTextEl = tempContainer.querySelector('.wave_subText');

    // 如果都不存在，直接返回原 HTML（避免报错）
    if (!valueEl && !unitEl && !subTextEl) {
      console.warn('DOM structure not as expected, skipping font size update');
      return htmlString;
    }
    // 获取主文本（用于计算字体大小）
    var valueText = valueEl && valueEl.textContent.trim(); // 如"96"
    var unitText = unitEl && unitEl.textContent.trim(); // 如"分"
    var fontSize = this.calculateFontSize(waveSize, domSize, valueText, unitText);

    // 更新各个部分的字体大小
    if (valueEl) {
      valueEl.style.fontSize = fontSize.mainFontSize + "px";
    }
    if (unitEl) {
      unitEl.style.fontSize = fontSize.subFontSize + "px";
    }
    if (subTextEl) {
      subTextEl.style.fontSize = fontSize.subFontSize + "px";
    }
    // 返回更新后的 HTML 字符串
    return tempContainer.innerHTML;
  }

  // 根据自适应规则计算中心文本字体
  ;
  _proto.calculateFontSize = function calculateFontSize(waveSize, domSize, valueText, unitText) {
    // 1. 计算主文本最大可用宽度（dom直径的 80%）
    var maxMainTextWidth = domSize * 0.8;

    // 2. 根据尺寸确定主文本候选字号区间（从大到小）
    var getMainFontSizeRange = function getMainFontSizeRange(size) {
      if (size > 112) {
        return [48, 36, 32];
      } else {
        return [32, 24]; // 默认值，暂时用不上
      }
    };

    // 3. 确定副文本候选字号
    var getSubFontSize = function getSubFontSize(size) {
      if (size >= 280) return 14;
      return 12;
    };

    // 4. 获取字号区间
    var mainSizes = getMainFontSizeRange(domSize);
    var subFontSize = getSubFontSize(waveSize);

    // 5. 尝试主文本每个字号，找到第一个不超宽的
    var mainFontSize = mainSizes[0]; // 默认最大字号
    var flag = false;
    for (var _iterator = _createForOfIteratorHelperLoose(mainSizes), _step; !(_step = _iterator()).done;) {
      var size = _step.value;
      var mainWidth = getTextWidth(valueText, size);
      var unitWidth = unitText ? getTextWidth(unitText, subFontSize) : 0;
      var totalWidth = mainWidth + unitWidth;
      if (totalWidth <= maxMainTextWidth) {
        flag = true;
        mainFontSize = size;
        break; // 找到第一个合适的就停
      }
    }
    // 如果都不合适，用最小字号兜底
    if (!flag) mainFontSize = mainSizes[mainSizes.length - 1];
    return {
      mainFontSize: mainFontSize,
      subFontSize: subFontSize
    };
  }

  // 图表渲染完成时回调
  ;
  _proto.onRenderReady = function onRenderReady(callback) {
    this.renderCallBack = callback;
  }

  // 监听容器变化
  ;
  _proto.setResizeObserver = function setResizeObserver() {
    var _this2 = this;
    this.resizeObserver = new ResizeObserver(function (entries) {
      _this2.setPosition();
      _this2.resizeDom();
      _this2.setRadar();
    });
    this.resizeObserver.observe(this.dom);
  }

  // 图表刷新，刷新配置项
  ;
  _proto.refresh = function refresh(option) {
    if (this.innerContainer) {
      this.innerContainer.style.display = 'block';
    }
    this.domContainer.innerHTML = '';
    this.innerContainer.innerHTML = '';
    this.option = option;
    this.data = option.data;
    this.centerDom = option.centerDom;
    this.setPosition();
    this.data && this.setRadar();
    this.resizeDom();
  }

  // 刷新图表自适应宽度
  ;
  _proto.setResize = function setResize() {
    this.resizeDom();
  }

  // 图表刷新，仅刷新数据
  ;
  _proto.refreshData = function refreshData(data) {
    this.option.data = data;
    this.refresh(this.option);
  }

  // 加载状态
  ;
  _proto.showLoading = function showLoading(option) {
    if (option === void 0) {
      option = {};
    }
    if (this.loadingContainer) {
      var _newOption, _newOption2, _newOption3, _newOption4, _newOption5;
      this.domContainer.innerHTML = '';
      this.loadingDom.innerHTML = '';
      var newOption = {
        theme: this.option.theme || 'light',
        data: this.option.data,
        showWave: false
      };
      // 合并新旧数据
      newOption = merge(newOption, option);
      // 重新渲染
      this.refresh(newOption);
      // 处理loading
      var text = ((_newOption = newOption) == null ? void 0 : _newOption.text) || '加载中...';
      var textSize = ((_newOption2 = newOption) == null ? void 0 : _newOption2.textSize) || 24;
      var textShow = ((_newOption3 = newOption) == null ? void 0 : _newOption3.textShow) === false ? false : true;
      var textColor = ((_newOption4 = newOption) == null ? void 0 : _newOption4.textColor) || (((_newOption5 = newOption) == null ? void 0 : _newOption5.theme.indexOf('dark')) !== -1 ? '#FFFFFF' : '#808080');
      var centerDom = function centerDom() {
        var dom = "\n                <div style=\"color: " + defendXSS(textColor) + ";font-size: " + defendXSS(textSize) + "px;line-height: " + defendXSS(textSize) + "px;display: " + defendXSS(textShow ? 'block' : 'none') + ";letter-spacing: 0.5px;\">\n                    " + defendXSS(text) + "\n                </div>";
        return dom;
      };
      this.insertCenterDom(centerDom, this.loadingDom);
      this.loadingContainer.style.display = 'block';
    } else {
      // 显示通用性loading
      insertStateDom(this.dom, 'loading', option);
    }
  };
  _proto.hideLoading = function hideLoading() {
    this.closeLoading();
  }

  // 关闭加载
  ;
  _proto.closeLoading = function closeLoading() {
    // 通用性loading也要关闭
    removeStateDom(this.dom, 'loading');
    if (this.loadingContainer) {
      this.loadingContainer.style.display = 'none';
    }
  }

  // 销毁图表
  ;
  _proto.uninstall = function uninstall() {
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
      this.resizeObserver = null;
    }
    this.dom.innerHTML = '';
  };
  return WaveChart;
}(BaseChart);
_defineProperty(WaveChart, "name", CHART_TYPE.WAVE);
export { WaveChart as default };
