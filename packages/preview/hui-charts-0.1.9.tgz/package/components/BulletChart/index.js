function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import { handleSeries } from './handleSeries.js';
import init from '../../option/init/index.js';
import updateWidth from './bulletChartOption.js';
import { handleTooltip, setDirection } from './handleOptipn.js';
import RectCoordSys from '../../option/RectSys/index.js';
import { CHART_TYPE, ADAPTIVE_THEME } from '../../util/constants.js';
import { mergeSeries } from '../../util/merge.js';
import xkey from '../../option/config/xAxis/xkey.js';
import xdata from '../../option/config/xAxis/xdata.js';
import ldata from '../../option/config/legend/ldata.js';
import ydata from '../../option/config/yAxis/ydata.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var BulletChart = /*#__PURE__*/function () {
  function BulletChart(iChartOption, chartInstance) {
    this.baseOption = {};
    this.iChartOption = {};
    this.iChartOption = init(iChartOption);
    this.chartInstance = chartInstance;
    // 根据 iChartOption 组装 baseOption
    this.updateOption();
  }
  var _proto = BulletChart.prototype;
  _proto.updateOption = function updateOption() {
    var iChartOption = this.iChartOption;
    // 图例数据
    RectCoordSys(this.baseOption, iChartOption, CHART_TYPE.BULLET);
    // x轴key值
    var xAxisKey = xkey(iChartOption);
    // x轴数据
    var xAxisData = xdata(iChartOption.data, xAxisKey);
    this.baseOption.xAxis.forEach(function (item) {
      item.data = xAxisData;
    });
    // 图例数据
    var legendData = ldata(iChartOption.data, xAxisKey);
    // 连线的数据
    var seriesData = ydata(iChartOption.data, legendData);
    //  图表鼠标悬浮提示框
    handleTooltip(this.baseOption, iChartOption);
    // 图表的series
    handleSeries(this.baseOption, iChartOption, legendData, seriesData);
    // 设置柱状图的方向
    setDirection(this.baseOption, iChartOption.direction);
    // 合并用户自定义series
    mergeSeries(iChartOption, this.baseOption);
  }

  // 根据渲染出的结果，二次计算option
  ;
  _proto.updateOptionAgain = function updateOptionAgain() {
    var _baseOption$dataZoom, _baseOption$dataZoom$, _this$iChartOption$it;
    var baseOption = this.baseOption;
    // 如果用户自定义了 barWidth 或 存在 dataZoom，则不主动刷新柱宽
    if (!((_baseOption$dataZoom = baseOption.dataZoom) != null && (_baseOption$dataZoom$ = _baseOption$dataZoom[0]) != null && _baseOption$dataZoom$.show) && !((_this$iChartOption$it = this.iChartOption.itemStyle) != null && _this$iChartOption$it.barWidth) && ADAPTIVE_THEME.includes(this.iChartOption.theme)) {
      updateWidth(baseOption, this.chartInstance, this.iChartOption);
    }
  };
  _proto.getOption = function getOption() {
    return this.baseOption;
  };
  _proto.setOption = function setOption() {};
  _proto.resize = function resize(callback) {
    var _this$baseOption$data, _this$baseOption$data2, _this$iChartOption$it2;
    // 如果用户自定义了 barWidth 或 存在 dataZoom，则不主动刷新柱宽
    if (!((_this$baseOption$data = this.baseOption.dataZoom) != null && (_this$baseOption$data2 = _this$baseOption$data[0]) != null && _this$baseOption$data2.show) && !((_this$iChartOption$it2 = this.iChartOption.itemStyle) != null && _this$iChartOption$it2.barWidth) && ADAPTIVE_THEME.includes(this.iChartOption.theme)) {
      updateWidth(this.baseOption, this.chartInstance, this.iChartOption);
      callback && callback(this.baseOption);
    }
  };
  return BulletChart;
}();
_defineProperty(BulletChart, "name", CHART_TYPE.BULLET);
export { BulletChart as default };
