var _HashMap;
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import { ictLight, ictDark } from './theme/ict/index.js';
import { bpitLight, bpitDark } from './theme/bpit/index.js';
import { cloudLight, cloudDark } from './theme/cloud/index.js';
import { hdesignLight, hdesignDark } from './theme/hdesign/index.js';
import { dpuiLight, dpuiDark } from './theme/dpui/index.js';
import merge from '../../util/merge.js';
import HashMap from '../../util/hashMap.js';
import cloneDeep from '../../util/cloneDeep.js';
import tips from '../../util/tips.js';
import { THEMES, CURRENT_THEME, DEFAULT_THEME_NAME, THEME_ERROR_TIP_MESSAGE } from '../../util/constants.js';
import mergeToken from './factory/mergeToken.js';
import { EXPORT_COLORS_KEY } from './factory/getExportColors.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

var themeToken = new HashMap((_HashMap = {}, _HashMap[THEMES.LIGHT] = cloneDeep(ictLight), _HashMap[THEMES.DARK] = cloneDeep(ictDark), _HashMap[THEMES.BPIT_LIGHT] = cloneDeep(bpitLight), _HashMap[THEMES.BPIT_DARK] = cloneDeep(bpitDark), _HashMap[THEMES.CLOUD_LIGHT] = cloneDeep(cloudLight), _HashMap[THEMES.CLOUD_DARK] = cloneDeep(cloudDark), _HashMap[THEMES.HDESIGN_LIGHT] = cloneDeep(hdesignLight), _HashMap[THEMES.HDESIGN_DARK] = cloneDeep(hdesignDark), _HashMap[THEMES.DPUI_LIGHT] = cloneDeep(dpuiLight), _HashMap[THEMES.DPUI_DARK] = cloneDeep(dpuiDark), _HashMap[CURRENT_THEME] = cloneDeep(ictLight), _HashMap));
var Token = /*#__PURE__*/function () {
  function Token() {}
  // todo待修改
  Token.set = function set(name, config) {
    var defaultConfig = cloneDeep(this.getConfig(DEFAULT_THEME_NAME));
    merge(defaultConfig, config);
    themeToken.set(name, defaultConfig);
  }
  //  以下待确认
  ;
  Token.setConfig = function setConfig(name, config) {
    // 以下为新的逻辑
    var themeKeys = this.getThemeKeys();
    var validate = themeKeys.includes(name);
    // 修改已有主题的配置
    if (validate) {
      var newConfig = mergeToken(name, config);
      var oldConfig = this.getConfig(name);
      merge(oldConfig, newConfig);
    } else {
      var _newConfig = mergeToken(DEFAULT_THEME_NAME, config);
      themeToken.set(name, _newConfig);
    }
  }
  //  以下待确认
  ;
  Token.getThemeKeys = function getThemeKeys() {
    return themeToken.keys();
  }

  //  以下待确认
  ;
  Token.resetThemeCongfig = function resetThemeCongfig() {
    themeToken.set(THEMES.LIGHT, cloneDeep(ictLight));
    themeToken.set(THEMES.DARK, cloneDeep(ictDark));
    themeToken.set(THEMES.BPIT_LIGHT, cloneDeep(bpitLight));
    themeToken.set(THEMES.BPIT_DARK, cloneDeep(bpitDark));
    themeToken.set(THEMES.CLOUD_LIGHT, cloneDeep(cloudLight));
    themeToken.set(THEMES.CLOUD_DARK, cloneDeep(cloudDark));
    themeToken.set(THEMES.HDESIGN_LIGHT, cloneDeep(hdesignLight));
    themeToken.set(THEMES.HDESIGN_DARK, cloneDeep(hdesignDark));
    themeToken.set(CURRENT_THEME, cloneDeep(ictLight));
  };
  Token.getConfig = function getConfig(name) {
    return themeToken.get(name);
  };
  Token.setDefaultTheme = function setDefaultTheme(name) {
    var tempTheme = this.validate(name);
    if (this.themeName !== tempTheme) {
      this.themeName = tempTheme;
      // 以下config功能待完善
      themeToken.set(CURRENT_THEME, themeToken.get(tempTheme));
      this.config = this.getConfig(CURRENT_THEME);
    }
  }

  // 校验主题的合法性,将不合法的主题值重置为默认的light主题,并给与提示
  ;
  Token.validate = function validate(name) {
    // 如果没传并且没有全局注册过直接就是light主题
    var tempTheme = name || this.themeName || DEFAULT_THEME_NAME;
    if (tempTheme.toLowerCase().includes('cloud-light')) {
      tempTheme = THEMES.CLOUD_LIGHT;
    }
    if (tempTheme.toLowerCase().includes('cloud-dark')) {
      tempTheme = THEMES.CLOUD_DARK;
    }
    var themeKeys = themeToken.keys();
    var validate = themeKeys.includes(tempTheme);
    if (!validate) {
      tips.error(THEME_ERROR_TIP_MESSAGE);
      tempTheme = THEMES.LIGHT;
    }
    return tempTheme;
  }

  /**
   *
   * @param {string} chartName  图表名称，根据名称从config中获取对应图表的chartToken
   * @returns Object 用于series或者其他模块的Proxy代理token对象
   */;
  Token.getTokenByName = function getTokenByName(chartName) {
    var _this = this;
    var handler = function handler(_, prop) {
      var token = _extends({}, _this.config[chartName]);
      return token[prop];
    };
    return new Proxy({}, {
      get: handler
    });
  }

  /**
   * 用于ui规范检查
   * @param {string} chartName 图表名称，根据名称从config中获取对应图表的chartToken
   * @returns Object 在factory中定义的chartToken对象
   */;
  Token.getChartTokenByName = function getChartTokenByName(chartName) {
    return this.config[chartName];
  };
  Token.getToken = function getToken() {
    return this.config;
  }

  /**
   * Theme暴露使用的颜色变量
   * @returns object
   */;
  Token.getColors = function getColors() {
    var _this2 = this;
    var colorHandler = function colorHandler(_, prop) {
      var vaild = EXPORT_COLORS_KEY.includes(prop);
      return vaild ? _this2.config.exportColors[prop] : undefined;
    };
    return new Proxy({}, {
      get: colorHandler
    });
  };
  return Token;
}();
// 当前主题名称
Token.themeName = undefined;
Token.config = cloneDeep(ictLight);
export { THEMES, Token as default };
