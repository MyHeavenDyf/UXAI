function getBarDefOpt(iChartOpt) {
  var defOption = {
    padding: [32, 2, 0, 2],
    theme: 'hdesign-light',
    adaptive: true,
    startAngle: 270,
    labelAlign: 'left',
    title: {
      itemGap: 6
    },
    radiusAxis: {
      axisLabel: {
        margin: 8
      }
    }
  };
  return defOption;
}
export { getBarDefOpt as default };
