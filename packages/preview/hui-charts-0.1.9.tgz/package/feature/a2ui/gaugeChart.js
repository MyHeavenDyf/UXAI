function getGaugeDefOpt(iChartOpt) {
  var defOption = {
    padding: [20, 0, 10, 1],
    theme: 'hdesign-light',
    adaptive: true
  };
  return defOption;
}
export { getGaugeDefOpt as default };
