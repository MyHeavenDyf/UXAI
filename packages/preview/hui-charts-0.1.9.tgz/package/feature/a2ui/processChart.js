function getBarDefOpt(iChartOpt) {
  var defOption = {
    padding: [12, 10, 10, 10],
    theme: 'hdesign-light',
    adaptive: true
  };
  return defOption;
}
export { getBarDefOpt as default };
