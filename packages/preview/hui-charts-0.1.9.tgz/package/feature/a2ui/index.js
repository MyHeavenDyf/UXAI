function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import merge from '../../util/merge.js';
import getBarDefOpt from './barChart.js';
import getLineDefOpt from './lineChart.js';
import getGaugeDefOpt from './gaugeChart.js';
import getBarDefOpt$1 from './processChart.js';
import getRadarDefOpt from './radarChart.js';
import getPieDefOpt from './pieChart.js';
import getBarDefOpt$2 from './assembleBubbleChart.js';
import getBarDefOpt$3 from './bubbleChart.js';
import getBarDefOpt$4 from './bulletChart.js';
import getBarDefOpt$5 from './funnelChart.js';
import getBarDefOpt$6 from './hillChart.js';
import getBarDefOpt$7 from './jadeJueChart.js';
import getBarDefOpt$8 from './scatterChart.js';
function defaultA2uiOption(iChartOption, that) {
  var padding = iChartOption.padding;
  var chartName = that.chartName;
  var defOption = {
    legend: {}
  };
  var RectShapeCharts = ['LineChart', 'BarChart', 'BubbleChart', 'HillChart', 'BulletChart', 'ScatterChart'];
  var PolarShapeCharts = ['RadarChart', 'GaugeChart', 'JadeJueChart', 'PieChart'];
  if (RectShapeCharts.includes(chartName)) {
    defOption = {
      legend: {
        show: true,
        top: 2,
        right: 6,
        left: 'auto'
      },
      xAxis: {
        axisLabel: {
          interval: 'auto',
          alignMaxLabel: 'right'
        }
      }
    };
  }
  if (PolarShapeCharts.includes(chartName)) {
    defOption = {
      legend: ['RadarChart', 'GaugeChart'].includes(chartName) ? {} : {
        show: true,
        top: 'center',
        left: '68%',
        orient: 'vertical'
      },
      position: {
        center: ['RadarChart', 'GaugeChart'].includes(chartName) ? ['50%', '50%'] : ['35%', '50%'],
        radius: '65%'
      }
    };
  }
  if (['ProcessChart', 'GaugeChart', 'RadarChart'].includes(chartName)) {
    defOption.legend.show = false;
  }
  if (['LineChart'].includes(chartName)) {
    defOption.xAxis.fullGrid = true;
    defOption.xAxis.axisLabel = {
      alignMinLabel: 'left',
      alignMaxLabel: 'right'
    };
  }
  return _extends({
    padding: padding || [32, 4, 4, 0]
  }, defOption);
}
function setMiniChart(iChartOption, that) {
  var chartName = that.chartName;
  var dataZoom = iChartOption.dataZoom,
    data = iChartOption.data;
  var domRect = that.dom.getBoundingClientRect();
  if (['LineChart', 'BarChart'].includes(chartName) && domRect.height < 60) {
    iChartOption.mini = true;
    if (dataZoom) {
      dataZoom.left = 10;
    } else {
      dataZoom = {
        left: 0
      };
    }
    iChartOption.legend.show = false;
  } else if (['PieChart', 'RadarChart', 'GaugeChart'].includes(chartName) && domRect.width < 200 || domRect.height < 120) {
    iChartOption.mini = true;
    iChartOption.position = {
      center: ['50%', '50%'],
      radius: '75%'
    };
    iChartOption.tooltip = {
      show: false
    };
  } else if (chartName === 'ProcessChart' && domRect.height < data.length * 38) {
    iChartOption.mini = true;
    iChartOption.legend.show = false;
  } else {
    iChartOption.mini = false;
    if (!['ProcessChart', 'GaugeChart'].includes(chartName)) {
      iChartOption.legend.show = true;
    }
    if (dataZoom) {
      delete dataZoom.left;
    }
  }
}
function setA2ui(iChartOption, that) {
  var chartName = that.chartName;
  var defaultOption = {
    get LineChart() {
      return getLineDefOpt(iChartOption);
    },
    get BarChart() {
      return getBarDefOpt(iChartOption);
    },
    get GaugeChart() {
      return getGaugeDefOpt();
    },
    get RadarChart() {
      return getRadarDefOpt();
    },
    get ProcessChart() {
      return getBarDefOpt$1();
    },
    get PieChart() {
      return getPieDefOpt();
    },
    get AssembleBubbleChart() {
      return getBarDefOpt$2();
    },
    get BubbleChart() {
      return getBarDefOpt$3();
    },
    get BulletChart() {
      return getBarDefOpt$4(iChartOption);
    },
    get FunnelChart() {
      return getBarDefOpt$5();
    },
    get HillChart() {
      return getBarDefOpt$6(iChartOption);
    },
    get JadeJueChart() {
      return getBarDefOpt$7();
    },
    get ScatterChart() {
      return getBarDefOpt$8();
    }
  };
  merge(iChartOption, defaultOption[chartName]);
  // 图例在顶部
  merge(iChartOption, defaultA2uiOption(iChartOption, that));
  // 判断是否使用mini图表
  setMiniChart(iChartOption, that);
}
export { setA2ui as default };
