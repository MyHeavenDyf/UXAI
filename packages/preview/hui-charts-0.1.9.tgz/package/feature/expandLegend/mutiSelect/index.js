function _createForOfIteratorHelperLoose(r, e) { var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (t) return (t = t.call(r)).next.bind(t); if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var o = 0; return function () { return o >= r.length ? { done: !0 } : { done: !1, value: r[o++] }; }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
import { CSS_CLASS } from './constants.js';
import search from './search.js';
import { item } from './item.js';
import position from './position.js';
import Token from '../../token/index.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var DEFAULT_OPTION = {
  data: [1, 2, 3, 4, 5],
  onclick: function onclick() {}
};
var REMOVE_DELAY = 300;
var MutiSelect = /*#__PURE__*/function () {
  function MutiSelect(element) {
    this.color = [];
    this.root = element;
    if (!MutiSelect.huicharts_mutiselect) {
      MutiSelect.huicharts_mutiselect = true;
      document.addEventListener("click", hide);
      document.addEventListener("wheel", hide);
      window.addEventListener("resize", hide);
    }
  }
  var _proto = MutiSelect.prototype;
  _proto.setOption = function setOption(option) {
    var _option2;
    option = option || DEFAULT_OPTION;
    var _option = option,
      data = _option.data,
      onclick = _option.onclick,
      theme = _option.theme;
    this.option = option;
    if (option.color) this.color = option.color;
    this.itemStyle = (_option2 = option) == null ? void 0 : _option2.itemStyle;
    // 包装一下data
    this.data = option.data;
    // 给根元素绑定点击事件
    this.bindClick(onclick);
  }

  // 给根元素绑定点击事件
  ;
  _proto.bindClick = function bindClick(onclick) {
    var _this = this;
    this.root.addEventListener("click", function (e) {
      e.stopPropagation();
      var preMutiselect = document.querySelector("." + CSS_CLASS.MUTISELECT + "." + CSS_CLASS.MUTISELECT_ACTIVE);
      var preMutiselectId = null;
      if (preMutiselect !== null) {
        preMutiselectId = preMutiselect.dataset.id;
        preMutiselect.classList.remove(CSS_CLASS.MUTISELECT_ACTIVE);
        preMutiselect.classList.add(CSS_CLASS.MUTISELECT_HIDDEN);
        setTimeout(function () {
          document.body.removeChild(preMutiselect);
        }, REMOVE_DELAY);
      }
      if (preMutiselectId !== _this.root.id) {
        var mutiselect = _this.mutiselect(onclick);
        document.body.appendChild(mutiselect);
        position.call(_this, mutiselect);
      }
    });
  }

  // 创建下拉框dom
  ;
  _proto.mutiselect = function mutiselect(onclick) {
    var _this$option,
      _this$option$theme,
      _this2 = this;
    var tokenConfig = Token.config;
    tokenConfig.legendInactiveColor;
    var nameColor = tokenConfig.legendPageTextColor;
    var legendTextColor = tokenConfig.legendTextColor;
    var itemHoverBg = tokenConfig.legendDropDownItemHover;
    var checkboxPathFill = tokenConfig.colorState.colorInfo;
    var iconInactiveColor = tokenConfig.legendPageIconInactiveColor;
    var legendDropDownBgColor = tokenConfig.tooltipBg;
    var mutiselectDom = document.createElement("div");
    mutiselectDom.classList.add(CSS_CLASS.MUTISELECT, CSS_CLASS.MUTISELECT_ACTIVE);
    var containerDom = this.container();
    var searchDom = search.call(this, containerDom);
    mutiselectDom.append(searchDom, containerDom);
    if ((_this$option = this.option) != null && (_this$option$theme = _this$option.theme) != null && _this$option$theme.includes('hdesign')) {
      var _this$option2;
      mutiselectDom.classList.add('hdesign');
      mutiselectDom.classList.add((_this$option2 = this.option) == null ? void 0 : _this$option2.theme);
      mutiselectDom.setAttribute('style', "--nameColor: " + nameColor + ";--textColor: " + legendTextColor + ";--itemHoverBg: " + itemHoverBg + "; --checkboxPathFill:" + checkboxPathFill + "; --iconInactiveColor:" + iconInactiveColor + ";--legendDropDownBgColor:" + legendDropDownBgColor);
      mutiselectDom.style['box-shadow'] = "0 " + tokenConfig.tooltipShadowOffsetY + "px " + tokenConfig.tooltipShadowBlur + "px 0 " + tokenConfig.tooltipShadowColor;
    }
    // 给每个选项绑定点击事件，并执行传入的回调事件
    mutiselectDom.addEventListener("click", function (e) {
      var target = e.target;
      while (!target.className.includes) {
        target = target.parentNode;
      }
      while (target.className.includes != null && target.className.includes(CSS_CLASS.MUTISELECT) && target.className !== CSS_CLASS.ITEM) {
        target = target.parentNode;
      }
      if (target.className === CSS_CLASS.ITEM) {
        var _target$firstChild$fi;
        target.firstChild.classList.toggle("active");
        (_target$firstChild$fi = target.firstChild.firstChild) == null ? void 0 : _target$firstChild$fi.classList.toggle("active");
        _this2.data[target.dataset.id].selected = !_this2.data[target.dataset.id].selected;
        onclick && onclick(target.dataset.id);
      }
      e.stopPropagation();
    });

    // 鼠标在多选框中滚动时避免关闭下拉框
    mutiselectDom.addEventListener("wheel", function (e) {
      e.stopPropagation();
      if (containerDom.offsetHeight === containerDom.scrollHeight) {
        e.preventDefault();
      } else if (e.target === mutiselectDom) {
        e.preventDefault();
      }
    });
    return mutiselectDom;
  }

  // 刷新数据
  ;
  _proto.refreshData = function refreshData(data) {
    this.initData(data);
  }

  // 组装数据
  ;
  _proto.initData = function initData(data) {
    this.data = [];
    if (Array.isArray(data)) {
      for (var _iterator = _createForOfIteratorHelperLoose(data), _step; !(_step = _iterator()).done;) {
        var _item = _step.value;
        this.data.push({
          name: _item["name"] === undefined ? _item : _item["name"],
          value: _item["value"] === undefined ? _item : _item["value"],
          selected: _item["selected"] === undefined ? false : _item["selected"]
        });
      }
    }
  }

  // 创建条目容器
  ;
  _proto.container = function container() {
    var _this3 = this;
    var containerDom = document.createElement("div");
    containerDom.classList.add(CSS_CLASS.CONTAINER);
    var colorLength = this.color.length;
    this.data.forEach(function (item$1, index) {
      var color = _this3.color[index % colorLength];
      if (item$1.display && item$1.display !== 'none') {
        containerDom.appendChild(item.call(_this3, item$1, index, color, _this3.itemStyle));
      } else if (item$1.display === undefined) {
        containerDom.appendChild(item.call(_this3, item$1, index, color, _this3.itemStyle));
      }
    });
    return containerDom;
  };
  _proto.getData = function getData() {
    return this.data;
  };
  return MutiSelect;
}(); // 隐藏所有的mutiselect
MutiSelect.huicharts_mutiselect = false;
function hide() {
  var item = document.querySelector("." + CSS_CLASS.MUTISELECT + "." + CSS_CLASS.MUTISELECT_ACTIVE);
  if (item) {
    item.classList.remove(CSS_CLASS.MUTISELECT_ACTIVE);
    item.classList.add(CSS_CLASS.MUTISELECT_HIDDEN);
    setTimeout(function () {
      document.body.removeChild(item);
    }, REMOVE_DELAY);
  }
}
export { MutiSelect as default };
