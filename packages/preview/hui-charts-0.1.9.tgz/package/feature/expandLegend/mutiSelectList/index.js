function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == typeof h && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator["return"] && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(typeof e + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, "catch": function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }
import Tips from '../tips/index.js';
import { CSS_CLASS, SVG_ICON } from './constants.js';
import { uuid } from '../../../util/math.js';
import throttle from '../../../util/throttle.js';
import { getTextWidth } from '../../../util/dom.js';
import statisticsList from './statisticList.js';
import { svgTransform } from '../../../util/convert.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 节流间隔
var THROTTLE_INTERVAL = 500;

// tips文字大小
var TEXT_SIZE = 14;
var DEFAULT_OPTION = {
  data: [],
  onclick: function onclick() {},
  style: {
    sign: "circle"
  }
};
var MutiSelectList = /*#__PURE__*/function () {
  function MutiSelectList(root) {
    // 根元素
    this.root = root;

    // 数据
    this.data = null;
  }
  var _proto = MutiSelectList.prototype;
  _proto.setOption = function setOption(option) {
    option = option || DEFAULT_OPTION;

    // 主题颜色
    this.color = option.color;

    // 整个图例占父元素的高度
    this.height = option.height;

    // 图例的点击事件
    this.onclick = option.onclick;

    // 图例的一些样式
    this.itemStyle = option.itemStyle;
    this.statistics = option.statistics;
    this.initData(option.data);
    this.setResizeObserver();
  }

  // 组装数据
  ;
  _proto.initData = function initData(data) {
    this.data = [];
    if (Array.isArray(data)) {
      for (var i = 0; i < data.length; i++) {
        this.data.push({
          name: data[i]["name"] === undefined ? data[i] : data[i]["name"],
          value: data[i]["value"] === undefined ? data[i] : data[i]["value"],
          selected: data[i]["selected"] === undefined ? true : data[i]["selected"],
          color: this.color.length === 0 ? "#000" : this.color[i % this.color.length]
        });
      }
    }
  }

  // 创建列表
  ;
  _proto.create = function create(onclick) {
    var _this = this;
    var list = document.createElement("div");
    list.classList.add(CSS_CLASS.LIST);
    list.style.height = this.height;
    if (this.statistics) {
      list.style.display = "flex";
      list.style.alignItems = "center";
      list.append(statisticsList.call(this));
    } else {
      var maxWidth = this.root.getBoundingClientRect().width;
      this.data.forEach(function (data, index) {
        var _this$itemStyle, _this$itemStyle2, _this$itemStyle3;
        var item = document.createElement("div");
        item.id = CSS_CLASS.ITEM + "_" + uuid();
        item.classList.add(CSS_CLASS.ITEM);
        var icon = document.createElement("div");

        // icon是展示为线还是小圆点
        if ((_this == null ? void 0 : (_this$itemStyle = _this.itemStyle) == null ? void 0 : _this$itemStyle.icon) === "line") {
          icon.classList.add(CSS_CLASS.ICON_LINE);
        } else {
          icon.classList.add(CSS_CLASS.ICON_CIRCLE);
        }
        icon.style.background = data.color;
        var text = document.createElement("span");
        text.innerText = data.name;
        text.classList.add(CSS_CLASS.ITEM_TEXT);
        var copy = document.createElement('img');
        copy.classList.add('copy');
        if (_this != null && (_this$itemStyle2 = _this.itemStyle) != null && _this$itemStyle2.copy) {
          var svg1 = svgTransform(SVG_ICON.COPY1);
          var svg2 = svgTransform(SVG_ICON.COPY2);
          copy.src = svg1;
          copy.addEventListener('mouseover', function (e) {
            e.stopPropagation();
            copy.src = svg2;
          });
          copy.addEventListener('mouseleave', function (e) {
            e.stopPropagation();
            copy.src = svg1;
          });
          copy.addEventListener('click', /*#__PURE__*/function () {
            var _ref = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee(e) {
              var clipboard;
              return _regeneratorRuntime().wrap(function _callee$(_context) {
                while (1) switch (_context.prev = _context.next) {
                  case 0:
                    e.stopPropagation();
                    clipboard = navigator.clipboard || {
                      writeText: function writeText(text) {
                        var copyInput = document.createElement('input');
                        copyInput.value = text;
                        document.body.appendChild(copyInput);
                        copyInput.select();
                        document.execCommand('copy');
                        document.body.removeChild(copyInput);
                      }
                    };
                    if (!clipboard) {
                      _context.next = 5;
                      break;
                    }
                    _context.next = 5;
                    return clipboard.writeText(data.name);
                  case 5:
                  case "end":
                    return _context.stop();
                }
              }, _callee);
            }));
            return function (_x) {
              return _ref.apply(this, arguments);
            };
          }());
        }
        // 是否要展示tips
        if (_this != null && (_this$itemStyle3 = _this.itemStyle) != null && _this$itemStyle3.showTips) {
          if (getTextWidth(data.name, TEXT_SIZE) > maxWidth) {
            var tips = new Tips(item);
            tips.setOption({
              data: data.name,
              onclick: function onclick() {}
            });
          }
        }
        item.append(icon, text, copy);

        // 每个图例的点击事件
        item.addEventListener("click", function (e) {
          e.stopPropagation();
          icon.classList.toggle(CSS_CLASS.ICON_UNACTIVE);
          text.classList.toggle(CSS_CLASS.ITEM_UNACTIVE);
          onclick && onclick(_this.data[index]);
        });
        list.append(item);
      });
    }

    // 列表滚动时立刻销毁所有tips
    list.addEventListener("scroll", function (e) {
      e.stopPropagation();
      Tips.destoryImmediately();
    });
    this.root.append(list);
  }

  // 响应式监听
  ;
  _proto.setResizeObserver = function setResizeObserver() {
    var _this2 = this;
    this.resizeObserver = new ResizeObserver(function () {
      throttle(THROTTLE_INTERVAL, function () {
        _this2.root.innerHTML = "";
        _this2.create(_this2.onclick);
      })();
    });
    this.resizeObserver.observe(this.root);
  };
  return MutiSelectList;
}();
export { MutiSelectList as default };
