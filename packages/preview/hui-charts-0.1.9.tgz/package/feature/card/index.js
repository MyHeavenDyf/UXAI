import merge from '../../util/merge.js';
import chartToken from './chartToken.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

var cardOption = {
  title: {
    name: 'Chart name',
    size: 'small',
    tip: {
      show: false,
      content: '标题提示内容'
    }
  }
};

// 卡片容器
var CardManager = /*#__PURE__*/function () {
  function CardManager(container, option) {
    option = merge(cardOption, option);
    // 卡片容器
    this.container = container;
    // 卡片配置项
    this.option = option;
    if (this.container) {
      this.createDom();
    }
  }
  var _proto = CardManager.prototype;
  _proto.changeTheme = function changeTheme() {
    var cardContainer = this.container.querySelector('.card-operatetion');
    cardContainer.style.setProperty('--titleColor', chartToken.titleColor);
    cardContainer.style.setProperty('--labelColor', chartToken.labelColor);
    cardContainer.style.setProperty('--selectBgActive', chartToken.selectBgActive);
    cardContainer.style.setProperty('--selectBgAInactive', chartToken.selectBgAInactive);
    cardContainer.style.setProperty('--selectBgAInactive', chartToken.selectBgAInactive);
    cardContainer.style.setProperty('--selectTextDisabled', chartToken.selectTextDisabled);
    cardContainer.style.setProperty('--selectSplitLineColor', chartToken.selectSplitLineColor);
  }
  // 创建容器
  ;
  _proto.createDom = function createDom() {
    var cardContainerDom = this.container.querySelector('.card-operatetion');
    if (cardContainerDom) {
      cardContainerDom.outerHTML = '';
    }
    var titleOption = this.option.title;
    var cardContainer = document.createElement('div');
    cardContainer.setAttribute('class', 'card-operatetion');
    var cardTop = document.createElement('div');
    cardTop.className = "card-top " + (this.option.divider ? 'divider' : '');
    var cardTitle = document.createElement('div');
    cardTitle.className = "card-title " + (titleOption.size === 'large' ? 'large' : '');
    cardTitle.innerHTML = " <span>" + titleOption.name + "</span>";
    cardTop.appendChild(cardTitle);
    cardContainer.appendChild(cardTop);
    this.container.insertAdjacentHTML('afterbegin', cardContainer.outerHTML);
    var titleDom = this.container.querySelector('.card-title');
    if (titleOption.tip && titleOption.tip.show) {
      var tipStr = "<img class=\"icon-tip\" src=\"data:image/image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAOCAYAAAAfSC3RAAAABHNCSVQICAgIfAhkiAAAAMNJREFUKJF1ktF1QyEMQy/p26t+kyEm6ShP2SSZpP3BOT5uoi8wkiwMgwZJAcy9DWDtuipvfBAk2UUwgZX7UdwmcEpyT/GOc2tuLsSo8fb6zFQjDxvp2ss78C3pbGcrO9ZIAdwlncU0CmUB8wCmpDokAy6CqB0TN8DN8d8wWt1AHF1Q4ELshuvIzEl8F/kjJF097n6OXpOkX4AvgIh4AldEDNsGsP2w/ahGwA+wbLtOUzvyKu7Z8fUV884vYTNIsrsg8QeoR4CfMYMDOgAAAABJRU5ErkJggg==\" title=\"" + titleOption.tip.content + "\">";
      titleDom.insertAdjacentHTML('beforeend', tipStr);
    }
    if (this.option.renderTitle) {
      this.option.renderTitle(titleDom);
    }
    var operation = this.option.operation;
    if (operation && operation.data) {
      this.createOperation(operation);
    }
    var valueArea = this.option.valueArea;
    if (valueArea) {
      this.createValueArea(valueArea);
    }
  }

  // 创建功能区
  ;
  _proto.createOperation = function createOperation(operation) {
    var data = operation.data;
    var onChange = operation.onChange;
    var activeClass;
    var operationItem = '';
    var _loop = function _loop() {
      var type = data[i].type;
      var itemData = data[i].data;
      var active = data[i].active || 0;
      if (type === 'button') {
        var buttonItem = '';
        itemData.forEach(function (element, index) {
          if (active === index) {
            buttonItem += "<div class='item active'>" + element.text + "</div>";
          } else {
            buttonItem += "<div class='item'>" + element.text + "</div>";
          }
        });
        operationItem += "<div class=\"card " + type + "\">" + buttonItem + "</div>";
      } else if (type === 'icon-button') {
        var iconButtonItem = '';
        itemData.forEach(function (element, index) {
          activeClass = active === index ? 'active' : '';
          iconButtonItem += "<div class='item " + activeClass + "'><img src=\"" + element.path + "\" /></div>";
        });
        operationItem += "<div class=\"card " + type + "\">" + iconButtonItem + "</div>";
      } else if (type === 'icon') {
        var iconItem = '';
        itemData.forEach(function (element, index) {
          iconItem += "<div class='item'><img src=\"" + element.path + "\" /></div>";
        });
        operationItem += "<div class=\"card " + type + "\">" + iconItem + "</div>";
      }
    };
    for (var i = 0; i < data.length; i++) {
      _loop();
    }
    var OperationStr = "<div class=\"operation\">" + operationItem + "</div>";
    this.container.querySelector('.card-top').insertAdjacentHTML('beforeend', OperationStr);
    var OperationDom = this.container.querySelector('.operation');
    for (var i = 0; i < OperationDom.children.length; i++) {
      this.OperationBind(OperationDom.children[i], data[i], onChange);
    }
    if (this.option.renderOperation) {
      this.option.renderOperation(OperationDom);
    }
  }

  // 功能区事件绑定
  ;
  _proto.OperationBind = function OperationBind(OperationDom, data, onChange) {
    var children = OperationDom.children;
    for (var i = 0; i < children.length; i++) {
      children[i].index = i;
      children[i].addEventListener('click', function (e) {
        if (data.type !== 'icon') {
          for (var j = 0; j < children.length; j++) {
            children[j].classList.remove('active');
          }
          e.currentTarget.classList.add('active');
        }
        onChange(data.data, this.index);
      });
    }
  }

  // 创建关键数值区域
  ;
  _proto.createValueArea = function createValueArea(valueArea) {
    var data = valueArea.data;
    var valueAreaDiv = document.createElement('div');
    valueAreaDiv.setAttribute('class', 'valueArea');
    if (data && data.length > 0) {
      for (var i = 0; i < data.length; i++) {
        var itemDiv = document.createElement('div');
        itemDiv.setAttribute('class', 'item');
        var mainDiv = document.createElement('div');
        mainDiv.innerHTML = "<span class=\"value\">" + data[i].value + "</span><span class=\"unit\">" + data[i].unit + "</span>";
        itemDiv.appendChild(mainDiv);
        var subDiv = document.createElement('div');
        subDiv.setAttribute('class', 'sub');
        subDiv.innerHTML = "" + data[i].desc;
        itemDiv.appendChild(subDiv);
        valueAreaDiv.appendChild(itemDiv);
      }
      var containerDom = this.container.querySelector('.card-operatetion');
      containerDom.insertAdjacentHTML('beforeend', valueAreaDiv.outerHTML);
      containerDom.classList.add('adaptation-bottom');
      var valueAreaDom = this.container.querySelector('.valueArea');
      if (this.option.renderValueArea) {
        return this.option.renderValueArea(valueAreaDom);
      }
    }
  }

  // 获取容器节点
  ;
  _proto.getContainer = function getContainer() {
    return this.container;
  }

  // 获取关键值
  ;
  _proto.getValue = function getValue() {
    var valueArr = [];
    var valueAreaDom = this.container.querySelector('.valueArea');
    var childrenItem = valueAreaDom.children;
    for (var i = 0; i < childrenItem.length; i++) {
      valueArr.push(childrenItem[i].querySelector('.value').innerHTML);
    }
    return valueArr;
  }

  // 更新关键值
  ;
  _proto.setValue = function setValue(value, index) {
    var valueAreaDom = this.container.querySelector('.valueArea');
    var childrenItem = valueAreaDom.children;
    if (Array.isArray(value)) {
      for (var i = 0; i < childrenItem.length; i++) {
        childrenItem[i].querySelector('.value').innerHTML = value[i];
      }
    } else {
      var valueDom = childrenItem[index + 1].querySelector('.value');
      valueDom.innerHTML = value;
    }
  }

  // 销毁实例,
  ;
  _proto.unInstall = function unInstall() {
    this.container.innerHTML = null;
  };
  return CardManager;
}();
export { CardManager as default };
