/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var escapeScript = function escapeScript(string) {
  var str = string.replace('<script>', '').replace('</script>', '');
  return str;
};
var defendScript = function defendScript(obj) {
  if (typeof obj === 'string') {
    return escapeScript(obj);
  } else if (typeof obj === 'number') {
    return obj;
  } else if (typeof obj === 'object') {
    for (var key in obj) {
      if (Object.hasOwnProperty.call(obj, key)) {
        var xssKey = defendScript(key);
        var xssValue = defendScript(obj[key]);
        delete obj[key];
        obj[xssKey] = xssValue;
      }
    }
    return obj;
  } else {
    return obj;
  }
};

/**
 * 对图表option的键值对进行过滤限制
 */
var xssOption = function xssOption(option) {
  for (var key in option) {
    if (Object.hasOwnProperty.call(option, key)) {
      var xssKey = defendScript(key);
      var xssValue = defendScript(option[key]);
      delete option[key];
      option[xssKey] = xssValue;
    }
  }
  return option;
};
export { xssOption as default };
