import { isArray } from './type.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 插入HTML元素
var appendHTML = function appendHTML(dom, child) {
  dom.insertAdjacentHTML('beforeend', child);
};

// 插入dom元素
var appendDom = function appendDom(dom, child) {
  dom.insertAdjacentElement('beforeend', child);
};

// 创建元素
var createDom = function createDom(name) {
  return document.createElementNS('http://www.w3.org/2000/svg', name);
};

// 元素绑定样式
var setStyle = function setStyle(dom, option) {
  for (var i in option) {
    if (Object.hasOwnProperty.call(option, i)) {
      dom.setAttribute(i, option[i]);
    }
  }
};

//给指定dom添加class类名，classList为数组类型
function addClass(dom, classes) {
  if (isArray(classes)) {
    classes.forEach(function (cls) {
      dom.classList.add(cls);
    });
  } else {
    dom.classList.add(classes);
  }
}

//给指定dom添加或更改属性
function attr(dom, key, value) {
  dom.setAttribute(key, value);
}

// 判断父元素是否为指定的 class
var isParent = function isParent(targetElement, parentClass) {
  if (targetElement === document.body) {
    return false;
  } else if (targetElement.parentNode.classList.contains(parentClass)) {
    return targetElement.parentNode;
  } else {
    return isParent(targetElement.parentNode, parentClass);
  }
};

// 计算一段字符的像素长度
var getTextWidth = function getTextWidth(text, fontSize) {
  if (fontSize === void 0) {
    fontSize = 12;
  }
  var result = 0;
  var ele = document.createElement('span');
  // 字符串中带有换行符时，会被自动转换成<br/>标签，若需要考虑这种情况，可以替换成空格，以获取正确的宽度
  ele.innerText = text;
  // 不同的大小和不同的字体都会导致渲染出来的字符串宽度变化，可以传入尽可能完备的样式信息
  ele.setAttribute('style', "font-size: " + fontSize + "px");
  document.documentElement.append(ele);
  result = ele.offsetWidth;
  document.documentElement.removeChild(ele);
  return result;
};

// 计算一段字符的像素高度
var getTextHeight = function getTextHeight(text, fontSize, lineHeight, padding) {
  if (fontSize === void 0) {
    fontSize = 12;
  }
  var result = 0;
  var ele = document.createElement('div');
  ele.style.fontSize = fontSize + "px";
  if (lineHeight) ele.style.lineHeight = lineHeight + "px";
  if (padding !== undefined) {
    if (typeof padding === 'number') {
      ele.style.padding = padding + "px";
    } else if (Array.isArray(padding)) {
      if (padding.length === 2) {
        ele.style.padding = padding[0] + "px " + padding[1] + "px";
      } else if (padding.length === 4) {
        ele.style.padding = padding[0] + "px " + padding[1] + "px " + padding[2] + "px " + padding[3] + "px";
      }
    }
  }
  // 使用 white-space: pre-wrap 来保留空白符并正常换行
  ele.style.whiteSpace = 'pre-wrap';
  ele.innerHTML = text;
  document.documentElement.append(ele);
  result = ele.offsetHeight;
  document.documentElement.removeChild(ele);
  return result;
};
function removeOuterSpaces(text) {
  // 使用正则表达式仅移除 { 和 } 前后所有的空格字符
  return text.replace(/[ ]*([{}])[ ]*/g, '$1').trim();
}
export { addClass, appendDom, appendHTML, attr, createDom, getTextHeight, getTextWidth, isParent, removeOuterSpaces, setStyle };
