/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var HashMap = /*#__PURE__*/function () {
  function HashMap(initObj) {
    this.data = void 0;
    this.data = newMap();
    for (var key in initObj) {
      if (Object.hasOwnProperty.call(initObj, key)) {
        this.set(key, initObj[key]);
      }
    }
  }
  var _proto = HashMap.prototype;
  _proto.hasKey = function hasKey(key) {
    return this.data.has(key);
  };
  _proto.get = function get(key) {
    return this.data.get(key);
  };
  _proto.set = function set(key, value) {
    this.data.set(key, value);
    return value;
  };
  _proto.each = function each(callback, context) {
    this.data.forEach(function (value, key) {
      callback.call(context, value, key);
    });
  };
  _proto.keys = function keys() {
    var keys = this.data.keys();
    return typeof Map === 'function' ? Array.from(keys) : keys;
  };
  _proto.removeKey = function removeKey(key) {
    this.data["delete"](key);
  };
  return HashMap;
}();
function newMap() {
  return typeof Map === 'function' ? new Map() : new MapPolyfill();
}
var MapPolyfill = /*#__PURE__*/function () {
  function MapPolyfill() {
    this.data = void 0;
  }
  var _proto2 = MapPolyfill.prototype;
  _proto2["delete"] = function _delete(key) {
    var existed = this.has(key);
    if (existed) {
      delete this.data[key];
    }
    return existed;
  };
  _proto2.has = function has(key) {
    return Object.hasOwnProperty.call(this.data, key);
  };
  _proto2.get = function get(key) {
    return this.data[key];
  };
  _proto2.set = function set(key, value) {
    this.data[key] = value;
    return this;
  };
  _proto2.keys = function keys() {
    return _keys(this.data);
  };
  _proto2.forEach = function forEach(callback) {
    var data = this.data;
    for (var key in data) {
      if (Object.hasOwnProperty.call(data, key)) {
        callback(data[key], key);
      }
    }
  };
  return MapPolyfill;
}();
function _keys(obj) {
  if (!obj) {
    return [];
  }
  if (Object.keys) {
    return Object.keys(obj);
  }
  var keyList = [];
  for (var key in obj) {
    if (Object.hasOwnProperty.call(obj, key)) {
      keyList.push(key);
    }
  }
  return keyList;
}
export { HashMap as default };
