import Animate from './Animate.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var AnimationGroup = /*#__PURE__*/function () {
  function AnimationGroup(options) {
    this.tasks = [];
    this.end = false;
    this.onFinishCallback = void 0;
    this.animate = void 0;
    // 更新后回调
    this.onAfterUpdate = function () {};
    this.onFinishCallback = (options == null ? void 0 : options.onFinish) || this.onFinishCallback;
    this.onAfterUpdate = (options == null ? void 0 : options.onAfterUpdate) || this.onAfterUpdate;
  }
  // 增加任务
  var _proto = AnimationGroup.prototype;
  _proto.add = function add(element, options) {
    this.end = false;
    options.onUpdate = options.onUpdate || this.onUpdate;
    var animate = new Animate(options, element);
    this.tasks[animate.getId()] = animate;
  }

  // 开始任务
;
  _proto.start = function start() {
    for (var key in this.tasks) {
      if (Object.hasOwnProperty.call(this.tasks, key)) {
        var element = this.tasks[key];
        element == null ? void 0 : element.start();
      }
    }
    this.step();
  }

  // 结束任务
;
  _proto.stop = function stop() {
    for (var key in this.tasks) {
      if (Object.hasOwnProperty.call(this.tasks, key)) {
        var element = this.tasks[key];
        element == null ? void 0 : element.stop();
      }
    }
  }

  // 循环
;
  _proto.step = function step(time) {
    var _this = this;
    !this.end && requestAnimationFrame(function (timestamp) {
      _this.step(timestamp);
    });
    this.end = !this.update(time);
  }

  // 删除所有任务
;
  _proto.removeAll = function removeAll() {
    this.tasks = {};
  }

  // 删除任务
;
  _proto.remove = function remove(tasks) {
    for (var index = 0; index < tasks.length; index++) {
      var task = tasks[index];
      task.group = undefined;
      delete this.tasks[task.getId()];
    }
  }

  // 如果组中的所有任务都未暂停或播放，则返回true
;
  _proto.allStopped = function allStopped() {
    return this.getAll().every(function (task) {
      return !task.isPlaying();
    });
  }

  // 更新任务
;
  _proto.update = function update(time, preserve, element) {
    if (time === void 0) {
      time = performance.now();
    }
    if (preserve === void 0) {
      preserve = true;
    }
    var taskIds = Object.keys(this.tasks);
    if (taskIds.length === 0) return true;
    var statusPool = [];
    // 动画是批量更新的
    if (taskIds.length > 0) {
      // 循环所有动画，更新对应位置
      for (var i = 0; i < taskIds.length; i++) {
        var task = this.tasks[taskIds[i]];
        var autoStart = !preserve;
        var status = task && task.update(time, autoStart) === false; // 是否已完成
        statusPool.push(status);
        if (status && !preserve) {
          // 已完成则删除当前任务
          this.remove(task);
        }
      }
    }
    this.onAfterUpdate();
    var isEnd = !statusPool.includes(false);
    isEnd && this.onFinishCallback && this.onFinishCallback();
    // 返回该动画组任务完成状态
    return !isEnd;
  };
  // 默认更新节点方法
  _proto.onUpdate = function onUpdate(params, elapsed, element) {
    if (element) {
      var s = element.style;
      s.position = 'absolute';
      var matchUnit = {
        'font-size': 'px',
        'line-height': 'px',
        'rotate': 'deg',
        'width': 'px',
        'height': 'px',
        'left': 'px',
        'top': 'px',
        'bottom': 'px',
        'right': 'px'
      };
      for (var key in params) {
        if (Object.hasOwnProperty.call(params, key)) {
          s[key] = matchUnit[key] ? params[key] + matchUnit[key] : params[key];
        }
      }
    }
  };
  return AnimationGroup;
}();
export { AnimationGroup as default };
