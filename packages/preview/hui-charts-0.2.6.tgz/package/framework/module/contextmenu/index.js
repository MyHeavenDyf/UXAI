function _createForOfIteratorHelperLoose(r, e) { var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (t) return (t = t.call(r)).next.bind(t); if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var o = 0; return function () { return o >= r.length ? { done: !0 } : { done: !1, value: r[o++] }; }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var TRIGGER_CLASSNAMES = ['huicharts-node', 'huicharts-line-wrap', 'huicharts-legend-itemContainer', 'huicharts-container'];
var IGNORE_CONTAINER_CLASS = 'huicharts-legend-container';
var Contextmenu = /*#__PURE__*/function () {
  function Contextmenu(context, menuOption) {
    this.showMenu = false;
    this.context = context;
    this.menuOption = menuOption; // 配置对象
    this.handleShow = this.updateMenu.bind(this);
    this.handleClose = this.closeContextmenu.bind(this);
    this.bindEvent();
  }
  var _proto = Contextmenu.prototype;
  _proto.bindEvent = function bindEvent() {
    this.context.root.addEventListener('contextmenu', this.handleShow);
  };
  _proto.uninstall = function uninstall() {
    this.showMenu = false;
    this.context.root.removeEventListener('click', this.handleClose);
    document.removeEventListener('click', this.handleClose);
    this.context.root.removeEventListener('contextmenu', this.handleShow);
  };
  _proto.updateMenu = function updateMenu(event) {
    event.preventDefault();
    // 判断触发器的class集合
    var clsNames = new Set(TRIGGER_CLASSNAMES);
    var menuOption = this.menuOption;
    event.target;
    var currentEl = event.target;
    var targetCls = '';
    while (currentEl) {
      var _currentEl$getAttribu;
      var currClsNames = ((_currentEl$getAttribu = currentEl.getAttribute("class")) == null ? void 0 : _currentEl$getAttribu.split(' ')) || [];
      targetCls = currClsNames.filter(function (name) {
        return clsNames.has(name);
      })[0];
      if (targetCls || currentEl === document.body) {
        break;
      }
      if (currClsNames.some(function (name) {
        return name === IGNORE_CONTAINER_CLASS;
      })) {
        this.closeContextmenu(event);
        return false; // 右键在图例的空白区域
      }
      currentEl = currentEl.parentNode;
    }
    var menu = undefined;
    var targetId = undefined;
    if (targetCls === 'huicharts-node') {
      menu = menuOption.node;
      targetId = currentEl.getAttribute('id');
    } else if (targetCls === 'huicharts-line-wrap') {
      var _currentEl$children$;
      menu = menuOption.line;
      targetId = (_currentEl$children$ = currentEl.children[0]) == null ? void 0 : _currentEl$children$.getAttribute('id');
    } else if (targetCls === 'huicharts-legend-itemContainer') {
      menu = menuOption.legend;
      targetId = currentEl.getAttribute('id');
    } else if (targetCls === 'huicharts-container') {
      menu = menuOption.canvas;
      targetId = 'huicharts-container';
    }
    if (menu) {
      this.closeContextmenu(event);
      this.context.root.addEventListener('click', this.handleClose);
      document.addEventListener('click', this.handleClose);
      this.createMenuElement(event, menu, targetId);
      this.showMenu = true;
    }
  }

  // 创建menu元素
;
  _proto.createMenuElement = function createMenuElement(event, menuObj, targetId) {
    var _this = this;
    var ulElement = document.createElement("ul");
    ulElement.classList.add("huicharts-contextmenu");
    if (Array.isArray(menuObj.data)) {
      var _loop = function _loop() {
        var item = _step.value;
        var liElement = document.createElement("li");
        if (menuObj.itemRender) {
          var renderElement = menuObj.itemRender(item, targetId);
          if (renderElement instanceof Node) {
            liElement.appendChild(renderElement);
          } else {
            liElement.innerHTML = renderElement;
          }
        } else {
          if (item.icon) {
            liElement.innerHTML = "<img class=\"menu-icon\" src=\"" + item.icon + "\" alt=\"\" />";
          }
          liElement.innerHTML += "<span class=\"menu-text\">" + item.label + "</span> ";
        }
        liElement.classList.add("huicharts-contextmenu-item");
        liElement.onclick = function (event) {
          event.stopPropagation();
          menuObj.onclick == null ? void 0 : menuObj.onclick(item, targetId, event);
          _this.closeContextmenu(event);
        };
        ulElement.appendChild(liElement);
      };
      for (var _iterator = _createForOfIteratorHelperLoose(menuObj.data), _step; !(_step = _iterator()).done;) {
        _loop();
      }
    }
    this.context.root.appendChild(ulElement);
    this.adjustMenuPosition(event, ulElement);
  }

  // 调整menu展示的位置
;
  _proto.adjustMenuPosition = function adjustMenuPosition(event, menuContainerEl) {
    var root = this.context.root; //  图表根容器
    var _root$getBoundingClie = root.getBoundingClientRect(),
      rootWidth = _root$getBoundingClie.width,
      rootHeight = _root$getBoundingClie.height,
      rootLeft = _root$getBoundingClie.left,
      rootTop = _root$getBoundingClie.top;
    var menuWidth = menuContainerEl.offsetWidth,
      menuHeight = menuContainerEl.offsetHeight;
    var _ref = this.menuOption.offset || [4, 4],
      _ref$ = _ref[0],
      offsetX = _ref$ === void 0 ? 4 : _ref$,
      _ref$2 = _ref[1],
      offsetY = _ref$2 === void 0 ? 4 : _ref$2; // 菜单容器偏移量
    var left = event.clientX - rootLeft + offsetX;
    var top = event.clientY - rootTop + offsetY;
    if (left + menuWidth > rootWidth) {
      // 右侧超出，向左移位
      left = rootWidth - menuWidth - offsetX;
    }
    if (top + menuHeight > rootHeight) {
      // 底部超出，向上移位
      top = rootHeight - menuHeight - offsetY;
    }
    menuContainerEl.setAttribute('style', "position: absolute; top:  " + top + "px; left:  " + left + "px;");
  };
  _proto.closeContextmenu = function closeContextmenu(event) {
    if (!this.showMenu) {
      return;
    }
    event == null ? void 0 : event.stopPropagation();
    this.showMenu = false;
    var contextmenu = this.context.root.querySelectorAll('.huicharts-contextmenu');
    contextmenu.forEach(function (el) {
      el.parentNode.removeChild(el);
    });
    this.context.root.removeEventListener('click', this.handleClose);
    document.removeEventListener('click', this.handleClose);
  };
  return Contextmenu;
}();
export { Contextmenu as default };
