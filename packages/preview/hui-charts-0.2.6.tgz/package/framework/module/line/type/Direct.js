/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
// 直连线
var Direct = /*#__PURE__*/function () {
  function Direct() {}
  var _proto = Direct.prototype;
  _proto.creatPath = function creatPath(data) {
    var startConnector = data.startConnector,
      endConnector = data.endConnector;
    var m = "M" + startConnector.absolute.x + " " + startConnector.absolute.y;
    var l = "L" + endConnector.absolute.x + " " + endConnector.absolute.y;
    return m + " " + l;
  };
  return Direct;
}();
export { Direct as default };
