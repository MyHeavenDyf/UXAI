/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
// 椭圆连线
var Ellipse = /*#__PURE__*/function () {
  function Ellipse(option) {
    // 椭圆曲线控制点
    this.EllipseDistance = 0.6;
    this.EllipseDistance = option.lineOption.EllipseDistance || 0.6;
  }
  var _proto = Ellipse.prototype;
  _proto.creatPath = function creatPath(data, option) {
    var _option$layout;
    function getCircleLineIntersection(x1, y1, x2, y2, radius) {
      // 计算直线斜率和截距
      var k = (y2 - y1) / (x2 - x1);
      var b = y1 - k * x1;
      var A = 1 + k * k;
      var B = 2 * k * (b - y1) - 2 * x1;
      var C = x1 * x1 + (b - y1) * (b - y1) - radius * radius;
      var discriminant = B * B - 4 * A * C;
      if (discriminant < 0) {
        return null; // 没有交点或相切于一点
      } else if (discriminant === 0) {
        // 相切于一点的情况（理论上只有一个交点）
        var x = (-B + Math.sqrt(discriminant)) / (2 * A);
        var y = k * x + b;
        return [{
          x: x,
          y: y
        }]; // 返回一个交点坐标数组
      } else {
        // 两个交点的情况
        var sqrtTerm = Math.sqrt(discriminant);
        var _x = (-B + sqrtTerm) / (2 * A);
        var _y = k * _x + b;
        var _x2 = (-B - sqrtTerm) / (2 * A);
        var _y2 = k * _x2 + b;
        return [{
          x: _x,
          y: _y
        }, {
          x: _x2,
          y: _y2
        }]; // 返回两个交点坐标数组
      }
    }
    var startConnector = data.startConnector,
      endConnector = data.endConnector;
    var x1 = startConnector.absolute.x;
    var y1 = startConnector.absolute.y;
    var x2 = endConnector.absolute.x;
    var y2 = endConnector.absolute.y;
    var middleX = (x2 + x1) / 2;
    var middleY = (y2 + y1) / 2;
    var pointX;
    var pointY;
    var xDiff = x2 - x1;
    var yDiff = y2 - y1;
    var distance = Math.hypot(xDiff, yDiff);
    if ((option == null ? void 0 : (_option$layout = option.layout) == null ? void 0 : _option$layout.type) == 'circle') {
      var _option$layout2, _option$layout3, _option$layout4, _option$layout5, _option$layout6, _option$layout7;
      var circleX = option != null && (_option$layout2 = option.layout) != null && _option$layout2.center ? option == null ? void 0 : (_option$layout3 = option.layout) == null ? void 0 : _option$layout3.center[0] : 0;
      var circleY = option != null && (_option$layout4 = option.layout) != null && _option$layout4.center ? option == null ? void 0 : (_option$layout5 = option.layout) == null ? void 0 : _option$layout5.center[1] : 0;
      var circleR = option != null && (_option$layout6 = option.layout) != null && _option$layout6.radian ? option == null ? void 0 : (_option$layout7 = option.layout) == null ? void 0 : _option$layout7.radian : 400; //值越大弧线越长
      var pointArr = getCircleLineIntersection(middleX, middleY, circleX, circleY, circleR);
      if (middleX < circleX) {
        pointX = pointArr[0].x;
        pointY = pointArr[0].y;
      } else {
        pointX = pointArr[1].x;
        pointY = pointArr[1].y;
      }
    } else {
      pointX = x2 - xDiff / 2, pointY = yDiff > 0 ? y2 + this.EllipseDistance * distance : y2 - this.EllipseDistance * distance;
    }
    var M = "M" + x1 + " " + y1;
    var Q = "Q" + pointX + " " + pointY + " " + x2 + " " + y2;
    var path = M + " " + Q;
    return path;
  };
  return Ellipse;
}();
export { Ellipse as default };
