import Line from './index.js';
import Customize from './customize.js';
import LineLayout from '../lineLayout/index.js';
import merge from '../../../util/merge.js';
import bufferRender from './bufferRender.js';
import ArrowManager from '../arrow/Manager.js';
import ConnectorManager from '../connector/Manager.js';
import Animation from '../animation/Animation.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

var DEFAULT_LINE = {
  type: 'Round',
  style: {
    width: 1,
    radius: 0,
    mode: 'solid',
    color: '#c2c2c2',
    hover: {
      color: '#2070F3'
    },
    active: {},
    disable: {}
  },
  endMarker: {
    size: 8,
    type: 'block',
    color: '#c2c2c2'
  }
};
var LineManager = /*#__PURE__*/function () {
  function LineManager(option, container, chartInstance) {
    // 线管理器工厂
    this.instance = {};
    this.canvasContainter = void 0;
    // 再次全部渲染线的延迟时间（等待节点渲染动效完成）
    this.RE_CREATE_TIME = 500;
    this.getData = function () {
      return this.instance;
    };
    this.update = function (line) {
      var _this$instance$line$i;
      (_this$instance$line$i = this.instance[line.id]) == null ? void 0 : _this$instance$line$i.update(line);
    };
    this.hide = function (line) {
      var _this$instance$line$i2;
      (_this$instance$line$i2 = this.instance[line.id]) == null ? void 0 : _this$instance$line$i2.hide(line);
    };
    this.option = option;
    this.container = container;
    this.chartInstance = chartInstance;
    this.gContainer = this.getGContainer();
    this.canvasContainter = this.container.parentNode;
    this.animationContainter = this.getAnimationContainer();
  }
  var _proto = LineManager.prototype;
  _proto.init = function init(option) {
    var lineOpt = merge(DEFAULT_LINE, option.line);
    this.lineOption = lineOpt;
    this.onClick = lineOpt.onClick;
    this.onHover = lineOpt.onHover;
    this.ArrowManager = new ArrowManager(lineOpt, this.container);
  }

  // 根据edges生成连接点
;
  _proto.layout = function layout(nodeManager) {
    this.nodeManager = nodeManager;
    this.relationData = nodeManager.getData();
    new LineLayout(this.relationData, this.option);
    this.connectorManager = new ConnectorManager(this.chartInstance, this.relationData.edges, this.option);
    this.init(this.option);
    this.createLineData(this.option.data, this.option);
  }

  // 刷新连线
;
  _proto.relayout = function relayout(option) {
    var _this = this;
    // 此时的节点数据中，x,y.width,height为最新值，其他数据是老的，数量也是最新的（经过了增删改查）
    var currentNodePosition = this.nodeManager.getCurrentPosition();
    this.currentRelationData = {
      nodes: [],
      edges: this.nodeManager.getData().edges
    };
    for (var i in currentNodePosition) {
      this.currentRelationData.nodes.push(currentNodePosition[i]);
    }
    // this.nodeManager.getData(); 要加id
    this.relationData.edges.forEach(function (line) {
      _this.currentRelationData.edges.forEach(function (edge, i) {
        if (edge.start == line.start && edge.end == line.end) {
          _this.currentRelationData.edges[i] = line;
        }
      });
    });
    new LineLayout(this.currentRelationData, option);
    // this.init(option);
    this.connectorManager.refresh(this, this.currentRelationData.edges, option);
    this.createLineData(this.currentRelationData, option);
  }

  // 绘制自定义连线
;
  _proto.renderCustom = function renderCustom(option, svgContainer) {
    // nodeManager 好像没用了
    new LineLayout(option.data, option);
    this.customizeData = option.data;
    // customizeData 就是自定义的连线的数据,nodes和edges
    this.createLineData(this.customizeData, option);
    // render
    var lineOpt = merge(DEFAULT_LINE, option.line);
    option.duration = this.RE_CREATE_TIME;
    var customizeArrow = new ArrowManager(lineOpt, this.container);
    Customize({
      data: this.customizeData,
      option: option,
      ArrowManager: customizeArrow,
      svgContainer: svgContainer
    });
  }

  // 将点的原始数据，转换成线的数据格式
;
  _proto.createLineData = function createLineData(data, option) {
    var nodeData = {};
    data.nodes.forEach(function (node) {
      nodeData[node.id] = node;
    });
    data.edges.forEach(function (edge, i) {
      var _nodeData$start, _nodeData$start2, _nodeData$end, _nodeData$end2;
      var startConnector = edge.startConnector,
        endConnector = edge.endConnector,
        end = edge.end,
        start = edge.start;
      if (!nodeData[start] || !nodeData[end]) {
        delete data.edges[i];
      }
      var id = startConnector.id + "-to-" + endConnector.id;
      edge.id = id;
      edge.startConnector.absolute = {
        x: startConnector.x + ((_nodeData$start = nodeData[start]) == null ? void 0 : _nodeData$start.x),
        y: startConnector.y + ((_nodeData$start2 = nodeData[start]) == null ? void 0 : _nodeData$start2.y)
      };
      edge.endConnector.absolute = {
        x: endConnector.x + ((_nodeData$end = nodeData[end]) == null ? void 0 : _nodeData$end.x),
        y: endConnector.y + ((_nodeData$end2 = nodeData[end]) == null ? void 0 : _nodeData$end2.y)
      };
      var lineStyle = merge(DEFAULT_LINE, option.line);
      edge.lineOption = lineStyle;
    });
  };
  _proto.render = function render() {
    var _this$option$layout,
      _this2 = this;
    var containerRect = this.container.getBoundingClientRect();
    this.canvasContainterRect = this.canvasContainter.getBoundingClientRect();
    this.containerCenter = {
      x: containerRect.width / 2,
      y: containerRect.height / 2
    };
    if ((_this$option$layout = this.option.layout) != null && _this$option$layout.bufferRender) {
      // 执行局部渲染方法
      this.relationData.edges.forEach(function (edge) {
        _this2.bufferRenderLine(edge, _this2.option);
      });
    } else {
      // 执行全局渲染方法
      this.relationData.edges.forEach(function (edge) {
        _this2.renderLine(edge, _this2.option);
      });
    }
  }

  // 局部渲染连线方法
;
  _proto.bufferRenderLine = function bufferRenderLine(edge, option) {
    // edge里会配置单根线MergeOption，需要合并一下 todo
    this.instance[edge.id] = new Line(edge, this.ArrowManager, option);
    // 使用初始偏移 (0, 0) 进行首次渲染
    var path = bufferRender(this.instance[edge.id], {
      scale: 1,
      lastScale: 1,
      offset: {
        x: 0,
        y: 0
      },
      center: this.containerCenter
    }, this.gContainer, this.canvasContainterRect); // TODO 初始渲染可能缩放值不是1
    if (this.instance[edge.id].hasRender) {
      this.bindEvent(this.instance[edge.id], path);
    }
  }

  // 全局渲染连线方法
;
  _proto.renderLine = function renderLine(line, option) {
    this.instance[line.id] = new Line(line, this.ArrowManager, option);
    var path = this.instance[line.id].render();
    this.bindEvent(this.instance[line.id], path);
    this.gContainer.appendChild(path);
  };
  _proto.bindEvent = function bindEvent(lineInstance, path) {
    var _lineInstance$style;
    if (this.onClick || this.lineOption.active) {
      lineInstance.bindEvent(path, 'click', this.onClick);
    }
    if (this.onHover || this.lineOption.hover) {
      lineInstance.bindEvent(path, 'hover', this.onHover);
    }
    // 绑定连线由短变长的动效
    lineInstance.animation({
      type: 'grow',
      duration: this.RE_CREATE_TIME,
      path: path,
      lineMode: (_lineInstance$style = lineInstance.style) == null ? void 0 : _lineInstance$style.mode
    });
  }

  // 外部触发局部渲染回调
;
  _proto.onBufferRender = function onBufferRender(params) {
    var _this$option$layout2;
    if (!((_this$option$layout2 = this.option.layout) != null && _this$option$layout2.bufferRender)) return;
    for (var id in this.instance) {
      bufferRender(this.instance[id], params, this.gContainer, this.canvasContainterRect);
    }
  };
  // 重新刷新连线，伴随动画
  _proto.refresh = function refresh(option) {
    var self = this;
    var animation = new Animation(null, {
      start: {
        x: 0,
        y: 0
      },
      end: {
        x: 100,
        y: 100
      },
      duration: 600,
      onUpdate: function onUpdate() {
        self.relayout(option);
        self.reUpdate(option);
      }
    });
    animation.start();
  }

  // 对比前后差异，重新刷新连线, this.currentRelationData 是新数据， this.instance是老线数据
;
  _proto.reUpdate = function reUpdate(option) {
    var _this3 = this;
    var newIds = [];
    var oldIds = [];
    this.currentRelationData.edges.forEach(function (edge) {
      newIds.push(edge.id);
      if (_this3.isExist(edge.id)) {
        _this3.update(edge);
      } else {
        _this3.renderLine(edge, option);
      }
    });
    oldIds = Object.keys(this.instance);
    oldIds.forEach(function (id) {
      if (newIds.indexOf(id) == -1) {
        _this3.unmount(id);
      }
    });
  }

  // 全部删除旧连线，创建新的连线
;
  _proto.reCreate = function reCreate(nodeManager, option) {
    var _this4 = this;
    for (var i in this.instance) {
      this.unmount(i);
    }
    this.instance = {};
    setTimeout(function () {
      _this4.relationData = nodeManager.getData();
      new LineLayout(_this4.relationData, option);
      _this4.createLineData(_this4.relationData, option);
      _this4.connectorManager.reCreate(_this4, _this4.relationData.edges, option);
      _this4.render();
    }, this.RE_CREATE_TIME);
  }

  // 是否在原线管理器中
;
  _proto.isExist = function isExist(id) {
    return this.instance[id];
  };
  _proto.getLine = function getLine(id) {
    return this.instance[id];
  };
  _proto.getGContainer = function getGContainer() {
    return this.container.getElementsByClassName("huicharts-lines-g")[0];
  };
  _proto.getAnimationContainer = function getAnimationContainer() {
    return this.container.parentNode.getElementsByClassName("huicharts-animation-container")[0];
  };
  _proto.unmount = function unmount(id) {
    this.instance[id].unmount(id);
    delete this.instance[id];
  };
  return LineManager;
}();
export { LineManager as default };
