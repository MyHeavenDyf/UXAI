/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var VDirection = ['TB', 'BT', 'V'];
var HDirection = ['LR', 'RL', 'H'];
var START = 'start';
var END = 'end';
var Direction = {
  'T': 'top',
  'L': 'left',
  'R': 'right',
  'B': 'bottom'
};
function countPosition(startNode, endNode, direction) {
  var startNodeStartPoint, startNodeEndPoint, endNodeStartPoint, endNodeEndPoint;
  if (direction === 'H') {
    startNodeStartPoint = startNode.x;
    startNodeEndPoint = startNode.x + startNode.width;
    endNodeStartPoint = endNode.x;
    endNodeEndPoint = endNode.x + endNode.width;
  } else {
    startNodeStartPoint = startNode.y;
    startNodeEndPoint = startNode.y + startNode.height;
    endNodeStartPoint = endNode.y;
    endNodeEndPoint = endNode.y + endNode.height;
  }
  // 起始节点左右分别与终止节点左右的距离
  var distanceArr = [Math.abs(startNodeStartPoint - endNodeStartPoint), Math.abs(startNodeStartPoint - endNodeEndPoint), Math.abs(startNodeEndPoint - endNodeStartPoint), Math.abs(startNodeEndPoint - endNodeEndPoint)];
  // 获取最小距离
  var minDistance = Math.min.apply(Math, distanceArr);
  var positionArrH = [{
    start: 'left',
    end: 'left'
  }, {
    start: 'left',
    end: 'right'
  }, {
    start: 'right',
    end: 'left'
  }, {
    start: 'right',
    end: 'right'
  }];
  var positionArrV = [{
    start: 'top',
    end: 'top'
  }, {
    start: 'top',
    end: 'bottom'
  }, {
    start: 'bottom',
    end: 'top'
  }, {
    start: 'bottom',
    end: 'bottom'
  }];
  var positionArr = direction === 'H' ? positionArrH : positionArrV;
  return positionArr[distanceArr.indexOf(minDistance)];
}
function init(data, option, nodeObj) {
  var _option$layout;
  var originalDirection;
  var direction = originalDirection = (option == null ? void 0 : (_option$layout = option.layout) == null ? void 0 : _option$layout.direction) || VDirection[0];
  if (direction === VDirection[2]) direction = VDirection[0];
  if (direction === HDirection[2]) direction = HDirection[0];
  var startPosition = Direction[direction[0]];
  var endPosition = Direction[direction[1]];

  // let initLineData = [];
  data.edges.forEach(function (edge) {
    if (!edge.start || !edge.end) return;
    edge.startConnector = edge.startConnector || {
      port: START,
      nodeId: edge.start,
      position: endPosition
    };
    edge.endConnector = edge.endConnector || {
      port: END,
      nodeId: edge.end,
      position: startPosition
    };
    if (originalDirection === 'H' || originalDirection === 'V') {
      var startNode = nodeObj[edge.start];
      var endNode = nodeObj[edge.end];
      var positions = countPosition(startNode, endNode, originalDirection);
      edge.startConnector.position = positions.start;
      edge.endConnector.position = positions.end;
    }
  });
}
export { init as default };
