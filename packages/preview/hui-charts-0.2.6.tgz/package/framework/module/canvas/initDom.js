import Grid from './grid.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

var svgContainer = "<svg class=\"huicharts-lines-container\" xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\" width=\"100%\" height=\"100%\">\n        <defs></defs><g class=\"huicharts-lines-g\"></g>\n     </svg>";
var svgSecondContainer = "<svg class=\"huicharts-second-lines-container\" xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\" width=\"100%\" height=\"100%\">\n        <defs></defs><g class=\"huicharts-second-lines-g\"></g>\n    </svg>";
function initDom(dom, option) {
  var _option$grid;
  // 画布最外层根容器
  var root = document.createElement('div');
  root.setAttribute('class', 'huicharts-container');
  dom == null ? void 0 : dom.appendChild(root);
  // 画布最外层容器
  var container = document.createElement('div');
  container.setAttribute('class', 'huicharts-canvas-container');
  root.appendChild(container);
  // 画布背景网格
  var bgCanvas;
  if (option != null && option.show && option != null && (_option$grid = option.grid) != null && _option$grid.show) {
    bgCanvas = new Grid(container, option == null ? void 0 : option.grid);
  }
  // 连线svg容器
  container.insertAdjacentHTML('beforeend', svgContainer);
  var lineContainer = dom.getElementsByClassName("huicharts-lines-container")[0];
  var lineGContainer = lineContainer.getElementsByClassName('huicharts-lines-g')[0];
  // 节点容器
  var nodeContainer = document.createElement('div');
  nodeContainer.setAttribute('class', 'huicharts-nodes-container');
  container.appendChild(nodeContainer);
  // 二次连线svg容器
  container.insertAdjacentHTML('beforeend', svgSecondContainer);
  var secondlineContainer = dom.getElementsByClassName("huicharts-second-lines-container ")[0];
  var secondlineGContainer = secondlineContainer.getElementsByClassName('huicharts-second-lines-g')[0];
  // 动效节点容器
  var animationContainer = document.createElement('div');
  animationContainer.setAttribute('class', 'huicharts-animation-container');
  container.appendChild(animationContainer);
  return {
    root: root,
    bgCanvas: bgCanvas,
    container: container,
    lineContainer: lineContainer,
    nodeContainer: nodeContainer,
    lineGContainer: lineGContainer,
    animationContainer: animationContainer,
    secondlineContainer: secondlineContainer,
    secondlineGContainer: secondlineGContainer
  };
}
export { initDom as default };
