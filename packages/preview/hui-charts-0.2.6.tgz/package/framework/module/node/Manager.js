import Node from './index.js';
import nodeLayout from '../nodeLayout/index.js';
import convertData from './convertData/index.js';
import bufferRender from './bufferRender.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var NodeManager = /*#__PURE__*/function () {
  function NodeManager(option, container) {
    // nodes + edges 数组格式数据, 即 relationData
    this.data = void 0;
    // 节点数据
    this.nodes = void 0;
    // 节点关系
    this.edges = void 0;
    // 布局名称
    this.layoutName = void 0;
    // 节点理器工厂
    this.instance = {};
    this.option = option;
    this.container = container;
    this.canvasContainter = this.container.parentNode;
  }

  // option.layout.algorithm 为自定义布局算法
  var _proto = NodeManager.prototype;
  _proto.init = function init(option) {
    var _option$layout;
    if (option != null && (_option$layout = option.layout) != null && _option$layout.algorithm) {
      this.layoutName = 'customize';
    } else {
      var _option$layout2;
      this.layoutName = (option == null ? void 0 : (_option$layout2 = option.layout) == null ? void 0 : _option$layout2.type) || 'defaults';
    }
  }

  // 计算布局
;
  _proto.layout = function layout() {
    this.init(this.option);
    var layoutClass = nodeLayout[this.layoutName];
    var containerRect = this.container.getBoundingClientRect();
    new layoutClass(this.option.data, containerRect, this.option);
    // 将 optionData 转成 relationData
    this.data = convertData[this.layoutName](this.option.data);
  };
  _proto.relayout = function relayout(option) {
    this.init(option);
    var layoutClass = nodeLayout[this.layoutName];
    var containerRect = this.container.getBoundingClientRect();
    new layoutClass(option.data, containerRect, option);
    // 将 optionData 转成 relationData
    this.data = convertData[this.layoutName](option.data);
  };
  _proto.render = function render() {
    var _this$option$layout,
      _this = this;
    this.instance = {};
    var containerRect = this.container.getBoundingClientRect();
    this.canvasContainterRect = this.canvasContainter.getBoundingClientRect();
    this.containerCenter = {
      x: containerRect.width / 2,
      y: containerRect.height / 2
    };
    if ((_this$option$layout = this.option.layout) != null && _this$option$layout.bufferRender) {
      // 执行局部渲染方法
      this.data.nodes.forEach(function (node) {
        _this.bufferRenderNode(node, _this.option);
      });
    } else {
      // 执行全局渲染方法
      this.data.nodes.forEach(function (node) {
        _this.renderNode(node, _this.option);
      });
    }
  }

  // 全局渲染
;
  _proto.renderNode = function renderNode(node, option) {
    var nodeInstance = new Node(node, option, this.container);
    var nodeDom = nodeInstance.render();
    this.container.appendChild(nodeDom);
    this.instance[node.id] = nodeInstance;
  }

  // 局部渲染
;
  _proto.bufferRenderNode = function bufferRenderNode(node, option) {
    var nodeInstance = new Node(node, option, this.container);
    // 使用初始偏移 (0, 0) 进行首次渲染
    bufferRender(nodeInstance, {
      scale: 1,
      lastScale: 1,
      offset: {
        x: 0,
        y: 0
      },
      center: this.containerCenter
    }, this.container, this.canvasContainterRect); // TODO 初始渲染可能缩放值不是1
    this.instance[node.id] = nodeInstance;
  }

  // 外部触发局部渲染回调
;
  _proto.onBufferRender = function onBufferRender(params) {
    var _this$option$layout2;
    if (!((_this$option$layout2 = this.option.layout) != null && _this$option$layout2.bufferRender)) return;
    for (var id in this.instance) {
      bufferRender(this.instance[id], params, this.container, this.canvasContainterRect);
    }
  };
  // 刷新所有节点，并执行位移动画, this.data为新数据, this.instance为旧数据
  _proto.refresh = function refresh(option) {
    var _this2 = this;
    var newIds = [];
    var oldIds = [];
    this.data.nodes.forEach(function (newNode) {
      newIds.push(newNode.id);
      if (_this2.isExist(newNode.id)) {
        _this2.instance[newNode.id].refresh(newNode);
      } else {
        var _option$layout3;
        if ((_option$layout3 = option.layout) != null && _option$layout3.bufferRender) {
          // 执行局部渲染方法
          _this2.bufferRenderNode(newNode, option);
        } else {
          // 执行全局渲染方法
          _this2.renderNode(newNode, option);
        }
      }
    });
    oldIds = Object.keys(this.instance);
    oldIds.forEach(function (id) {
      if (newIds.indexOf(id) == -1) {
        _this2.unmount(id);
      }
    });
  };
  _proto.getNodeData = function getNodeData(id) {
    var _this$instance$id;
    return (_this$instance$id = this.instance[id]) == null ? void 0 : _this$instance$id.getData();
  };
  _proto.getNode = function getNode(id) {
    return this.instance[id];
  }

  // 保存节点的实时位置+大小，用于做动效
;
  _proto.getCurrentPosition = function getCurrentPosition() {
    var _this3 = this;
    var current = {};
    Object.keys(this.instance).forEach(function (id) {
      current[id] = _this3.instance[id].getCurrentPosition();
    });
    return current;
  };
  _proto.getData = function getData() {
    return this.data; // nodes, edges
  };
  _proto.getDom = function getDom(id) {
    var _this$instance$id2;
    return (_this$instance$id2 = this.instance[id]) == null ? void 0 : _this$instance$id2.getDom();
  };
  _proto.isExist = function isExist(id) {
    return this.instance[id];
  };
  _proto.update = function update(id, data) {
    this.instance[id].update(data);
  }

  // 指定节点添加事件
;
  _proto.addEventListener = function addEventListener(id, eventName, eventCallBack) {
    this.getNode(id).addEventListener(eventName, eventCallBack);
  };
  _proto.unmount = function unmount(id) {
    this.instance[id].unmount();
    delete this.instance[id];
  };
  return NodeManager;
}();
export { NodeManager as default };
