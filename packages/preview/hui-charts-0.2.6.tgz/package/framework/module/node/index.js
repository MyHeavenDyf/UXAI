import Animation from '../animation/Animation.js';
import nodeRender from '../../../feature/nodeRender/index.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

var NODE_WIDTH = 100;
var NODE_HEIGHT = 50;
var Node = /*#__PURE__*/function () {
  function Node(data, option, container) {
    // 节点数据
    this.data = void 0;
    // 用户传入的渲染方法、框架组件、DOM元素
    this.component = void 0;
    // 节点容器
    this.container = void 0;
    // 节点外壳
    this.nodeContainer = void 0;
    // 节点最终位置
    this.position = void 0;
    // 节点实时位置，用于做动效位移使用
    this.currentPosition = void 0;
    // 框架节点组件实例
    this.app = void 0;
    // 节点是否已渲染
    this.hasRender = void 0;
    this.data = data;
    this.currentPosition = data;
    this.component = this.setComponent(data, option);
    this.container = container;
    this.setComponentSize(data, option);
    this.setComponentPosition(data);
    this.hasRender = false;
  }
  var _proto = Node.prototype;
  _proto.render = function render() {
    if (!this.data) return;
    var id = this.data.id;
    var nodeContainer = document.createElement("div");
    nodeContainer.id = id;
    nodeContainer.style.width = this.componentSize.width + 'px';
    nodeContainer.style.height = this.componentSize.height + 'px';
    nodeContainer.style.top = this.position.y + 'px';
    nodeContainer.style.left = this.position.x + 'px';
    nodeContainer.style.position = 'absolute';
    nodeContainer.setAttribute('class', 'huicharts-node');
    nodeRender.render(nodeContainer, this.component, this.data, this);
    // TODO 此处要改，不建议存储dom
    this.nodeContainer = nodeContainer;
    this.setCurrentPosition({
      left: this.position.x,
      top: this.position.y,
      width: this.componentSize.width,
      height: this.componentSize.height
    });
    this.bindEvents();
    // 设置节点为已渲染
    this.hasRender = true;
    return nodeContainer;
  }

  // 兼容旧版本的render方法
;
  _proto.setComponent = function setComponent(data, option) {
    var dataComponent = data.component || data.render;
    var optionComponent = option.component || option.render;
    return dataComponent || optionComponent;
  }

  // 设定节点尺寸
;
  _proto.setComponentSize = function setComponentSize(data, option) {
    var _option$node, _option$node2;
    this.componentSize = {
      width: (data == null ? void 0 : data.width) || (option == null ? void 0 : (_option$node = option.node) == null ? void 0 : _option$node.width) || NODE_WIDTH,
      height: (data == null ? void 0 : data.height) || (option == null ? void 0 : (_option$node2 = option.node) == null ? void 0 : _option$node2.height) || NODE_HEIGHT
    };
    return this.componentSize;
  }

  // 设定节点最终位置
;
  _proto.setComponentPosition = function setComponentPosition(data) {
    this.position = {
      x: data.x,
      y: data.y
    };
    return this.position;
  }

  // 设定当前节点位置，实时更新，用于做动效位移使用
;
  _proto.setCurrentPosition = function setCurrentPosition(rect) {
    this.currentPosition.x = rect.left;
    this.currentPosition.y = rect.top;
    this.currentPosition.width = rect.width;
    this.currentPosition.height = rect.height;
  };
  _proto.getCurrentPosition = function getCurrentPosition() {
    return this.currentPosition;
  }

  // 设定各个框架节点实例
;
  _proto.setComponentApp = function setComponentApp(app) {
    this.app = app;
  }

  // 更新节点
;
  _proto.update = function update(data) {
    var _this$app;
    (_this$app = this.app) == null ? void 0 : _this$app.update(data);
  }

  // 卸载节点
;
  _proto.unmount = function unmount() {
    var _this$app2;
    (_this$app2 = this.app) == null ? void 0 : _this$app2.unmount();
    this.container.removeChild(this.nodeContainer);
  }

  // 节点绑定事件
;
  _proto.bindEvents = function bindEvents() {
    for (var eventName in this.data.event) {
      this.addEventListener(eventName, this.data.event[eventName]);
    }
  };
  _proto.addEventListener = function addEventListener(eventName, callback) {
    var _this = this;
    if (!this.nodeContainer) return;
    this.nodeContainer.addEventListener(eventName, function (event) {
      callback(event, _this.data);
    });
  };
  _proto.removeEventListener = function removeEventListener(eventName, callback) {
    var _this2 = this;
    if (!this.nodeContainer) return;
    this.nodeContainer.removeEventListener(eventName, function (event) {
      callback(event, _this2.data);
    });
  }

  // 位置变换，数据刷新，节点刷新
;
  _proto.refresh = function refresh(newData) {
    var _this3 = this;
    var animation = new Animation(this.nodeContainer, {
      start: {
        top: this.position.y,
        left: this.position.x,
        width: this.componentSize.width,
        height: this.componentSize.height
      },
      end: {
        top: newData.y,
        left: newData.x,
        width: newData.width,
        height: newData.height
      },
      duration: 500,
      onAfterUpdate: function onAfterUpdate(params, elapsed, element) {
        _this3.setCurrentPosition(params);
      },
      onFinish: function onFinish() {
        _this3.setComponentPosition(newData);
        _this3.setComponentSize(newData, {});
        _this3.setData(newData);
        _this3.update(newData);
      }
    });
    animation.start();
  };
  _proto.setData = function setData(data) {
    this.data = data;
  };
  _proto.getDom = function getDom() {
    return this.nodeContainer;
  };
  _proto.getData = function getData() {
    return this.data;
  };
  return Node;
}();
export { Node as default };
