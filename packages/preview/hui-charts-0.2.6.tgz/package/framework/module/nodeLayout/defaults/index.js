import execute from './excute.js';
var Layout = /*#__PURE__*/function () {
  function Layout(data, containerSize, option) {
    // 树形结构数据
    this.data = void 0;
    this.data = data;
    // 容器大小
    this.containerSize = containerSize;

    // 计算节点位置
    this.doLayout(this.data.nodes, this.data, option);
  }

  // 开始执行位置算法
  var _proto = Layout.prototype;
  _proto.doLayout = function doLayout(nodes, data, options) {
    execute(nodes, data, this.containerSize);
  };
  return Layout;
}();
export { Layout as default };
