function isArray(e) {
  return Object.prototype.toString.call(e) === "[object Array]" ? true : false;
}
function isString(e) {
  return typeof e === "string";
}
function isNumber(e) {
  return typeof e === "number";
}
function isNaN(e) {
  return Number.isNaN(Number(e));
}
function getDegree(l, o, e) {
  var t = [];
  for (var _e = 0; _e < l; _e++) {
    t[_e] = 0;
  }
  e.forEach(function (e) {
    if (e.start) {
      t[o[e.start]] += 1;
    }
    if (e.end) {
      t[o[e.end]] += 1;
    }
  });
  return t;
}
function small(e) {
  var l;
  rows = rows || 5;
  cols = cols || 5;
  if (e == null) {
    l = Math.min(rows, cols);
  } else {
    var o = Math.min(rows, cols);
    if (o === rows) {
      rows = e;
    } else {
      cols = e;
    }
  }
  return l;
}
function large(e) {
  var l;
  rows = rows || 5;
  cols = cols || 5;
  if (e == null) {
    l = Math.max(rows, cols);
  } else {
    var o = Math.max(rows, cols);
    if (o === rows) {
      rows = e;
    } else {
      cols = e;
    }
  }
  return l;
}
function used(e, l) {
  return cellUsed["c-" + e + "-" + l] || false;
}
function use(e, l) {
  cellUsed["c-" + e + "-" + l] = true;
}
function moveToNextCell() {
  cols = cols || 5;
  col++;
  if (col >= cols) {
    col = 0;
    row++;
  }
}
function getPos(e) {
  var l;
  var o;
  var t = id2manPos[e.id];
  if (t) {
    l = t.col * cellWidth + cellWidth / 2 + begin[0];
    o = t.row * cellHeight + cellHeight / 2 + begin[1];
  } else {
    while (used(row, col)) {
      moveToNextCell();
    }
    l = col * cellWidth + cellWidth / 2 + begin[0];
    o = row * cellHeight + cellHeight / 2 + begin[1];
    use(row, col);
    moveToNextCell();
  }
  e.x = l;
  e.y = o;
}
var nodeSize;
var center = [0, 0];
var splits;
var columns;
var cells;
var begin;
var preventOverlap;
var preventOverlapPadding;
var condense;
var rows;
var cols;
var sortBy;
var cellWidth;
var cellHeight;
var cellUsed;
var id2manPos;
var row;
var col;
function execute(e, l, o, t) {
  var s = t.layout;
  begin = s.begin || [0, 0];
  preventOverlap = s.preventOverlap || false;
  preventOverlapPadding = s.preventOverlapPadding || 0;
  condense = s.condense || false;
  rows = s.rows || undefined;
  cols = s.cols || undefined;
  sortBy = s.sortBy || "default";
  var i = s.width || o.width;
  var n = s.height || o.height;
  cellWidth = 0;
  cellHeight = 0;
  cellUsed = {};
  id2manPos = {};
  row = 0;
  col = 0;
  nodeSize = 50;
  if (t.node) {
    nodeSize = [t.node.width, t.node.height];
  }
  var r = l.edges;
  var c = e.length;
  if (c === 0) {
    return;
  }
  if (c === 1) {
    e[0].x = center[0];
    e[0].y = center[1];
    return;
  }
  var d = [];
  e.forEach(function (e) {
    d.push(e);
  });
  var f = {};
  d.forEach(function (e, l) {
    f[e.id] = l;
  });
  if (isString(sortBy) && sortBy !== "default") {
    if (isNaN(e[0][sortBy])) {
      var w = getDegree(d.length, f, r);
      d.forEach(function (e, l) {
        e[sortBy] = w[l];
      });
    }
  }
  if (sortBy === "degreeMany" || isString(sortBy) && sortBy !== "default" && sortBy !== "degreeFew") {
    d.sort(function (e, l) {
      return l[sortBy] - e[sortBy];
    });
  }
  if (sortBy === "degreeFew") {
    d.sort(function (e, l) {
      return e[sortBy] - l[sortBy];
    });
  }
  if (!i && typeof window !== "undefined") {
    i = window.innerWidth;
  }
  if (!n && typeof window !== "undefined") {
    n = window.innerHeight;
  }
  var u = rows;
  var a = cols != null ? cols : columns;
  cells = c;
  if (u != null && a != null) {
    rows = u;
    cols = a;
  } else if (u != null && a == null) {
    rows = u;
    cols = Math.ceil(cells / rows);
  } else if (u == null && a != null) {
    cols = a;
    rows = Math.ceil(cells / cols);
  } else {
    splits = Math.sqrt(cells * n / i);
    rows = Math.round(splits);
    cols = Math.round(i / n * splits);
  }
  if (cols * rows > cells) {
    var h = small();
    var g = large();
    if ((h - 1) * g >= cells) {
      small(h - 1);
    } else if ((g - 1) * h >= self.cells) {
      large(g - 1);
    }
  } else {
    while (cols * rows < cells) {
      var _h = small();
      var _g = large();
      if ((_g + 1) * _h >= cells) {
        large(_g + 1);
      } else {
        small(_h + 1);
      }
    }
  }
  cellWidth = i / cols;
  cellHeight = n / rows;
  if (condense) {
    cellWidth = 0;
    cellHeight = 0;
  }
  if (preventOverlap) {
    d.forEach(function (e) {
      if (!e.x || !e.y) {
        e.x = 0;
        e.y = 0;
      }
      var l;
      var o;
      if (isArray(e.size)) {
        l = e.size[0];
        o = e.size[1];
      } else if (isNumber(e.size)) {
        l = e.size;
        o = e.size;
      }
      if (l === undefined || o === undefined) {
        if (isArray(nodeSize)) {
          l = nodeSize[0];
          o = nodeSize[1];
        } else if (isNumber(nodeSize)) {
          l = nodeSize;
          o = nodeSize;
        } else {
          l = 30;
          o = 30;
        }
      }
      var t = preventOverlapPadding;
      var s = l + t;
      var i = o + t;
      cellWidth = Math.max(cellWidth, s);
      cellHeight = Math.max(cellHeight, i);
    });
  }
  row = 0;
  col = 0;
  for (var _l = 0; _l < d.length; _l++) {
    var p = d[_l];
    getPos(p);
  }
}
export { execute as default };
