/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var DEFAULT_BOX_FONTSIZE = 18;
var DEFAULT_BOX_HEIGHT = 36;
var DEFAULT_BOX_GAP = 18;
var DEFAULT_BOX_OPTIONS = {
  getId: function getId(t) {
    return t.id || t.name;
  },
  getPreH: function getPreH(t) {
    return t.preH || 0;
  },
  getPreV: function getPreV(t) {
    return t.preV || 0;
  },
  getHGap: function getHGap(t) {
    return t.hgap || DEFAULT_BOX_GAP;
  },
  getVGap: function getVGap(t) {
    return t.vgap || DEFAULT_BOX_GAP;
  },
  getChildren: function getChildren(t) {
    return t.children;
  },
  getHeight: function getHeight(t) {
    return t.height || DEFAULT_BOX_HEIGHT;
  },
  getWidth: function getWidth(t) {
    var h = t.label || " ";
    return t.width || h.split("").length * DEFAULT_BOX_FONTSIZE;
  }
};
var NodeBox = /*#__PURE__*/function () {
  function NodeBox(t, h) {
    this.options = Object.assign(DEFAULT_BOX_OPTIONS, h);
    this.vgap = this.hgap = 0;
    var e = this.options.getHGap(t);
    var i = this.options.getVGap(t);
    this.preH = this.options.getPreH(t);
    this.preV = this.options.getPreV(t);
    this.width = this.options.getWidth(t);
    this.height = this.options.getHeight(t);
    this.width += this.preH;
    this.height += this.preV;
    this.id = this.options.getId(t);
    this.x = 0;
    this.y = 0;
    this.depth = t.depth;
    if (!this.children) {
      this.children = [];
    }
    this.addGap(e, i);
  }
  var _proto = NodeBox.prototype;
  _proto.isRoot = function isRoot() {
    return this.depth === 0;
  };
  _proto.isLeaf = function isLeaf() {
    return this.children.length === 0;
  };
  _proto.addGap = function addGap(t, h) {
    this.hgap += t;
    this.vgap += h;
    this.width += 2 * t;
    this.height += 2 * h;
  };
  _proto.eachNode = function eachNode(t) {
    var h = [this];
    var e;
    while (e = h.shift()) {
      t(e);
      h = e.children.concat(h);
    }
  };
  _proto.DFTraverse = function DFTraverse(t) {
    this.eachNode(t);
  };
  _proto.BFTraverse = function BFTraverse(t) {
    var h = [this];
    var e;
    while (e = h.shift()) {
      t(e);
      h = h.concat(e.children);
    }
  };
  _proto.getBoundingBox = function getBoundingBox() {
    var h = {
      left: Number.MAX_VALUE,
      top: Number.MAX_VALUE,
      width: 0,
      height: 0
    };
    this.eachNode(function (t) {
      h.left = Math.min(h.left, t.x);
      h.top = Math.min(h.top, t.y);
      h.width = Math.max(h.width, t.x + t.width);
      h.height = Math.max(h.height, t.y + t.height);
    });
    return h;
  };
  _proto.translate = function translate(h, e) {
    if (h === void 0) {
      h = 0;
    }
    if (e === void 0) {
      e = 0;
    }
    this.eachNode(function (t) {
      t.x += h;
      t.y += e;
      t.x += t.preH;
      t.y += t.preV;
    });
  };
  _proto.right2left = function right2left() {
    var h = this.getBoundingBox();
    this.eachNode(function (t) {
      t.x = t.x - (t.x - h.left) * 2 - t.width;
    });
    this.translate(h.width, 0);
  };
  _proto.bottom2top = function bottom2top() {
    var h = this.getBoundingBox();
    this.eachNode(function (t) {
      t.y = t.y - (t.y - h.top) * 2 - t.height;
    });
    this.translate(0, h.height);
  };
  return NodeBox;
}();
export { NodeBox as default };
