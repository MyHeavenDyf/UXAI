function WrappedTree(e, c, n, t) {
  if (t === void 0) {
    t = [];
  }
  var r = this;
  r.w = e || 0;
  r.h = c || 0;
  r.y = n || 0;
  r.x = 0;
  r.c = t || [];
  r.cs = t.length;
  r.prelim = 0;
  r.mod = 0;
  r.shift = 0;
  r.change = 0;
  r.tl = null;
  r.tr = null;
  r.el = null;
  r.er = null;
  r.msel = 0;
  r.mser = 0;
}
WrappedTree.fromNode = function (e, c) {
  if (!e) return null;
  var n = [];
  e.children.forEach(function (e) {
    n.push(WrappedTree.fromNode(e, c));
  });
  if (c) return new WrappedTree(e.height, e.width, e.x, n);
  return new WrappedTree(e.width, e.height, e.y, n);
};
function moveRight(e, c, n) {
  if (n) {
    e.y += c;
  } else {
    e.x += c;
  }
  e.children.forEach(function (e) {
    moveRight(e, c, n);
  });
}
function getMin(e, c) {
  var n = c ? e.y : e.x;
  e.children.forEach(function (e) {
    n = Math.min(getMin(e, c), n);
  });
  return n;
}
function normalize(e, c) {
  var n = getMin(e, c);
  moveRight(e, -n, c);
}
function convertBack(e, n, t) {
  if (t) {
    n.y = e.x;
  } else {
    n.x = e.x;
  }
  e.c.forEach(function (e, c) {
    convertBack(e, n.children[c], t);
  });
}
function layer(e, c, n) {
  if (n === void 0) {
    n = 0;
  }
  if (c) {
    e.x = n;
    n += e.width;
  } else {
    e.y = n;
    n += e.height;
  }
  e.children.forEach(function (e) {
    layer(e, c, n);
  });
}
var nonLayeredTidyTree = function nonLayeredTidyTree(e, c) {
  if (c === void 0) {
    c = {};
  }
  var n = c.isHorizontal;
  function r(c) {
    if (c.cs === 0) {
      l(c);
      return;
    }
    r(c.c[0]);
    var n = x(d(c.c[0].el), 0, null);
    for (var _e = 1; _e < c.cs; ++_e) {
      r(c.c[_e]);
      var _t = d(c.c[_e].er);
      i(c, _e, n);
      n = x(_t, _e, n);
    }
    o(c);
    l(c);
  }
  function l(e) {
    if (e.cs === 0) {
      e.el = e;
      e.er = e;
      e.msel = e.mser = 0;
    } else {
      e.el = e.c[0].el;
      e.msel = e.c[0].msel;
      e.er = e.c[e.cs - 1].er;
      e.mser = e.c[e.cs - 1].mser;
    }
  }
  function i(e, c, n) {
    var t = e.c[c - 1];
    var r = t.mod;
    var l = e.c[c];
    var i = l.mod;
    while (t !== null && l !== null) {
      if (d(t) > n.low) n = n.nxt;
      var _o = r + t.prelim + t.w - (i + l.prelim);
      if (_o > 0) {
        i += _o;
        m(e, c, n.index, _o);
      }
      var _s = d(t);
      var _f = d(l);
      if (_s <= _f) {
        t = h(t);
        if (t !== null) r += t.mod;
      }
      if (_s >= _f) {
        l = u(l);
        if (l !== null) i += l.mod;
      }
    }
    if (!t && !!l) {
      a(e, c, l, i);
    } else if (!!t && !l) {
      p(e, c, t, r);
    }
  }
  function m(e, c, n, t) {
    e.c[c].mod += t;
    e.c[c].msel += t;
    e.c[c].mser += t;
    s(e, c, n, t);
  }
  function u(e) {
    return e.cs === 0 ? e.tl : e.c[0];
  }
  function h(e) {
    return e.cs === 0 ? e.tr : e.c[e.cs - 1];
  }
  function d(e) {
    return e.y + e.h;
  }
  function a(e, c, n, t) {
    var r = e.c[0].el;
    r.tl = n;
    var l = t - n.mod - e.c[0].msel;
    r.mod += l;
    r.prelim -= l;
    e.c[0].el = e.c[c].el;
    e.c[0].msel = e.c[c].msel;
  }
  function p(e, c, n, t) {
    var r = e.c[c].er;
    r.tr = n;
    var l = t - n.mod - e.c[c].mser;
    r.mod += l;
    r.prelim -= l;
    e.c[c].er = e.c[c - 1].er;
    e.c[c].mser = e.c[c - 1].mser;
  }
  function o(e) {
    e.prelim = (e.c[0].prelim + e.c[0].mod + e.c[e.cs - 1].mod + e.c[e.cs - 1].prelim + e.c[e.cs - 1].w) / 2 - e.w / 2;
  }
  function t(c, n) {
    n += c.mod;
    c.x = c.prelim + n;
    f(c);
    for (var _e2 = 0; _e2 < c.cs; _e2++) {
      t(c.c[_e2], n);
    }
  }
  function s(e, c, n, t) {
    if (n !== c - 1) {
      var _r = c - n;
      e.c[n + 1].shift += t / _r;
      e.c[c].shift -= t / _r;
      e.c[c].change -= t - t / _r;
    }
  }
  function f(c) {
    var n = 0;
    var t = 0;
    for (var _e3 = 0; _e3 < c.cs; _e3++) {
      n += c.c[_e3].shift;
      t += n + c.c[_e3].change;
      c.c[_e3].mod += t;
    }
  }
  function x(e, c, n) {
    while (n !== null && e >= n.low) {
      n = n.nxt;
    }
    return {
      low: e,
      index: c,
      nxt: n
    };
  }
  layer(e, n);
  var w = WrappedTree.fromNode(e, n);
  r(w);
  t(w, 0);
  convertBack(w, e, n);
  normalize(e, n);
  return e;
};
export { nonLayeredTidyTree as default };
