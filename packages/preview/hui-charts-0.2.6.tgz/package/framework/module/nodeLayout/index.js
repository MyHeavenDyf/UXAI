import Layout from './nonLayeredTidyTree/index.js';
import Layout$1 from './grid/index.js';
import Layout$2 from './circle/index.js';
import Layout$3 from './linearArc/index.js';
import Layout$4 from './customize/index.js';
import Layout$5 from './defaults/index.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

var nodeLayout = {
  'mindmap': Layout,
  'grid': Layout$1,
  'circle': Layout$2,
  'linearArc': Layout$3,
  'customize': Layout$4,
  'defaults': Layout$5
};
export { nodeLayout as default };
