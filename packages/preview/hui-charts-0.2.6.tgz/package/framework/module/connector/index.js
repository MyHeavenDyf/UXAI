var _CONNECTOR;
function _readOnlyError(r) { throw new TypeError('"' + r + '" is read-only'); }
import Dot from './type/dot.js';
import Expand from './type/expand.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

var DOT = 'dot'; // 圆点样式
var EXPAND = 'expand'; // 展开样式

var CONNECTOR = (_CONNECTOR = {}, _CONNECTOR[DOT] = Dot, _CONNECTOR[EXPAND] = Expand, _CONNECTOR);
var Connector = /*#__PURE__*/function () {
  function Connector(data, option, chartInstance) {
    // 连接点数据
    this.data = data;
    // 绘画连接点
    this.render(option, chartInstance);
    this.chartInstance = chartInstance;
  }

  // 绘画节点
  var _proto = Connector.prototype;
  _proto.render = function render(option, chartInstance) {
    var _option$connector;
    var data = this.data;
    var nodeDom = document.getElementById(data.nodeId);
    var render = (_option$connector = option.connector) == null ? void 0 : _option$connector.render;
    var connectorType = Object.assign({
      type: 'dot'
    }, option.connector);
    var connectorStyle = connectorType.style;
    var connectorDom;
    var dom = document.createElement('div');
    dom.id = data.id;
    dom.setAttribute('class', 'connector-con');
    dom.setAttribute('style', "left: " + data.x + "px; top: " + data.y + "px;");
    if (render && render(data)) {
      var parser = new DOMParser();
      var doc = parser.parseFromString(render(data), "text/html");
      connectorDom = doc.body.firstChild;
    } else {
      var connectorIns = new CONNECTOR[connectorType.type]();
      if (option.layout) {
        connectorDom = connectorIns.render(data, chartInstance);
      }
    }
    connectorStyle && connectorDom && Object.keys(connectorStyle).forEach(function (item) {
      connectorDom.style[item] = connectorStyle[item];
    });
    if (connectorDom) {
      dom.appendChild(connectorDom);
    }
    nodeDom && nodeDom.appendChild(dom);
    // 绑定事件
    this.clickEvent(dom, data, option);
  }

  // 绑定click事件
;
  _proto.clickEvent = function clickEvent(dom, data, option) {
    var _option$connector2;
    var onClick = (_option$connector2 = option.connector) == null ? void 0 : _option$connector2.onClick;
    dom.addEventListener("click", function () {
      onClick && onClick(data);
    });
  }

  // 卸载节点
;
  _proto.uninstall = function uninstall(id, instances) {
    var element = document.getElementById(id);
    element && element.remove();
    instances[id] && delete instances[id];
    this.Alldata[id] && delete this.Alldata[id];
  }

  // 更新节点信息
;
  _proto.update = function update(id, data, option) {
    var dom = document.getElementById(id);
    if (dom) {
      var _option$connector3;
      dom.setAttribute('style', "left: " + data.x + "px; top: " + data.y + "px;");
      var connectorStyle = option == null ? void 0 : (_option$connector3 = option.connector) == null ? void 0 : _option$connector3.style;
      connectorStyle && Object.keys(connectorStyle).forEach(function (item) {
        dom.style[item] = connectorStyle[item];
      });
    }
  };
  return Connector;
}();
export { Connector as default };
