function _inheritsLoose(t, o) { t.prototype = Object.create(o.prototype), t.prototype.constructor = t, _setPrototypeOf(t, o); }
function _setPrototypeOf(t, e) { return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) { return t.__proto__ = e, t; }, _setPrototypeOf(t, e); }
import Base from './Base.js';
import CanvasManager from '../module/canvas/index.js';
import LegendManger from '../module/legend/index.js';
import Contextmenu from '../module/contextmenu/index.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 对外暴露的关系型图表基础组件
var Relation = /*#__PURE__*/function (_Base) {
  function Relation() {
    var _this;
    _this = _Base.call(this) || this;
    // 图表容器
    _this.dom = undefined;
    // 图表配置
    _this.option = {};
    // 画布模块
    _this.canvas = {};
    // 图例模块
    _this.legendManger = null;
    return _this;
  }
  _inheritsLoose(Relation, _Base);
  var _proto = Relation.prototype;
  _proto.setOption = function setOption(option) {
    var _option$legend;
    this.option = option;
    if (this.dom === undefined) {
      console.error('This chart has not set container dom!');
      return;
    }
    // 将画布作为图表容器
    this.canvas = new CanvasManager(this.dom, this.option.canvas);
    var containers = this.canvas.containers;
    // 用户提供的容器
    this.dom = this.canvas.getCanvasDom();
    // 图表根容器 .huicharts-container
    this.root = containers.root;
    // 图表画布容器 .huicharts-canvas-container
    this.container = containers.container;
    // 图表连线容器 .huicharts-lines-container
    this.svgContainer = containers.lineContainer;
    // 图表节点容器  .huicharts-nodes-container
    this.htmlContainer = containers.nodeContainer;
    // 图表节点容器  .huicharts-animation-container
    this.animationContainer = containers.animationContainer;
    // 图表二次连线容器 .huicharts-second-lines-container
    this.secondSvgContainer = containers.secondlineContainer;
    this.secondlineGContainer = containers.secondlineGContainer;
    // lineGContainer
    if (option != null && option.legend && !((option == null ? void 0 : (_option$legend = option.legend) == null ? void 0 : _option$legend.show) === false)) {
      this.legendManger = new LegendManger(option.legend, this.root);
    }
    // 右键菜单
    if (option != null && option.menu) {
      this.setContextMenu(option.menu);
    }
  };
  _proto.uninstall = function uninstall() {
    var _this$contextmenuMang;
    (_this$contextmenuMang = this.contextmenuManger) == null ? void 0 : _this$contextmenuMang.uninstall();
  };
  _proto.render = function render() {
    var _this$legendManger;
    (_this$legendManger = this.legendManger) == null ? void 0 : _this$legendManger.render();
  };
  _proto.setCanvas = function setCanvas(canvasOpt) {};
  _proto.setContextMenu = function setContextMenu(contextMenuOpt) {
    this.contextmenuManger = new Contextmenu(this, contextMenuOpt);
  };
  return Relation;
}(Base);
export { Relation as default };
