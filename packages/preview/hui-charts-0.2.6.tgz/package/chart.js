function _inheritsLoose(t, o) { t.prototype = Object.create(o.prototype), t.prototype.constructor = t, _setPrototypeOf(t, o); }
function _setPrototypeOf(t, e) { return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) { return t.__proto__ = e, t; }, _setPrototypeOf(t, e); }
import CoreChart from './core.js';
import register from './register.js';
import { isFunction } from './util/type.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 图表核心对象，通过 Register 全量引入图表给 HuiCharts 渲染，打包容量较大
var HuiCharts = /*#__PURE__*/function (_CoreChart) {
  function HuiCharts() {
    var _this;
    _this = _CoreChart.call(this) || this;
    // 图表名称
    _this.chartName = null;
    return _this;
  }

  /**
   * 传入配置项
   * @param {图表类型, 当为string型时需要转换为对应图表class} chart 
   * @param {配置项} iChartOption 
   * @param {三方插件} plugins 
   * @param {是否初始渲染} isInit 
   */
  _inheritsLoose(HuiCharts, _CoreChart);
  var _proto = HuiCharts.prototype;
  _proto.setSimpleOption = function setSimpleOption(chart, iChartOption, plugins, isInit) {
    if (plugins === void 0) {
      plugins = {};
    }
    if (isInit === void 0) {
      isInit = true;
    }
    var ChartClass = null;
    if (isFunction(chart)) {
      this.chartName = chart.name;
      ChartClass = chart;
    } else {
      this.chartName = chart;
      ChartClass = this.getChartClass(chart);
    }
    _CoreChart.prototype.setSimpleOption.call(this, ChartClass, iChartOption, plugins, isInit);
  }

  // 获取图表类
;
  _proto.getChartClass = function getChartClass(name) {
    return register.getRegisteredComp(name);
  };
  return HuiCharts;
}(CoreChart);
export { HuiCharts as default };
