import max from '../../util/sort/max.js';
import min from '../../util/sort/min.js';
import { isArray, isString, isObject } from '../../util/type.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 组装直角坐标系自适应
function AdaptivePolarSys(baseOpt, iChartOpt, echartsIns, type) {
  var _echartsIns$getDom, _echartsIns$_dom, _baseOpt$polar;
  if (!iChartOpt.adaptive && !iChartOpt.a2ui) return;
  var chartHeight = (echartsIns == null ? void 0 : echartsIns.getHeight == null ? void 0 : echartsIns.getHeight()) || (echartsIns == null ? void 0 : echartsIns.getDom == null ? void 0 : (_echartsIns$getDom = echartsIns.getDom()) == null ? void 0 : _echartsIns$getDom.clientHeight) || (echartsIns == null ? void 0 : (_echartsIns$_dom = echartsIns._dom) == null ? void 0 : _echartsIns$_dom.clientHeight) || 0;
  var radius = ((_baseOpt$polar = baseOpt.polar) == null ? void 0 : _baseOpt$polar.radius) || baseOpt.radar[0].radius;
  var dataMax = 0;
  baseOpt.series.forEach(function (item, index) {
    var data = getDataNoObject(item.data);
    if (isArray(data[0])) data = data[0];
    var itemMax = max(data);
    min(data);
    if (itemMax > dataMax) {
      dataMax = itemMax;
    }
  });
  if (iChartOpt.radarMax) {
    dataMax = iChartOpt.radarMax;
  }
  var polarHeight = isArray(radius) ? radius[1] - radius[0] : radius;
  if (isString(polarHeight) && polarHeight.includes('%')) {
    polarHeight = parseFloat(polarHeight) / 100 * chartHeight / 2;
  }
  var scaleNumber = Math.trunc(polarHeight / 20) || 4; // 刻度轴行高18，最小间距2
  var split = dataMax / scaleNumber;
  if (type === 'polarBar') {
    if (split > 10) {
      split = (Math.trunc(split / 10) + 1) * 10;
    } else {
      split = Math.trunc(split) + 1;
    }
    baseOpt.radiusAxis.minInterval = split;
    baseOpt.radiusAxis.maxInterval = split;
    baseOpt.radiusAxis.interval = split;
    baseOpt.angleAxis.splitNumber = scaleNumber;
  } else if (type === 'radar') {
    if (!Number.isInteger(split)) {
      baseOpt.radar[0].splitNumber = scaleNumber - 1;
    } else {
      baseOpt.radar[0].splitNumber = scaleNumber;
    }
  }
}
function getDataNoObject(data) {
  if (!data) return data;
  return data.map(function (item) {
    return isObject(item) ? item.value : item;
  });
}
export { AdaptivePolarSys as default };
