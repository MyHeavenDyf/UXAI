import fluctuation, { transformData } from '../../../feature/fluctuation/index.js';
import { isNumber } from '../../../util/type.js';
function defaultFormatter(val) {
  if (!isNumber(val)) return val;
  var actualVal = Number.parseFloat(val.toFixed(2));
  return actualVal;
}
function axisOptimization(yAxis, baseYaxis, data) {
  // 静态给定y轴优化范围
  if (yAxis && yAxis.fluctuation) {
    var _yAxis$fluctuation = yAxis.fluctuation,
      equalSplit = _yAxis$fluctuation.equalSplit,
      splitNumber = _yAxis$fluctuation.splitNumber,
      active = _yAxis$fluctuation.active,
      labelFormatter = _yAxis$fluctuation.labelFormatter;
    if (!active) return;
    var newdata = transformData(data);
    var value = fluctuation(newdata);
    baseYaxis.min = value[0];
    baseYaxis.max = value[1];
    if (equalSplit) {
      var interval = (value[1] - value[0]) / (splitNumber != null ? splitNumber : 5);
      baseYaxis.interval = interval;
      baseYaxis.axisLabel.formatter = labelFormatter || defaultFormatter;
    }
  }
  // 动态优化y轴范围
  if (yAxis && yAxis.allowRange) {
    var _newdata = transformData(data);
    var _value = fluctuation(_newdata, yAxis.allowRange);
    baseYaxis.min = _value[0];
    baseYaxis.max = _value[1];
  }
}
export { axisOptimization as default };
