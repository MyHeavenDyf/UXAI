/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
function position(legend, selfLegend) {
  var position = selfLegend.position;
  legend.top = (position == null ? void 0 : position.top) !== undefined ? position.top : 'auto';
  legend.left = (position == null ? void 0 : position.left) !== undefined ? position.left : 'auto';
  legend.right = (position == null ? void 0 : position.right) !== undefined ? position.right : 'auto';
  legend.bottom = (position == null ? void 0 : position.bottom) !== undefined ? position.bottom : 'auto';
}
export { position as default };
