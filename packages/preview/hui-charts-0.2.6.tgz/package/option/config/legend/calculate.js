function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import cloneDeep from '../../../util/cloneDeep.js';
import { isArray, isNumber } from '../../../util/type.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 格式化富文本 获取宽度
function formatRichText(text, styles, textStyle, richMaxWidth) {
  var totalWidth = 0;
  var titleName;
  var titlePaddingWidth;
  // 创建一个canvas
  var canvas = document.createElement('canvas');
  var ctx = canvas.getContext('2d');
  var itemHeight = 0;
  text.replace(/\{(\w+)\|([^}]+)\}/g, function (match, styleName, content) {
    var style = styles[styleName] || {};
    var fontSize = ((textStyle == null ? void 0 : textStyle.fontSize) || 12) + "px;";
    var fontWeight = (textStyle == null ? void 0 : textStyle.fontWeight) || 'normal';
    var fontFamily = (textStyle == null ? void 0 : textStyle.fontFamily) || 'Arial';
    // 第一项为title
    if (!titleName) {
      titleName = styleName;
    }
    for (var key in style) {
      var val = style[key];
      if (key === 'padding' && titleName && !titlePaddingWidth) {
        titlePaddingWidth = isArray(val) ? Number(val[1]) + Number(val[3] || 0) : Number(val) * 2;
      }
      if (key === 'fontSize') {
        fontSize = val + 'px';
      }
      if (key === 'fontWeight') {
        fontWeight = fontWeight;
      }
      if (key === 'fontFamily') {
        fontFamily = fontFamily;
      }
    }
    // 设置字体
    ctx.font = fontWeight + " " + fontSize + " " + fontFamily;
    var metrics = ctx.measureText(content);
    // 获取宽度
    var textWidth = metrics.width;
    var textHeight = metrics.fontBoundingBoxAscent + metrics.fontBoundingBoxDescent;
    if (styleName === 'split') {
      // 分割线占宽17---取自设计稿
      textWidth = style != null && style.width ? style.width * 2 : 17;
    }
    if (richMaxWidth[styleName]) {
      richMaxWidth[styleName].widths.push(textWidth);
    } else {
      richMaxWidth[styleName] = {};
      richMaxWidth[styleName].widths = [textWidth];
    }
    if (style.width && style.width > textWidth) {
      totalWidth += style.width;
    } else {
      totalWidth += textWidth;
    }
    if (textHeight > itemHeight) {
      itemHeight = textHeight;
    }
  });
  canvas.remove();
  return {
    totalWidth: totalWidth,
    richMaxWidth: richMaxWidth,
    titleName: titleName,
    titlePaddingWidth: titlePaddingWidth,
    itemHeight: itemHeight
  };
}

// 计算图例宽度
function calculateOccupancy(iChartOption, legend, legendData) {
  try {
    var textStyle = (legend == null ? void 0 : legend.textStyle) || {};
    var richStyles = textStyle.rich || {};
    // 存储每个图例的宽度
    var itemNameWidths = [];
    var richMaxWidth = {};
    var maxWidths = [];
    var itemHeights = [];
    var titleName;
    var titlePaddingWidth;
    var iconWidth = (Number(legend.itemWidth) || 8) + 6; // icon与文本的间隙
    var iconHeight = Number(legend.itemHeight) || 8;
    // 创建一个canvas
    var canvas = document.createElement('canvas');
    var ctx = canvas.getContext('2d');
    // 为每个图例项创建测量元素
    legendData.forEach(function (name) {
      // 应用formatter和rich样式
      try {
        if (legend.formatter) {
          var formatterText = legend.formatter(name);
          var formatterConfig = formatRichText(formatterText, richStyles, textStyle, richMaxWidth, itemNameWidths);
          titleName = formatterConfig.titleName;
          maxWidths.push(formatterConfig.totalWidth);
          titlePaddingWidth = formatterConfig.titlePaddingWidth;
          itemHeights.push(formatterConfig.itemHeight);
        } else {
          // 未设置formatter
          var fontSize = ((textStyle == null ? void 0 : textStyle.fontSize) || 12) + "px;";
          var fontWeight = (textStyle == null ? void 0 : textStyle.fontWeight) || 'normal';
          var fontFamily = (textStyle == null ? void 0 : textStyle.fontFamily) || 'Arial';
          // 设置字体
          ctx.font = fontWeight + " " + fontSize + " " + fontFamily;
          var metrics = ctx.measureText(name);
          // 获取宽度
          var textWidth = metrics.width;
          var textHeight = metrics.fontBoundingBoxAscent + metrics.fontBoundingBoxDescent;
          if (richMaxWidth.title) {
            richMaxWidth.title.widths.push(textWidth);
          } else {
            richMaxWidth.title = {};
            richMaxWidth.title.widths = [textWidth];
          }
          maxWidths.push(textWidth);
          itemHeights.push(textHeight);
        }
      } catch (e) {
        console.warn(e);
      }
    });
    // 移除canvas
    canvas.remove();
    // 每一项最大值
    for (var key in richMaxWidth) {
      var element = richMaxWidth[key];
      element.maxWidth = Math.max.apply(Math, element.widths);
      if (key === 'split') {
        element.maxWidth = 17; //分割线占宽取自设计稿
      }
    }
    // 计算结果
    var maxWidth = Math.max.apply(Math, maxWidths) + iconWidth;
    var verticalHeight = itemHeights.reduce(function (sum, w) {
      w = w > iconHeight ? w : iconHeight;
      return sum + w + 8;
    }, 0); //图例间隙为8
    return {
      maxWidth: maxWidth,
      richMaxWidth: richMaxWidth,
      titleName: titleName,
      titlePaddingWidth: titlePaddingWidth,
      verticalHeight: verticalHeight
    };
  } catch (e) {
    console.error('计算图例宽度失败：', e);
  }
}

// 文本截断处理
function truncateText(text, maxWidth, fontSize, ellipsis, fontFamily, fontWeight) {
  if (fontFamily === void 0) {
    fontFamily = 'Arial';
  }
  if (fontWeight === void 0) {
    fontWeight = 'normal';
  }
  // 创建一个canvas
  var canvas = document.createElement('canvas');
  var ctx = canvas.getContext('2d');
  // 设置字体
  ctx.font = fontWeight + " " + fontSize + " " + fontFamily;
  // 测量省略号宽度
  var ellipsisWidth = ctx.measureText(ellipsis).width;
  // 如果原始文本的宽度不超过maxWidth，直接返回
  var totalWidth = ctx.measureText(text).width;
  if (totalWidth <= maxWidth || !Number(maxWidth)) {
    return text;
  }
  var high = text.length;
  var best = 0; //截断位置

  for (var index = 0; index < high; index++) {
    var midText = text.substring(0, index);
    var midWidth = ctx.measureText(midText).width;
    if (midWidth + ellipsisWidth >= maxWidth) {
      best = index;
      break;
    }
  }
  // 截断字符串 + 省略号
  return text.substring(0, best) + ellipsis;
}

// 图例截断处理
function updateLegendOccupancy(iChartOption, legend, legendData, chartInstance) {
  var _chartInstance$getDom, _chartInstance$_dom, _richMaxWidth$titleNa;
  var formatter = legend.formatter;
  legend.textStyle = legend.textStyle || {
    rich: {}
  };
  legend.textStyle.rich = legend.textStyle.rich || {};
  var textStyle = legend == null ? void 0 : legend.textStyle;
  var config = calculateOccupancy(iChartOption, legend, legendData);
  if (!config) return;
  var legendMaxWidth = Math.floor(((chartInstance == null ? void 0 : chartInstance.getWidth == null ? void 0 : chartInstance.getWidth()) || (chartInstance == null ? void 0 : chartInstance.getDom == null ? void 0 : (_chartInstance$getDom = chartInstance.getDom()) == null ? void 0 : _chartInstance$getDom.clientWidth) || (chartInstance == null ? void 0 : (_chartInstance$_dom = chartInstance._dom) == null ? void 0 : _chartInstance$_dom.clientWidth) || 0) * 0.4);
  var richMaxWidth = config.richMaxWidth,
    maxWidth = config.maxWidth,
    titleName = config.titleName,
    titlePaddingWidth = config.titlePaddingWidth;
  // 用户rich
  var rich = cloneDeep(textStyle.rich);
  var titleExceed = false; // title超出标识
  var titleWidth = 0; // title宽度
  var richTitle = rich == null ? void 0 : rich[titleName];
  var useTitleMaxWidth = richTitle == null ? void 0 : richTitle.width; // 用户配置宽度
  isArray(richTitle == null ? void 0 : richTitle.padding) ? Number(richTitle == null ? void 0 : richTitle.padding[1]) || 0 : Number(richTitle == null ? void 0 : richTitle.padding);
  var titleMaxWidth = (richMaxWidth == null ? void 0 : (_richMaxWidth$titleNa = richMaxWidth[titleName]) == null ? void 0 : _richMaxWidth$titleNa.maxWidth) || 0;
  // 计算title宽度
  if (legendMaxWidth < maxWidth || legendMaxWidth < maxWidth + (titlePaddingWidth || 0)) {
    // 内容大于图例最大宽 或 内容加title的padding大于图例最大宽
    titleExceed = true;
    titleWidth = titleMaxWidth - (maxWidth - legendMaxWidth) - (titlePaddingWidth || 0); // title与右边的间隙
    titleWidth = isNumber(useTitleMaxWidth) ? useTitleMaxWidth : titleWidth;
    legend.tooltip = {
      show: true
    };
  } else {
    titleWidth = isNumber(useTitleMaxWidth) ? useTitleMaxWidth : titleMaxWidth; // title与右边的间隙
  }
  // 更新rich 增加width
  for (var key in richMaxWidth) {
    var _textStyle$rich$key, _textStyle$rich, _textStyle$rich2;
    var element = richMaxWidth[key];
    // 每一项的最大宽度
    var _maxWidth = element.maxWidth || Math.max.apply(Math, element.widths);
    // title宽度为上面纠正后的宽度
    if (key === titleName && titleWidth) {
      _maxWidth = titleWidth;
    }
    // 用户传入宽度
    var useWidth = (_textStyle$rich$key = textStyle.rich[key]) == null ? void 0 : _textStyle$rich$key.width;
    // 更新内部用于截断文本用的rich，useWidth用于判断是否为用户传入宽度
    rich[key] = _extends({}, ((_textStyle$rich = textStyle.rich) == null ? void 0 : _textStyle$rich[key]) || {}, {
      useWidth: useWidth,
      width: useWidth === undefined ? _maxWidth : useWidth
    });
    // 更新option中rich
    textStyle.rich[key] = _extends({}, ((_textStyle$rich2 = textStyle.rich) == null ? void 0 : _textStyle$rich2[key]) || {}, {
      width: useWidth === undefined ? _maxWidth : useWidth
    });
  }
  legend.left = '60%'; // 开启自适应 固定位置
  legend.right = 'auto';
  legend.formatter = function (name) {
    if (formatter) {
      var text = formatter(name);
      var newText = text.replace(/\{(\w+)\|([^}]+)\}/g, function (match, styleName, content) {
        var newContent = content;
        var richItem = rich[styleName] || {};
        var widthNum = isNumber(richItem == null ? void 0 : richItem.width) ? richItem == null ? void 0 : richItem.width : undefined;
        var hasUseWidth = richItem == null ? void 0 : richItem.useWidth;
        var fontSize = (richItem.fontSize || (textStyle == null ? void 0 : textStyle.fontSize) || 12) + 'px';
        var fontWeight = (richItem == null ? void 0 : richItem.fontWeight) || (textStyle == null ? void 0 : textStyle.fontWeight) || 'normal';
        var fontFamily = (richItem == null ? void 0 : richItem.fontFamily) || (textStyle == null ? void 0 : textStyle.fontFamily) || 'Arial';
        // title的截断处理
        if (!hasUseWidth && titleExceed && styleName === 'title' && isNumber(widthNum)) {
          newContent = truncateText(content, widthNum - 10, fontSize, '...', fontFamily, fontWeight); // 10为...的占位
        }
        // 用户设置了宽度的截断处理
        if (hasUseWidth && styleName !== 'split' && isNumber(widthNum)) {
          newContent = truncateText(content, widthNum - 10, fontSize, '...', fontFamily, fontWeight); // 10为...的占位
        }
        return "{" + styleName + "|" + newContent + "}";
      });
      return newText;
    } else {
      // 未设置formatter文本也超出也会截断
      var fontSize = ((textStyle == null ? void 0 : textStyle.fontSize) || 12) + 'px';
      var fontWeight = (textStyle == null ? void 0 : textStyle.fontWeight) || 'normal';
      var fontFamily = (textStyle == null ? void 0 : textStyle.fontFamily) || 'Arial';
      var _maxWidth2 = legendMaxWidth - (titlePaddingWidth || 21);
      var newContent = truncateText(name, _maxWidth2, fontSize, '...', fontFamily, fontWeight);
      return newContent;
    }
  };
}

// 设置移动端图例
function setMobileLegend(iChartOption, legend, legendData, chartInstance) {
  var _chartInstance$getDom2, _chartInstance$_dom2, _chartInstance$getDom3, _chartInstance$_dom3;
  var config = calculateOccupancy(iChartOption, legend, legendData);
  var textStyle = legend == null ? void 0 : legend.textStyle;
  if (!config) return;
  var chartWidth = (chartInstance == null ? void 0 : chartInstance.getWidth == null ? void 0 : chartInstance.getWidth()) || (chartInstance == null ? void 0 : chartInstance.getDom == null ? void 0 : (_chartInstance$getDom2 = chartInstance.getDom()) == null ? void 0 : _chartInstance$getDom2.clientWidth) || (chartInstance == null ? void 0 : (_chartInstance$_dom2 = chartInstance._dom) == null ? void 0 : _chartInstance$_dom2.clientWidth) || 0;
  var chartHeight = (chartInstance == null ? void 0 : chartInstance.getHeight == null ? void 0 : chartInstance.getHeight()) || (chartInstance == null ? void 0 : chartInstance.getDom == null ? void 0 : (_chartInstance$getDom3 = chartInstance.getDom()) == null ? void 0 : _chartInstance$getDom3.clientHeight) || (chartInstance == null ? void 0 : (_chartInstance$_dom3 = chartInstance._dom) == null ? void 0 : _chartInstance$_dom3.clientHeight) || 0;
  var legendMaxWidth = Math.floor(chartWidth * 0.5);
  (Number(legend.itemWidth) || 8) + 6; // icon与文本的间隙
  var richMaxWidth = config.richMaxWidth,
    maxWidth = config.maxWidth,
    titleName = config.titleName,
    titlePaddingWidth = config.titlePaddingWidth,
    verticalHeight = config.verticalHeight;
  // 更新rich 增加width
  for (var key in richMaxWidth) {
    var _textStyle$rich$key2, _textStyle$rich3;
    var element = richMaxWidth[key];
    // 每一项的最大宽度
    var richWidth = element.maxWidth || Math.max.apply(Math, element.widths);
    // 用户传入宽度
    var useWidth = (_textStyle$rich$key2 = textStyle.rich[key]) == null ? void 0 : _textStyle$rich$key2.width;
    if (key === titleName && (legendMaxWidth < maxWidth || legendMaxWidth < maxWidth + (titlePaddingWidth || 0))) {
      richWidth = chartWidth - (maxWidth - richWidth) - titlePaddingWidth;
    }
    // 更新option中rich
    textStyle.rich[key] = _extends({}, ((_textStyle$rich3 = textStyle.rich) == null ? void 0 : _textStyle$rich3[key]) || {}, {
      width: useWidth === undefined ? richWidth : useWidth
    });
  }
  if (legendMaxWidth < maxWidth || legendMaxWidth < maxWidth + (titlePaddingWidth || 0)) {
    // 内容大于图例最大宽 或 内容加title的padding大于图例最大宽
    legend.left = 'center'; // 开启自适应 固定位置
    legend.right = 'auto';
    legend.top = 'auto';
    legend.bottom = 0;
    legend.orient = 'horizontal';
    var graphHeight = chartHeight - verticalHeight - 16; //图形区高度 = 总高 - 图例高度 - 间距16
    if (!iChartOption.position) iChartOption.position = {};
    iChartOption.graphHeight = graphHeight;
  } else {
    legend.left = '50%'; // 开启自适应 固定位置
    legend.right = 'auto';
    iChartOption.graphHeight = undefined;
  }
}
export { setMobileLegend, updateLegendOccupancy };
