function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import Token from '../../../feature/token/index.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 图例翻页是否使用动画和动画时长，具有共性，提取
function getUnitAnimationConfig() {
  return {
    // 是否开启动画 
    animation: Token.config.animation,
    // 数据更新动画的时长
    animationDurationUpdate: Token.config.animationDurationUpdate
  };
}

// 状态切换的动画配置
function getStateAnimation() {
  return {
    stateAnimation: {
      // 状态切换的动画时长
      duration: Token.config.stateAnimationDuration,
      // 状态切换的动画缓动
      easing: Token.config.stateAnimationEasing
    }
  };
}

// 基础的动画配置
function getBasicAnimationConfig() {
  return _extends({}, getUnitAnimationConfig(), {
    // 是否开启动画的阈值
    animationThreshold: Token.config.animationThreshold,
    // 初始动画的时长
    animationDuration: Token.config.animationDuration,
    // 初始动画的缓动效果
    animationEasing: Token.config.animationEasing,
    // 初始动画的延迟
    animationDelay: Token.config.animationDelay,
    // 数据更新动画的缓动效果
    animationEasingUpdate: Token.config.animationEasingUpdate,
    // 数据更新动画的延迟
    animationDelayUpdate: Token.config.animationDelayUpdate
  });
}
function animation() {
  return _extends({}, getBasicAnimationConfig(), getStateAnimation());
}
export { animation as default, getBasicAnimationConfig, getUnitAnimationConfig };
