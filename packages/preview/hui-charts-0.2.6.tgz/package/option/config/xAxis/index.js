import base from './base.js';
import name from './name.js';
import axisLine from './axisLine.js';
import axisLabel from './axisLabel.js';
import axisMargin from './axisMargin.js';
import boundaryGap from './boundaryGap.js';
import merge from '../../../util/merge.js';
import { toArray } from '../../../util/type.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

/**
 * 
 * @param {object} iChartOpt  图标的配置项
 * @param {Function} callBack 用于在merge外部iChartOpt的配置和内部默认配置之前根据不用类型图表对默认配置进行操作
 * @returns x轴的配置
 */
function xAxis(iChartOpt, callBack) {
  var xAxisResult = iChartOpt.xAxis || {};
  xAxisResult = toArray(xAxisResult).map(function (xAxisItem, xAxisItemIndex) {
    var xAxisUnit = base();
    // 坐标轴名称
    name(xAxisUnit, xAxisItem, iChartOpt);
    // 坐标轴两边留白策略
    boundaryGap(xAxisUnit, xAxisItem, iChartOpt);
    // 刻度标签
    axisLabel(xAxisUnit, xAxisItem, iChartOpt);
    // 坐标轴刻度
    axisLine(xAxisUnit, xAxisItem, iChartOpt);
    // 坐标轴前后留白
    axisMargin(xAxisUnit, xAxisItem);
    callBack && callBack(xAxisUnit, xAxisItemIndex);
    // 覆盖属性
    merge(xAxisUnit, xAxisItem);
    return xAxisUnit;
  });
  return xAxisResult;
}
export { xAxis as default };
