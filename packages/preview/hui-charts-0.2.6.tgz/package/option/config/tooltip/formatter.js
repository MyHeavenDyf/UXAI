import defendXSS from '../../../util/defendXSS.js';
import Token from '../../../feature/token/index.js';
import { isObject } from '../../../util/type.js';
function validateName(name) {
  return name !== null && name !== undefined && name !== '';
}

// 暂时不校验''
function formatValue(value) {
  if (isObject(value)) {
    value = value.value;
  }
  if (value === null || value === undefined || value === '') {
    return '--';
  }
  return value;
}

// 移动端tooltip关闭按钮
function getCloseIcon(tooltipCloseColor) {
  if (tooltipCloseColor === void 0) {
    tooltipCloseColor = '#808080';
  }
  return "<svg width=\"16px\" height=\"16px\" viewBox=\"0 0 16 16\" fill=\"none\" customFrame=\"#000000\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">\n      <rect id=\"close\" width=\"16\" height=\"16\" x=\"0\" y=\"0\"/>\n      <g id=\"\u7EC4\u5408 1\">\n          <path id=\"\u76F4\u7EBF 1\" d=\"M0 0L12 0\" stroke=\"" + tooltipCloseColor + "\" stroke-linecap=\"round\" stroke-width=\"1\" transform=\"matrix(0.707107,0.707107,-0.707107,0.707107,3.75,3.75)\" />\n          <path id=\"\u76F4\u7EBF 1\" d=\"M0 0L12 0\" stroke=\"" + tooltipCloseColor + "\" stroke-linecap=\"round\" stroke-width=\"1\" transform=\"matrix(-0.707107,0.707107,-0.707107,-0.707107,12.2354,3.75)\" />\n      </g>\n    </svg>";
}
function getDataHtmlStr(dataConfig) {
  var _Token$config = Token.config,
    tooltipIconGap = _Token$config.tooltipIconGap,
    tooltipValueGap = _Token$config.tooltipValueGap,
    legendCircleItemHeight = _Token$config.legendCircleItemHeight,
    tooltipDataNameColor = _Token$config.tooltipDataNameColor,
    tooltipValueColor = _Token$config.tooltipValueColor;
  var iconColor = dataConfig.iconColor,
    name = dataConfig.name,
    _dataConfig$nameColor = dataConfig.nameColor,
    nameColor = _dataConfig$nameColor === void 0 ? tooltipDataNameColor : _dataConfig$nameColor,
    value = dataConfig.value,
    _dataConfig$valueColo = dataConfig.valueColor,
    valueColor = _dataConfig$valueColo === void 0 ? tooltipValueColor : _dataConfig$valueColo,
    _dataConfig$unit = dataConfig.unit,
    unit = _dataConfig$unit === void 0 ? '' : _dataConfig$unit,
    _dataConfig$unitColor = dataConfig.unitColor,
    unitColor = _dataConfig$unitColor === void 0 ? tooltipValueColor : _dataConfig$unitColor,
    type = dataConfig.type;
  var iconStr = '',
    unitStr = '',
    iconStyle = '';
  if (type === 'line') {
    iconStyle = "width:" + (legendCircleItemHeight + 2) + "px;height:2px;";
  } else {
    iconStyle = "width:" + legendCircleItemHeight + "px;height:" + legendCircleItemHeight + "px;border-radius:50%;";
  }
  if (iconColor) {
    iconStr = "<div style=\"background-color:" + defendXSS(iconColor) + ";" + iconStyle + "\"></div>";
  }
  if (unit) {
    unitStr = "<span style=\"font-weight:bold;color:" + unitColor + ";\">" + defendXSS(unit) + "</span>";
  }
  var validateVal = formatValue(value);
  return "<div style=\"display:flex;align-items:center;justify-content:space-between;gap:" + tooltipValueGap + "px\">\n                      <div style=\"display:flex;gap:" + tooltipIconGap + "px;align-items:center;\">\n                      " + iconStr + "\n                      <span style=\"display:inline-block;color:" + nameColor + ";\">" + defendXSS(name) + "</span>\n                      </div>\n                      <div style=\"display:flex;\">\n                      <span style=\"font-weight:bold;color:" + valueColor + ";\">" + defendXSS(validateVal) + "</span>\n                      " + unitStr + "\n                      </div> \n            </div>";
}
function getTooltipContentHtmlStr(tipConfig, tooltip) {
  var _Token$config2 = Token.config,
    tooltipItemGap = _Token$config2.tooltipItemGap,
    tooltipTitleColor = _Token$config2.tooltipTitleColor,
    tooltipCloseColor = _Token$config2.tooltipCloseColor;
  var title = tipConfig.title,
    _tipConfig$titleColor = tipConfig.titleColor,
    titleColor = _tipConfig$titleColor === void 0 ? tooltipTitleColor : _tipConfig$titleColor,
    children = tipConfig.children,
    hideEmpty = tipConfig.hideEmpty,
    isMobile = tipConfig.isMobile;
  var content = '';
  if (validateName(title)) {
    content = "<div class=\"hui-charts-tooltip-title\" style=\"color:" + titleColor + "\">" + defendXSS(title) + "</div>";
  }
  if ((tooltip == null ? void 0 : tooltip.order) === 'seriesDesc') {
    children = children.reverse();
  }
  if (children && children.length !== 0) {
    for (var index = 0; index < children.length; index++) {
      var item = children[index];
      if (hideEmpty && (item.value === null || item.value === undefined || item.value === '')) continue;
      content += getDataHtmlStr(item);
    }
  }
  if (isMobile) {
    content += "<div class=\"hui-charts-tooltip-close\">" + getCloseIcon(tooltipCloseColor) + "</div>";
  }
  var htmlString = "<div class=\"hui-charts-tooltip-container\" style=\"display:flex;flex-direction:column;gap:" + tooltipItemGap + "px;\">" + content + "</div>";
  return htmlString;
}
export { getTooltipContentHtmlStr as default, formatValue, getCloseIcon, getDataHtmlStr, validateName };
