import grid from '../config/grid/index.js';
import xAxis from '../config/xAxis/index.js';
import yAxis from '../config/yAxis/index.js';
import legend from '../config/legend/index.js';
import tooltip from '../config/tooltip/index.js';
import datazoom from '../config/datazoom/index.js';
import toolbox from '../config/toolbox/index.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 组装直角坐标系所需的基础配置
function RectCoordSys(baseOpt, iChartOpt, chartName, chartInstance) {
  // 图表padding
  baseOpt.grid = grid(iChartOpt);
  // 图表基础颜色
  baseOpt.color = iChartOpt.color;
  // 图表x坐标轴
  baseOpt.xAxis = xAxis(iChartOpt);
  // 图表y坐标轴
  baseOpt.yAxis = yAxis(baseOpt, iChartOpt, chartName);
  // 图表鼠标悬浮提示框
  baseOpt.tooltip = tooltip(iChartOpt, chartName);
  // 图表图例
  baseOpt.legend = legend(iChartOpt, chartName, chartInstance);
  // 图表datazoom
  baseOpt.dataZoom = datazoom(iChartOpt);
  // 图表toolbox
  baseOpt.toolbox = toolbox(iChartOpt);
}
export { RectCoordSys as default };
