/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
/**
 * 循环取出颜色
 */
function getColor(colors, index) {
  return colors[index % colors.length];
}

/**
 * 十六进制转rgba, 如codeToRGB("#6d8ff0",0.5) --> 'rgba(109,143,240,0.5)'
 */
function codeToRGB(code, opacity) {
  if (code === undefined) {
    return undefined;
  }
  if (code.includes('rgb')) {
    return changeRgbaOpacity(code, opacity);
  }
  var result = [];
  result.push(parseInt(code.substring(1, 3), 16));
  result.push(parseInt(code.substring(3, 5), 16));
  result.push(parseInt(code.substring(5), 16));
  return "rgba(" + result.join(',') + "," + opacity + ")";
}

/**
 * rgba转十六进制 codeToHex('rgba(255,0,0,.5)') --> '#fffcfc'
 * 将red、blue等转换为十六进制
 */
function codeToHex(color) {
  switch (color) {
    case 'red':
      return '#ff0000';
    case 'blue':
      return '#0000ff';
    case 'green':
      return '#00ff00';
    case 'pink':
      return '#FFC0CB';
    case 'yellow':
      return '#FFFF00';
    case 'orange':
      return '#FFA500';
    case 'black':
      return '#000000';
    case 'white':
      return '#ffffff';
    case 'gray':
      return '#808080';
    case 'purple':
      return '#800080';
  }
  if (color.includes('#')) {
    if (color.length === 7) {
      return color;
    } else if (color.length === 4) {
      return color[0] + color[1] + color[1] + color[2] + color[2] + color[3] + color[3];
    }
  }
  var values = color.replace(/rgba?\(/, '').replace(/\)/, '').replace(/[\s+]/g, '').split(',');
  var a = parseFloat(values[3] || 1);
  var r = Math.floor(a * parseInt(values[0]) + (1 - a) * 255);
  var g = Math.floor(a * parseInt(values[1]) + (1 - a) * 255);
  var b = Math.floor(a * parseInt(values[2]) + (1 - a) * 255);
  return "#" + ("0" + r.toString(16)).slice(-2) + ("0" + g.toString(16)).slice(-2) + ("0" + b.toString(16)).slice(-2);
}

/**
 * 修改 'rgba(109,143,240,0.5)' 格式下的颜色透明度
 */
function changeRgbaOpacity(rgba, opacity) {
  var _rgba$match = rgba.match(/\d+(\.\d+)?/g),
    r = _rgba$match[0],
    g = _rgba$match[1],
    b = _rgba$match[2];
  return "rgba(" + r + "," + g + "," + b + "," + opacity + ")";
}

/**
 * 
 * 将color转换6位16进制格式
 */
function transColor(colorStr) {
  // 使用正则表达式提取颜色代码中的每个字符
  var regex = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
  var matches = colorStr.match(regex);

  // 如果匹配到了 3 个字符，则将其每个字符重复一遍
  if (matches) {
    return "#" + matches[1] + matches[1] + matches[2] + matches[2] + matches[3] + matches[3];
  }

  // 如果颜色代码格式不正确，则直接返回原来的代码
  return colorStr;
}

// 获取两种颜色的混合之后的颜色。ratio为后者的颜色占比，默认0.5，两者比例各占50%去混合
var getMixColor = function getMixColor(c1, c2, ratio) {
  if (ratio === void 0) {
    ratio = 0.5;
  }
  if (typeof c1 !== 'string' || typeof c2 !== 'string') return '';
  var color1 = codeToHex(c1);
  var color2 = codeToHex(c2);
  var r1 = parseInt(color1.substring(1, 3), 16);
  var g1 = parseInt(color1.substring(3, 5), 16);
  var b1 = parseInt(color1.substring(5, 7), 16);
  var r2 = parseInt(color2.substring(1, 3), 16);
  var g2 = parseInt(color2.substring(3, 5), 16);
  var b2 = parseInt(color2.substring(5, 7), 16);
  var r = Math.round(r1 * (1 - ratio) + r2 * ratio);
  var g = Math.round(g1 * (1 - ratio) + g2 * ratio);
  var b = Math.round(b1 * (1 - ratio) + b2 * ratio);
  r = ('0' + (r || 0).toString(16)).slice(-2);
  g = ('0' + (g || 0).toString(16)).slice(-2);
  b = ('0' + (b || 0).toString(16)).slice(-2);
  return '#' + r + g + b;
};
export { changeRgbaOpacity, codeToHex, codeToRGB, getColor, getMixColor, transColor };
