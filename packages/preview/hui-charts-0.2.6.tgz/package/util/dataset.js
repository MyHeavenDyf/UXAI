import { isArray, isObject } from './type.js';
import Token from '../feature/token/index.js';
import { CHART_TYPE } from './constants.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

var DEFAULT_KEY = 'product';
var getDatasetData = function getDatasetData(option) {
  if (option.dataset && option.dataset.source) {
    var source = option.dataset.source;
    var headers = source[0];
    var data = [];

    // source为二维数组，需要将二维数组转对象数组，转成标准的data格式
    if (isArray(headers)) {
      data = source.slice(1).map(function (row) {
        var obj = {};
        headers.forEach(function (header, index) {
          obj[header] = row[index];
        });
        return obj;
      });
    } else if (isObject(headers)) {
      data = source;
    }
    option.data = data;
    var series = option.series;
    // series.encode维度映射
    if (series && isArray(series) && series[0].encode) {
      var encode = series[0].encode;
      option.direction = 'horizontal';
      var chartToken = Token.getChartTokenByName(CHART_TYPE.BAR);
      series[0].itemStyle = {
        borderRadius: [0, chartToken.borderRadius, chartToken.borderRadius, 0]
      };
      xAxisName(option, encode.y);
      var encodeKeys = [encode.x, encode.y];
      option.data.forEach(function (item) {
        Object.keys(item).forEach(function (key) {
          if (!encodeKeys.includes(key)) {
            delete item[key];
          }
        });
      });
    } else {
      xAxisName(option, DEFAULT_KEY);
    }
    return option;
  }
  return option;
};
var xAxisName = function xAxisName(option, name) {
  if (option.xAxis) {
    option.xAxis.data = name;
  } else {
    option.xAxis = {
      data: name
    };
  }
};
export { getDatasetData };
