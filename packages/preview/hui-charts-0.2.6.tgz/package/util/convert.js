/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var pxToNumber = function pxToNumber(pxText) {
  return pxText.split('px')[0] - 0;
};

// 日期格式化
var formatDate = function formatDate(date, fmt) {
  var padZero = function padZero(value) {
    return value < 10 ? "0" + value : value;
  };
  var year = date.getFullYear();
  var month = padZero(date.getMonth() + 1);
  var day = padZero(date.getDate());
  var hour = padZero(date.getHours());
  var minute = padZero(date.getMinutes());
  var second = padZero(date.getSeconds());
  var millisecond = padZero(date.getMilliseconds());
  return fmt.replace(/y+/, year).replace(/M+/, month).replace(/d+/, day).replace(/h+/, hour).replace(/m+/, minute).replace(/s+/, second).replace(/S/, millisecond);
};

//SVG转base64
function svgTransform(svgData) {
  var svgBlob = new Blob([svgData], {
    type: 'image/svg+xml'
  });
  var svgUrl = URL.createObjectURL(svgBlob);
  return svgUrl;
}
export { formatDate, pxToNumber, svgTransform };
