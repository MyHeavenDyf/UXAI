// 判断是否是移动端
function mobile() {
  var userAgent = /Mobi|Android|iPhone/i.test(navigator.userAgent);
  return userAgent;
}
export { mobile as default };
