/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
// 对canvas的画笔的简单封装
var Paint = /*#__PURE__*/function () {
  function Paint(ctx) {
    this.ctx = null;
    this.ctx = ctx;
  }
  var _proto = Paint.prototype;
  _proto.beginPath = function beginPath() {
    this.ctx.beginPath();
  };
  _proto.closePath = function closePath() {
    this.ctx.closePath();
  };
  _proto.moveTo = function moveTo(x, y) {
    this.ctx.moveTo(x, y);
  };
  _proto.lineTo = function lineTo(x, y) {
    this.ctx.lineTo(x, y);
  };
  _proto.lineCap = function lineCap(type) {
    this.ctx.lineCap = type;
  };
  _proto.stroke = function stroke() {
    this.ctx.stroke();
  };
  _proto.lineJoin = function lineJoin(type) {
    this.ctx.lineJoin = type;
  };
  _proto.lineWidth = function lineWidth(nub) {
    this.ctx.lineWidth = nub;
  };
  _proto.fill = function fill() {
    this.ctx.fill();
  };
  _proto.save = function save() {
    this.ctx.save();
  };
  _proto.restore = function restore() {
    this.ctx.restore();
  };
  _proto.translate = function translate(x, y) {
    this.ctx.translate(x, y);
  };
  _proto.createLinearGradient = function createLinearGradient(x0, y0, x1, y1) {
    return this.ctx.createLinearGradient(x0, y0, x1, y1);
  };
  _proto.clearRect = function clearRect(x, y, width, height) {
    this.ctx.clearRect(x, y, width, height);
  };
  _proto.rect = function rect(x, y, width, height) {
    this.ctx.rect(x, y, width, height);
  };
  _proto.strokeStyle = function strokeStyle(color) {
    this.ctx.strokeStyle = color;
  };
  _proto.arc = function arc(x, y, radius, startAngle, endAngle, anticlockwise) {
    if (anticlockwise === void 0) {
      anticlockwise = false;
    }
    this.ctx.arc(x, y, radius, startAngle, endAngle, anticlockwise);
  };
  _proto.fillStyle = function fillStyle(color) {
    this.ctx.fillStyle = color;
  };
  _proto.clip = function clip() {
    this.ctx.clip();
  };
  _proto.createRadialGradient = function createRadialGradient(x0, y0, r0, x1, y1, r1) {
    return this.ctx.createRadialGradient(x0, y0, r0, x1, y1, r1);
  };
  return Paint;
}();
export { Paint as default };
