/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var MOUSE_EVENT_NAMES = ['click', 'dblclick', 'mousedown', 'mousemove', 'mouseup', 'mouseover', 'mouseout', 'globalout', 'contextmenu'];

// 绑定图表事件
function event(chartInstance, event) {
  if (!event) return;
  MOUSE_EVENT_NAMES.forEach(function (eventName) {
    chartInstance.off(eventName);
  });
  var queryKeys = Object.keys(event);
  queryKeys.forEach(function (qrKey) {
    var eKeys = Object.keys(event[qrKey]);
    eKeys.forEach(function (key) {
      chartInstance.on(key, qrKey, function (params) {
        event[qrKey][key](params);
      });
    });
  });
}
export { event };
