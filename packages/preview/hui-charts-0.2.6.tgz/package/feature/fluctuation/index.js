import { isArray } from '../../util/type.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 获取新的数据格式
var transformData = function transformData(origindata) {
  var newData = {};
  var count = Object.keys(origindata[0]).length;
  var _loop = function _loop(i) {
    var arr = [];
    origindata.forEach(function (key) {
      var firstKey = Object.keys(key)[i];
      var firstValue = key[firstKey];
      arr.push(firstValue);
      newData[firstKey] = arr;
    });
  };
  for (var i = 1; i < count; i++) {
    _loop(i);
  }
  return newData;
};

// 修改轴数据 data：图表数据 allowRange：允许轴的范围
var fluctuation = function fluctuation(data, allowRange) {
  var min = Infinity;
  var max = -Infinity;
  var range = allowRange || [-Infinity, Infinity];
  var dataKeys = Object.keys(data);
  dataKeys.forEach(function (key) {
    data[key].forEach(function (item) {
      if (isArray(item)) {
        var arr = item.filter(function (t) {
          return !isNaN(Number(t)) && Number(t) > range[0] && Number(t) < range[1];
        });
        var curMin = Math.min.apply(Math, arr);
        var curMax = Math.max.apply(Math, arr);
        min = Math.min(min, curMin);
        max = Math.max(max, curMax);
      } else {
        var num = Number(item);
        if (num < range[0] || num > range[1]) {
          return;
        }
        min = Math.min(min, num);
        max = Math.max(max, num);
      }
    });
  });
  var axisMin = Math.floor(min - (max - min) / 5 * 4);
  if (min > 0 && axisMin < 0) {
    axisMin = 0;
  }
  var axisMax = Math.ceil(max + (max - min) / 5);
  return [axisMin, axisMax];
};
export { fluctuation as default, transformData };
