import SingleSelect from '../singleSelect/index.js';
import { SVG_ICON, CSS_CLASS } from './constants.js';
import { uuid } from '../../../util/math.js';
import { svgTransform } from '../../../util/convert.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 创建更多按钮
function more() {
  var _this = this;
  var more = document.createElement("div");
  var moreIcon = document.createElement("img");
  more.id = "more-" + uuid();
  moreIcon.src = svgTransform(SVG_ICON.EVEN_MORE);
  more.classList.add(CSS_CLASS.MORE);
  more.appendChild(moreIcon);
  var dropdown = new SingleSelect(more);
  dropdown.setOption({
    data: this.data,
    color: this.color,
    itemStyle: this.itemStyle,
    // 点击触发的事件
    onclick: function onclick(data) {
      _this.onclick(data);
    }
  });
  return more;
}
export { more as default };
