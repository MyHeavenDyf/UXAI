import { CSS_CLASS, SVG_ICON, CLOUD_SVG_ICON } from './constants.js';
import { svgTransform } from '../../../util/convert.js';
import Token from '../../token/index.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 创建分页
function createPaging() {
  var _this$theme,
    _this = this;
  // 默认初始位置
  this.current = 0;
  var isHdesign = (_this$theme = this.theme) == null ? void 0 : _this$theme.includes('hdesign');
  var iconColor = Token.config.legendPageIconColor;
  var iconInactiveColor = Token.config.legendPageIconInactiveColor;
  // 创建paing
  var paging = document.createElement("div");
  paging.classList.add(CSS_CLASS.PAGING);

  // paing中间的文字
  var pagingText = document.createElement("span");
  pagingText.classList.add(CSS_CLASS.PAGING_TEXT);
  pagingText.innerText = "1/2";

  // paging左右按钮的盒子
  var pagingLeft = document.createElement("div");
  var pagingRight = document.createElement("div");
  pagingLeft.classList.add(CSS_CLASS.PAGING_LEFT);
  pagingRight.classList.add(CSS_CLASS.PAGING_RIGHT);

  // paing的左右按钮
  var pagingLeftIcon = document.createElement("img");
  var pagingRightIcon = document.createElement("img");
  pagingLeftIcon.src = svgTransform(SVG_ICON.LEFT_ARROW);
  pagingRightIcon.src = svgTransform(SVG_ICON.RIGHT_ARROW);
  pagingLeftIcon.classList.add(CSS_CLASS.PAGING_ICON);
  pagingRightIcon.classList.add(CSS_CLASS.PAGING_ICON);
  pagingLeft.append(pagingLeftIcon);
  pagingRight.append(pagingRightIcon);
  if (isHdesign) {
    pagingLeft.innerHTML = "";
    pagingLeft.innerHTML = CLOUD_SVG_ICON.LEFT_ARROW;
    pagingLeft.setAttribute('style', "--pagingIconColor: " + iconInactiveColor + ";");
    pagingRight.innerHTML = "";
    pagingRight.innerHTML = CLOUD_SVG_ICON.RIGHT_ARROW;
    pagingRight.setAttribute('style', "--pagingIconColor: " + iconColor + ";");
  }

  // paing左按钮点击事件
  pagingLeft.addEventListener("click", function (e) {
    var iconColor = Token.config.legendPageIconColor;
    var iconInactiveColor = Token.config.legendPageIconInactiveColor;
    e.stopPropagation();
    if (_this.current >= 1) {
      var _this$theme2;
      _this.current--;
      var _isHdesign = (_this$theme2 = _this.theme) == null ? void 0 : _this$theme2.includes('hdesign');
      // 展示当前分组页的图例
      _this.group[_this.current][_this.group[_this.current].length - 1].scrollIntoView({
        behavior: "smooth",
        block: "nearest",
        inline: "end"
      });
      pagingText.innerText = _this.current + 1 + "/" + _this.group.length;

      // 左按钮是否置灰
      if (_this.current === 0) {
        if (_isHdesign) {
          pagingLeft.setAttribute('style', "--pagingIconColor: " + iconInactiveColor + ";");
        } else {
          pagingLeftIcon.src = svgTransform(SVG_ICON.LEFT_ARROW);
          pagingLeftIcon.classList.remove(CSS_CLASS.PAGING_ICON_ROTATE);
        }
      }
      if (_isHdesign) {
        pagingRight.setAttribute('style', "--pagingIconColor: " + iconColor + ";");
      } else {
        pagingRightIcon.src = svgTransform(SVG_ICON.RIGHT_ARROW);
        pagingRightIcon.classList.remove(CSS_CLASS.PAGING_ICON_ROTATE);
      }
    }
  });

  // paing右按钮点击事件
  pagingRight.addEventListener("click", function (e) {
    var iconColor = Token.config.legendPageIconColor;
    var iconInactiveColor = Token.config.legendPageIconInactiveColor;
    e.stopPropagation();
    if (_this.current < _this.group.length - 1) {
      var _this$theme3;
      _this.current++;
      var _isHdesign2 = (_this$theme3 = _this.theme) == null ? void 0 : _this$theme3.includes('hdesign');
      // 展示当前分组页的图例
      _this.group[_this.current][_this.group[_this.current].length - 1].scrollIntoView({
        behavior: "smooth",
        block: "nearest",
        inline: "end"
      });
      pagingText.innerText = _this.current + 1 + "/" + _this.group.length;

      // 右按钮是否置灰
      if (_this.current + 1 === _this.group.length) {
        if (_isHdesign2) {
          pagingRight.setAttribute('style', "--pagingIconColor: " + iconInactiveColor + ";");
        } else {
          pagingRightIcon.src = svgTransform(SVG_ICON.LEFT_ARROW);
          pagingRightIcon.classList.add(CSS_CLASS.PAGING_ICON_ROTATE);
        }
      }
      if (_isHdesign2) {
        pagingLeft.setAttribute('style', "--pagingIconColor: " + iconColor + ";");
      } else {
        pagingLeftIcon.src = svgTransform(SVG_ICON.RIGHT_ARROW);
      }
      pagingLeftIcon.classList.add(CSS_CLASS.PAGING_ICON_ROTATE);
    }
  });

  // 插入paign的dom
  paging.append(pagingLeft, pagingText, pagingRight);
  this.paging = paging;
  this.pagingText = pagingText;
  this.pagingLeftIcon = pagingLeftIcon;
  this.pagingRightIcon = pagingRightIcon;
  this.pagingLeft = pagingLeft;
  this.pagingRight = pagingRight;
  return paging;
}
export { createPaging as default };
