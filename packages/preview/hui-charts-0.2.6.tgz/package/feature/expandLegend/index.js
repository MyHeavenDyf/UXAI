function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import MutiSelectLegend from './mutiSelectLegend/index.js';
import MutiSelectList from './mutiSelectList/index.js';
import { CSS_CLASS } from './constants.js';
import SingleSelectLegend from './singleSelectLegend/index.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
// echarts图例切换事件名
var LEGEND_TOGGLE_SELECT = "legendToggleSelect";
function expandLegend(chartsIns) {
  var _option$legend, _option$legend$upgrad;
  var dom = chartsIns.dom,
    option = chartsIns.eChartOption;
  var preContainer = dom.querySelector("." + CSS_CLASS.CONTAINER);
  preContainer && dom.removeChild(preContainer);
  if ((option == null ? void 0 : (_option$legend = option.legend) == null ? void 0 : (_option$legend$upgrad = _option$legend.upgrade) == null ? void 0 : _option$legend$upgrad.type) === undefined) return;
  // 将图表原有的图例隐藏
  option.legend = _extends({}, option.legend, {
    show: false
  });
  // 开始渲染
  var type = option.legend.upgrade.type;
  switch (type) {
    case "mutiselect":
      createMutiSelect(chartsIns);
      break;
    case "list":
      createList(chartsIns);
      break;
    case "singleselect":
      createSingleSelectLegend(chartsIns);
      break;
  }
}
function createMutiSelect(chartsIns) {
  var _option$legend2, _option$series$;
  var dom = chartsIns.dom,
    option = chartsIns.eChartOption,
    iChartOption = chartsIns.iChartOption;
  var width = option.legend.upgrade.width;
  var container = document.createElement("div");
  container.classList.add(CSS_CLASS.CONTAINER);
  if (iChartOption != null && iChartOption.theme.includes('hdesign')) {
    container.classList.add('hdesign');
    container.classList.add(iChartOption.theme);
  }
  var legendBar = document.createElement("div");
  legendBar.classList.add(CSS_CLASS.MUTISELECT_CONTAINER);
  if (width && typeof width === "string") {
    legendBar.style.width = width;
  }
  container.append(legendBar);
  dom.insertAdjacentHTML("afterbegin", container.outerHTML);
  var mutiSelect = new MutiSelectLegend(dom.querySelector("." + CSS_CLASS.MUTISELECT_CONTAINER));
  var data = option == null ? void 0 : (_option$legend2 = option.legend) == null ? void 0 : _option$legend2.data;
  if (data === undefined) data = option == null ? void 0 : (_option$series$ = option.series[0]) == null ? void 0 : _option$series$.data;
  mutiSelect.setOption({
    theme: iChartOption.theme || '',
    data: [].concat(data),
    color: [].concat(option.color),
    itemStyle: option.legend.upgrade.itemStyle,
    onclick: function onclick(clickItem) {
      var _option$legend3;
      if (((_option$legend3 = option.legend) == null ? void 0 : _option$legend3.selected) === undefined) option.legend.selected = {};
      option.legend.selected[clickItem.name] = clickItem.selected;
      chartsIns.setOption(option);
    },
    onLegendClick: function onLegendClick(clickItem) {
      chartsIns.getEchartsInstance().dispatchAction({
        type: LEGEND_TOGGLE_SELECT,
        name: clickItem.name
      });
    }
  });
}
function createList(chartsIns) {
  var _option$legend4, _option$legend4$upgra, _option$legend6;
  var dom = chartsIns.dom,
    option = chartsIns.eChartOption,
    iChartOption = chartsIns.iChartOption;
  var container = document.createElement("div");
  container.classList.add(CSS_CLASS.LIST_CONTAINER);
  if (iChartOption != null && iChartOption.theme.includes('hdesign')) {
    container.classList.add('hdesign');
  }
  if ((option == null ? void 0 : (_option$legend4 = option.legend) == null ? void 0 : (_option$legend4$upgra = _option$legend4.upgrade) == null ? void 0 : _option$legend4$upgra.position) === "underCanvas") {
    dom.insertAdjacentHTML("beforeend", container.outerHTML);
    dom.parentNode.querySelector("." + CSS_CLASS.LIST_CONTAINER).style.width = "100%";
    dom.parentNode.querySelector("." + CSS_CLASS.LIST_CONTAINER).style.position = "static";
  } else {
    var _option$legend5, _option$legend5$upgra;
    dom.insertAdjacentHTML("afterbegin", container.outerHTML);
    // 图表默认距离右边35%，图例列表宽30%
    if (!option.grid) {
      option.grid = [{
        bottom: 0,
        left: 0,
        right: "35%",
        top: 0
      }];
    }
    if (option != null && (_option$legend5 = option.legend) != null && (_option$legend5$upgra = _option$legend5.upgrade) != null && _option$legend5$upgra.width) {
      dom.parentNode.querySelector("." + CSS_CLASS.LIST_CONTAINER).style.width = option.legend.upgrade.width;
      option.grid[0].right = Number(option.legend.upgrade.width.split("%")[0]) + 5 + "%";
    }
  }
  var list = new MutiSelectList(dom.parentNode.querySelector("." + CSS_CLASS.LIST_CONTAINER));
  var data = option == null ? void 0 : (_option$legend6 = option.legend) == null ? void 0 : _option$legend6.data;
  if (data === undefined) {
    var _option$series$2;
    data = option == null ? void 0 : (_option$series$2 = option.series[0]) == null ? void 0 : _option$series$2.data;
  }
  list.setOption({
    theme: iChartOption.theme || '',
    data: [].concat(data),
    itemStyle: option.legend.upgrade.itemStyle,
    color: [].concat(option.color),
    height: dom.style.height,
    statistics: option.legend.upgrade.statistics,
    onclick: function onclick(clickItem) {
      chartsIns.getEchartsInstance().dispatchAction({
        type: LEGEND_TOGGLE_SELECT,
        name: clickItem.name
      });
    }
  });
}
function createSingleSelectLegend(chartsIns) {
  var _option$legend7, _option$series$3;
  var dom = chartsIns.dom,
    option = chartsIns.eChartOption,
    iChartOption = chartsIns.iChartOption;
  var width = option.legend.upgrade.width;
  var container = document.createElement("div");
  container.classList.add(CSS_CLASS.CONTAINER);
  if (iChartOption != null && iChartOption.theme.includes('hdesign')) {
    container.classList.add('hdesign');
  }
  var legendBar = document.createElement("div");
  legendBar.classList.add(CSS_CLASS.SINGLESELECT_CONTAINER);
  if (width && typeof width === "string") {
    legendBar.style.width = width;
  }
  container.append(legendBar);
  dom.insertAdjacentHTML("afterbegin", container.outerHTML);
  var singleSelect = new SingleSelectLegend(dom.querySelector("." + CSS_CLASS.SINGLESELECT_CONTAINER));
  var data = option == null ? void 0 : (_option$legend7 = option.legend) == null ? void 0 : _option$legend7.data;
  if (data === undefined) data = option == null ? void 0 : (_option$series$3 = option.series[0]) == null ? void 0 : _option$series$3.data;
  singleSelect.setOption({
    theme: iChartOption.theme || '',
    data: [].concat(data),
    color: [].concat(option.color),
    itemStyle: option.legend.upgrade.itemStyle,
    onclick: function onclick(clickItem) {
      chartsIns.getEchartsInstance().dispatchAction({
        type: LEGEND_TOGGLE_SELECT,
        name: clickItem.name
      });
    },
    onLegendClick: function onLegendClick(clickItem) {
      chartsIns.getEchartsInstance().dispatchAction({
        type: LEGEND_TOGGLE_SELECT,
        name: clickItem.name
      });
    }
  });
}
export { expandLegend as default };
