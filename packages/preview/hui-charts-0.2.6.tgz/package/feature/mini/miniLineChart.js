import { isArray } from '../../util/type.js';
import merge from '../../util/merge.js';

// 微型场景下，不显示不必要的图元
function miniLine(iChartOption, baseOption) {
  // if (iChartOption.mini) {
  var mini = iChartOption.mini,
    padding = iChartOption.padding,
    legend = iChartOption.legend,
    title = iChartOption.title,
    tooltip = iChartOption.tooltip,
    yAxis = iChartOption.yAxis;
  baseOption.grid.forEach(function (item) {
    Object.assign(item, {
      top: mini ? 1 : (padding == null ? void 0 : padding[0]) || 0,
      right: mini ? 0 : (padding == null ? void 0 : padding[1]) || 0,
      bottom: mini ? 1 : (padding == null ? void 0 : padding[2]) || 0,
      left: mini ? 0 : (padding == null ? void 0 : padding[3]) || 0,
      containLabel: !mini
    });
  });
  baseOption.legend = Object.assign(baseOption.legend, {
    show: mini ? false : (legend == null ? void 0 : legend.show) || true
  });
  baseOption.title = merge(baseOption.title, {
    show: mini ? false : (title == null ? void 0 : title.show) || true
  });
  // baseOption.tooltip = Object.assign(baseOption.tooltip, {
  //   show: mini ? false : (tooltip?.show || true)
  // });
  if (!isArray(baseOption.xAxis)) {
    baseOption.xAxis = [baseOption.xAxis];
  }
  if (!isArray(baseOption.yAxis)) {
    baseOption.yAxis = [baseOption.yAxis];
  }
  baseOption.xAxis.forEach(function (item) {
    Object.assign(item, {
      show: !mini,
      boundaryGap: false
    });
  });
  baseOption.yAxis.forEach(function (item) {
    Object.assign(item, {
      show: !mini,
      max: mini ? 'dataMax' : yAxis != null && yAxis.max ? yAxis == null ? void 0 : yAxis.max : function () {
        return null;
      },
      min: 'dataMin'
    });
  });
  baseOption.dataZoom.forEach(function (item) {
    Object.assign(item, {
      show: mini ? false : iChartOption.dataZoom.show
    });
  });
  // }
}
export { miniLine as default };
