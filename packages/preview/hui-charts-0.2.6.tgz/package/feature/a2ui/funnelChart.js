function getBarDefOpt(iChartOpt) {
  var defOption = {
    padding: [32, 2, 0, 2],
    theme: 'hdesign-light',
    adaptive: true,
    label: {
      color: '#ffffff'
    },
    legend: {
      show: true,
      position: {
        left: 'center',
        bottom: 2
      }
    }
  };
  return defOption;
}
export { getBarDefOpt as default };
