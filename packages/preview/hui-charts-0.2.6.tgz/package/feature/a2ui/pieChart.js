function getPieDefOpt(iChartOpt) {
  var defOption = {
    padding: [20, 0, 10, 0],
    theme: 'hdesign-light',
    adaptive: true,
    label: {
      show: false
    },
    title: {
      itemGap: 6
    }
  };
  return defOption;
}
export { getPieDefOpt as default };
