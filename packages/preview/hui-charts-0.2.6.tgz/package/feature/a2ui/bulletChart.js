function getBarDefOpt(iChartOpt) {
  var defOption = {
    padding: [32, 2, 0, 2],
    theme: 'hdesign-light',
    adaptive: true,
    background: [{
      name: 'error',
      data: 100
    }, {
      name: 'warning',
      data: 200
    }, {
      name: 'subwarning',
      data: 300
    }, {
      name: 'success',
      data: 400
    }],
    tooltip: {
      show: true
    },
    yAxis: {
      splitNumber: 4
    },
    xAxis: {
      axisLabel: {
        interval: 'auto'
      }
    }
  };
  if (iChartOpt.direction === 'horizontal') {
    defOption.yAxis.axisLabel = {
      alignMaxLabel: 'right'
    };
  }
  return defOption;
}
export { getBarDefOpt as default };
