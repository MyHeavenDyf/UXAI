function defCircleProcessChartOption(iChartOpt) {
  var defOption = {
    padding: [20, 0, 10, 0],
    theme: 'hdesign-light',
    adaptive: true,
    legend: {
      show: false
    }
  };
  return defOption;
}
export { defCircleProcessChartOption as default };
