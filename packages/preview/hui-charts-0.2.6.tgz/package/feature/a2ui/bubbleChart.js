function getBarDefOpt(iChartOpt) {
  var defOption = {
    padding: [32, 2, 0, 2],
    theme: 'hdesign-light',
    adaptive: true,
    tooltip: {
      show: true
    },
    yAxis: {
      splitNumber: 4
    },
    xAxis: {
      axisLabel: {
        interval: 'auto'
      }
    }
  };
  return defOption;
}
export { getBarDefOpt as default };
