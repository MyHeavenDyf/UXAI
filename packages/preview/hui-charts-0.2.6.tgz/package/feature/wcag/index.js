import cloneDeep from '../../util/cloneDeep.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 多层级的对象合并 函数
function assignObj(target, sources) {
  if (target === void 0) {
    target = {};
  }
  if (sources === void 0) {
    sources = {};
  }
  var itemObj = target || {};
  if (typeof target !== 'object' || typeof sources !== 'object' || !sources) {
    return sources;
  }
  for (var key in sources) {
    if (Object.prototype.hasOwnProperty.call(target || {}, key)) {
      itemObj[key] = assignObj(target[key], sources[key]);
    } else {
      itemObj[key] = sources[key];
    }
  }
  return itemObj;
}

// 图表可选择能力
var WcagObserver = /*#__PURE__*/function () {
  function WcagObserver(mode, theme, echartsIns, eChartOption) {
    this.echartsIns = echartsIns;
    this.eChartOption = eChartOption;
    this.focusedOption = {}; // 聚焦框体配置项
    this.theme = theme;
    this.mode = mode; // 选择模式'single' | 'series' | 'auto'
    this.curMode = undefined; // 当前模式
    this.clickFlag = false; // 模拟阻止点击冒泡
    this.nextParam = {
      // 键盘tab需要的参数
      componentType: 'series',
      seriesIndex: 0,
      dataIndex: 0,
      seriesType: ''
    };
    this.focused = false; // 图表是否被tab聚焦

    this.onDocClick = this.docClick.bind(this);
    this.onKeyUp = this.keyUp.bind(this);
    this.onSeriesClick = this.seriesClick.bind(this);
    this.addSelectMode(mode);
  }

  // 单数据选中
  var _proto = WcagObserver.prototype;
  _proto.setSingleSelectedStyle = function setSingleSelectedStyle(param) {
    var subTypeList = ['line', 'scatter', 'radar'];
    var rect = {};
    this.curMode = 'single';
    if ((param == null ? void 0 : param.dataIndex) === undefined && this.mode === 'auto') {
      this.setSeriesSelectedStyle(param);
      return;
    }
    var node = this.echartsIns.getModel().getSeriesByIndex(param.seriesIndex).getData()._graphicEls[param.dataIndex];
    if (subTypeList.includes(param.seriesType)) {
      rect = {
        x: node.x - node._sizeX - 4,
        y: node.y - node._sizeY - 4,
        width: node._sizeX * 2 + 8,
        height: node._sizeY * 2 + 8
      };
    } else {
      var _node$path;
      rect = node._rectStroke || node._rect || ((_node$path = node.path) == null ? void 0 : _node$path.getBoundingRect());
    }
    this.setCommonOptionByRectList([rect], param);
  }

  // 系列选中
;
  _proto.setSeriesSelectedStyle = function setSeriesSelectedStyle(param) {
    var subTypeList = ['line', 'scatter', 'radar'];
    var rectList = [];
    this.curMode = 'series';
    var seriesModel = this.echartsIns.getModel().getSeriesByIndex(param.seriesIndex);
    if (subTypeList.includes(seriesModel.subType)) {
      var graphicList = seriesModel.getData()._graphicEls;
      rectList = graphicList.filter(function (t) {
        return !!t;
      }).map(function (node) {
        return {
          x: node.x - node._sizeX - 4,
          y: node.y - node._sizeY - 4,
          width: node._sizeX * 2 + 8,
          height: node._sizeY * 2 + 8
        };
      });
    } else {
      rectList = seriesModel.getData()._graphicEls.map(function (t) {
        var _t$path;
        return t._rectStroke || t._rect || ((_t$path = t.path) == null ? void 0 : _t$path.getBoundingRect());
      }).filter(function (t) {
        return !!t;
      });
    }
    this.setCommonOptionByRectList(rectList, param);
  };
  _proto.setCommonOptionByRectList = function setCommonOptionByRectList(rectList, eventParam) {
    this.focusedOption = {
      series: []
    };
    var pointList = [];
    var lineList = [];
    rectList.forEach(function (rect) {
      var list = [{
        x: rect.x,
        y: rect.y
      }, {
        x: rect.x + rect.width,
        y: rect.y
      }, {
        x: rect.x,
        y: rect.y + rect.height
      }, {
        x: rect.x + rect.width,
        y: rect.y + rect.height
      }];
      var lines = [[{
        x: rect.x,
        y: rect.y
      }, {
        x: rect.x + rect.width,
        y: rect.y
      }], [{
        x: rect.x + rect.width,
        y: rect.y
      }, {
        x: rect.x + rect.width,
        y: rect.y + rect.height
      }], [{
        x: rect.x + rect.width,
        y: rect.y + rect.height
      }, {
        x: rect.x,
        y: rect.y + rect.height
      }], [{
        x: rect.x,
        y: rect.y + rect.height
      }, {
        x: rect.x,
        y: rect.y
      }]];
      pointList.push.apply(pointList, list);
      lineList.push.apply(lineList, lines);
    });
    var markColor = this.theme.match(/dark/gi) ? '#fff' : '#252b3a';
    this.focusedOption.series[eventParam.seriesIndex] = {
      data: [],
      markPoint: {
        symbol: 'circle',
        silent: true,
        symbolSize: 6,
        blur: {
          itemStyle: {
            opacity: 1
          }
        },
        itemStyle: {
          borderWidth: 1,
          borderColor: markColor,
          color: '#fff'
        },
        data: pointList,
        animation: false
      },
      markLine: {
        silent: true,
        symbol: 'none',
        lineStyle: {
          color: markColor
        },
        blur: {
          lineStyle: {
            opacity: 1
          }
        },
        emphasis: {
          disabled: true
        },
        data: lineList,
        animation: false
      }
    };
  }

  // 给图表加上可选择能力'single' | 'series' | 'auto'
;
  _proto.addSelectMode = function addSelectMode(focusedMode) {
    var _this = this;
    var isClick = false;
    var chartDom = this.echartsIns.getDom();
    chartDom.setAttribute('tabindex', 0);
    chartDom.addEventListener('focus', function () {
      if (isClick) return;
      _this.focused = true;
      chartDom.classList.add('chart-focus');
      _this.seriesClick(_this.nextParam);
    });
    chartDom.addEventListener('blur', function () {
      _this.focused = false;
      chartDom.classList.remove('chart-focus');
      _this.docClick();
    });
    chartDom.addEventListener('mousedown', function () {
      isClick = true;
      setTimeout(function () {
        isClick = false;
      }, 200);
    });
    this.mode = focusedMode;
    this.echartsIns.on('click', 'series', this.onSeriesClick);
    document.addEventListener('keyup', this.onKeyUp);
  };
  _proto.unobserve = function unobserve() {
    document.removeEventListener('keyup', this.onKeyUp);
    this.echartsIns.off('click', this.onSeriesClick);
  };
  _proto.docClick = function docClick() {
    if (!this.clickFlag) {
      this.focusedOption = {};
      this.curMode = '';
      this.updateOption();
    }
  };
  _proto.keyUp = function keyUp(event) {
    // 键盘tab事件
    if (!this.focused) return;
    var _this$nextParam = this.nextParam,
      seriesIndex = _this$nextParam.seriesIndex,
      dataIndex = _this$nextParam.dataIndex;
    var isNext = event.key === 'ArrowRight' || event.key === ' ';
    var isPrev = event.key === 'ArrowLeft';
    if (event.key === 'Tab') {
      event.stopPropagation();
      return;
    }
    if (isNext || isPrev) {
      event.stopPropagation();
      var curMode = this.curMode;
      if (curMode === 'single') {
        var maxDataIndex = this.eChartOption.series[seriesIndex].data.length - 1;
        if (isNext) {
          if (dataIndex >= maxDataIndex) {
            this.nextParam.dataIndex = 0;
          } else {
            this.nextParam.dataIndex += 1;
          }
        } else if (isPrev) {
          if (dataIndex === 0) {
            this.nextParam.dataIndex = maxDataIndex;
          } else {
            this.nextParam.dataIndex -= 1;
          }
        }
      } else if (curMode === 'series') {
        var maxSeriesIndex = this.eChartOption.series.length - 1;
        if (isNext) {
          if (seriesIndex >= maxSeriesIndex) {
            this.nextParam.seriesIndex = 0;
          } else {
            this.nextParam.seriesIndex += 1;
          }
        } else if (isPrev) {
          if (seriesIndex === 0) {
            this.nextParam.seriesIndex = maxSeriesIndex;
          } else {
            this.nextParam.seriesIndex -= 1;
          }
        }
      }
      this.seriesClick(this.nextParam);
    }
  };
  _proto.seriesClick = function seriesClick(param) {
    var _param$event,
      _this2 = this;
    if (param.componentType !== 'series') {
      return;
    }
    (_param$event = param.event) == null ? void 0 : _param$event.stop(); // 阻止冒泡触发docclick
    this.clickFlag = true;
    setTimeout(function () {
      // 阻止冒泡触发docclick
      _this2.clickFlag = false;
    }, 200);
    var type = this.mode;
    if (type === 'auto') {
      type = this.curMode === '' ? 'series' : 'single';
    }
    if (type === 'single') {
      this.setSingleSelectedStyle(param);
    } else if (type === 'series') {
      this.setSeriesSelectedStyle(param);
    }
    this.nextParam = {
      componentType: 'series',
      seriesIndex: param.seriesIndex,
      dataIndex: param.dataIndex,
      seriesType: param.seriesType
    };
    this.updateOption();
  };
  _proto.updateOption = function updateOption() {
    var _this3 = this;
    var option = cloneDeep(this.eChartOption);
    assignObj(option, this.focusedOption);
    this.echartsIns.setOption(option, {
      notMerge: true
    });
    setTimeout(function () {
      _this3.echartsIns.resize();
    });
  };
  return WcagObserver;
}();
export { WcagObserver as default };
