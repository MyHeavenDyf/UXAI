import getAngleAxisToken from './angleAxis.js';
import getColorToken from './color.js';
import getDataZoomToken from './dataZoom.js';
import getLegendToken from './legend.js';
import getRadarToken from './radar.js';
import getRadiusAxisToken from './radiusAxis.js';
import getTitleToken from './title.js';
import getTooltipToken from './tooltip.js';
import getxAxisToken from './xAxis.js';
import getyAxisToken from './yAxis.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

var moduleMap = {
  angleAxis: getAngleAxisToken,
  color: getColorToken,
  dataZoom: getDataZoomToken,
  legend: getLegendToken,
  radar: getRadarToken,
  radiusAxis: getRadiusAxisToken,
  title: getTitleToken,
  tooltip: getTooltipToken,
  xAxis: getxAxisToken,
  yAxis: getyAxisToken
};
var moduleSourceCommon = ['dataZoom', 'legend',
// 暂时屏蔽title的检测
// 'title',
'tooltip', 'xAxis', 'yAxis'];
var moduleSourceSpecial = ['angleAxis', 'color', 'radar', 'radiusAxis'];

/**
 * 
 * @param {object} moudle  echarts支持的模块对象
 * @param {string} moduleName  模块的名称
 * @returns {object} 返回当前模块的ui规范或者null
 */
function getComonRule(moudle, moduleName) {
  if (moudle && (moduleSourceSpecial.includes(moduleName) || moduleSourceCommon.includes(moduleName) && moudle.show !== false)) return moduleMap[moduleName](moudle);
  return null;
}
export { getComonRule as default };
