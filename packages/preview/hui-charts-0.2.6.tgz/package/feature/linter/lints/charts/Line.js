import Token from '../../../token/index.js';
import { CHART_TYPE } from '../../../../util/constants.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// itemStyle  emphasis.itemStyle;待定
function getLineRule() {
  var chartToken = Token.getChartTokenByName(CHART_TYPE.LINE);
  return {
    series: {
      label: {
        color: chartToken.labelColor,
        fontSize: chartToken.fontSize
      },
      lineStyle: {
        width: chartToken.lineWidth
      }
    }
  };
}
export { getLineRule as default };
