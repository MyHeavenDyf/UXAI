function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import getPieRule from './Pie.js';
import getBarRule from './Bar.js';
import getLineRule from './Line.js';
import getRadarRule from './Radar.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

var chartRuleMap = {
  PieChart: getPieRule,
  BarChart: getBarRule,
  LineChart: getLineRule,
  RadarChart: getRadarRule
};

/**
 * 
 * @param {string} chartName  图表的名称
 * @param {object} echartsOpt  图表配置项
 */
function getUiRule(chartName, echartsOpt) {
  var moduleFn = chartRuleMap[chartName];
  var seriesUiRule = moduleFn ? moduleFn(echartsOpt) : {};
  return _extends({}, seriesUiRule);
}
export { getUiRule as default };
