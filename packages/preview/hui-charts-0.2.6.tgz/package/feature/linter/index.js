import getUiRule from './lints/charts/index.js';
import Dialog from './dialog/index.js';
import getComonRule from './lints/modules/index.js';
import { isArray } from '../../util/type.js';
import { transColor } from '../../util/color.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

function chartLinter(name, eChartOption, dom, action, displayMode) {
  var standardOption = getUiRule(name, eChartOption);
  var differences = getObjectDifferences(standardOption, eChartOption, action === 'fix');
  if (!differences.length) {
    differences = ['无不符合规范项！'];
  }
  // 有对话框元素先移除
  var existingDialog = dom.querySelector('.linter-dialog');
  if (existingDialog) {
    dom.removeChild(existingDialog);
  }

  // 根据action和displayMode决定如何展示结果
  if (action === 'check' && !displayMode || displayMode === 'dialog') {
    new Dialog(dom, differences);
  } else if (displayMode === 'console') {
    console.warn(differences);
  }
}
function getObjectDifferences(seriesOpt, echartsOpt, isfix) {
  var differences = [];
  // 遍历检查项echartsOption的属性
  Object.keys(echartsOpt).sort().forEach(function (key) {
    // 对color属性特殊处理
    if (key === 'color') {
      var standardColor = getComonRule(echartsOpt[key], 'color');
      if (!isArray(echartsOpt.color)) {
        differences.push("\u4E3B\u9898\u989C\u8272\u4E0E\u89C4\u8303\u4E0D\u5339\u914D");
        if (isfix) {
          echartsOpt.color = standardColor;
        }
        return false;
      } else {
        // 如果数组不对则报不匹配
        if (JSON.stringify(standardColor) !== JSON.stringify(echartsOpt.color)) {
          differences.push("\u4E3B\u9898\u989C\u8272\u4E0E\u89C4\u8303\u4E0D\u5339\u914D");
          if (isfix) {
            echartsOpt.color = standardColor;
          }
          return false;
        }
      }
    } else {
      // 对key为非color进行比对
      if (!isArray(echartsOpt[key])) {
        key === 'series' ? compare(seriesOpt.series, echartsOpt[key], key) : compare(getComonRule(echartsOpt[key], key), echartsOpt[key], key);
      } else {
        var isOne = echartsOpt[key].length === 1;
        echartsOpt[key].forEach(function (item, num) {
          var order = isOne ? '' : num;
          key === 'series' ? compare(seriesOpt.series, item, key + order) : compare(getComonRule(item, key), item, key + order);
        });
      }
    }
  });
  function compare(obj1, obj2, path) {
    if (path === void 0) {
      path = '';
    }
    if (obj1) {
      Object.keys(obj1).forEach(function (key) {
        var p = path ? path + "." + key : key;
        // 如果规范里面没值跳过
        if (obj1[key] === undefined || obj1[key] === null) {
          return false;
        }
        // 对ecahrtOpt没有对应值的，提示无此属性
        else if (obj2[key] === undefined || obj2[key] === null) {
          differences.push(p + " \u5728eChartOption\u65E0\u6B64\u5C5E\u6027");
          if (isfix) {
            obj2[key] = obj1[key];
          }
          return false;
        } else if (typeof obj1[key] === 'object' && typeof obj2[key] === 'object') {
          // padding进行特殊比对
          if (key === 'padding' && isArray(obj1[key]) && isArray(obj2[key])) {
            if (!(JSON.stringify(obj1[key]) === JSON.stringify(obj2[key]))) {
              differences.push("" + p + '值跟规范不同');
              if (isfix) {
                obj2[key] = obj1[key];
              }
            }
          } else {
            compare(obj1[key], obj2[key], p);
          }
        } else if (key === 'color' && typeof obj1[key] === 'string' && typeof obj2[key] === 'string') {
          // 将color都转为6位16进制大写，在进行比较
          if (transColor(obj1[key]).toUpperCase() !== transColor(obj2[key]).toUpperCase()) {
            differences.push("" + p + '值跟规范不同');
            if (isfix) {
              obj2[key] = obj1[key];
            }
          }
        }
        // 值不相等的提示跟规范不同
        else if (obj1[key] !== obj2[key]) {
          differences.push("" + p + '值跟规范不同');
          if (isfix) {
            obj2[key] = obj1[key];
          }
        }
      });
    }
  }
  return differences;
}
export { chartLinter as default };
