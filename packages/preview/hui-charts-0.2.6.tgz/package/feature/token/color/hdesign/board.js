/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var rose = {
  colorRose5: '#FEE5F2',
  colorRose10: '#FCC3E0',
  colorRose20: '#F99AC7',
  colorRose30: '#F470AB',
  colorRose40: '#ED448A',
  colorRose50: '#E61866',
  colorRose60: '#C40054',
  colorRose70: '#811439',
  colorRose80: '#540D24',
  colorRose90: '#330614'
};
var red = {
  colorRed5: '#FEE7E8',
  colorRed10: '#FABDC1',
  colorRed20: '#F59297',
  colorRed30: '#EE696F',
  colorRed40: '#E7434A',
  colorRed50: '#E02128',
  colorRed60: '#C7000B',
  colorRed70: '#850F12',
  colorRed80: '#59080A',
  colorRed90: '#350305'
};
var orange = {
  colorOrange5: '#FEF5E8',
  colorOrange10: '#FDE2BD',
  colorOrange20: '#FCCE92',
  colorOrange30: '#F9B766',
  colorOrange40: '#F69E39',
  colorOrange50: '#F4840C',
  colorOrange60: '#C76207',
  colorOrange70: '#954304',
  colorOrange80: '#642802',
  colorOrange90: '#3D1601'
};
var yellow = {
  colorYellow5: '#FEFCE0',
  colorYellow10: '#FEF8B8',
  colorYellow20: '#FEF08A',
  colorYellow30: '#FDE55C',
  colorYellow40: '#FCD72E',
  colorYellow50: '#FCC800',
  colorYellow60: '#D19F00',
  colorYellow70: '#9E7400',
  colorYellow80: '#614500',
  colorYellow90: '#2E1F00'
};
var green = {
  colorGreen5: '#F2FBE9',
  colorGreen10: '#DFF4CC',
  colorGreen20: '#C6E9A8',
  colorGreen30: '#A8DB81',
  colorGreen40: '#87C859',
  colorGreen50: '#62B42E',
  colorGreen60: '#488E20',
  colorGreen70: '#316614',
  colorGreen80: '#1B3E0A',
  colorGreen90: '#0C2004'
};
var mint = {
  colorMint5: '#E7FBF2',
  colorMint10: '#BCF2DB',
  colorMint20: '#8FE5C2',
  colorMint30: '#63D5A8',
  colorMint40: '#36C18D',
  colorMint50: '#09AA71',
  colorMint60: '#058358',
  colorMint70: '#036142',
  colorMint80: '#02422E',
  colorMint90: '#00291D'
};
var cyan = {
  colorCyan5: '#E8FCFD',
  colorCyan10: '#C9F6F9',
  colorCyan20: '#A4ECF1',
  colorCyan30: '#7DDFE7',
  colorCyan40: '#55CCD9',
  colorCyan50: '#2CB8C9',
  colorCyan60: '#1C94A4',
  colorCyan70: '#127180',
  colorCyan80: '#094C57',
  colorCyan90: '#04282F'
};
var blue = {
  colorBlue5: '#EEF3FE',
  colorBlue10: '#D0D8FD',
  colorBlue20: '#B0BFFD',
  colorBlue30: '#8CA3FA',
  colorBlue40: '#668CF7',
  colorBlue50: '#2070F3',
  colorBlue60: '#1F55B5',
  colorBlue70: '#1B3F86',
  colorBlue80: '#112857',
  colorBlue90: '#081635'
};
var indigo = {
  colorIndigo5: '#EEEEFE',
  colorIndigo10: '#D5D3FD',
  colorIndigo20: '#BFB9FA',
  colorIndigo30: '#A89FF9',
  colorIndigo40: '#8E81F4',
  colorIndigo50: '#715AFB',
  colorIndigo60: '#5531EB',
  colorIndigo70: '#3F21B5',
  colorIndigo80: '#281675',
  colorIndigo90: '#160B48'
};
var purple = {
  colorPurple5: '#F7EDFE',
  colorPurple10: '#E8CFFE',
  colorPurple20: '#D9B1FD',
  colorPurple30: '#CB8EFB',
  colorPurple40: '#BF68FA',
  colorPurple50: '#B62BF7',
  colorPurple60: '#8A21BC',
  colorPurple70: '#651B8B',
  colorPurple80: '#41125A',
  colorPurple90: '#260937'
};
var pink = {
  colorPink5: '#FDE6FC',
  colorPink10: '#F9C5F6',
  colorPink20: '#F39DEC',
  colorPink30: '#EB74DF',
  colorPink40: '#E049CE',
  colorPink50: '#D41DBC',
  colorPink60: '#9F1C8D',
  colorPink70: '#751868',
  colorPink80: '#4C0F43',
  colorPink90: '#2E0728'
};
var brand = {
  colorBrand5: '#E6F2FD',
  colorBrand10: '#B8D9F9',
  colorBrand20: '#8ABEF3',
  colorBrand30: '#5CA2E9',
  colorBrand40: '#2E86DE',
  colorBrand50: '#0067D1',
  colorBrand60: '#004EA8',
  colorBrand70: '#003D83',
  colorBrand80: '#002E6A',
  colorBrand90: '#00214B'
};
var gray = {
  colorGray0: '#FFFFFF',
  colorGray5: '#F3F3F3',
  colorGray10: '#DFDFDF',
  colorGray20: '#C9C9C9',
  colorGray30: '#AEAEAE',
  colorGray40: '#939393',
  colorGray50: '#777777',
  colorGray60: '#595959',
  colorGray70: '#393939',
  colorGray80: '#2A2A2A',
  colorGray90: '#191919',
  colorGray100: '#000000'
};
var transparent = {
  colorTransparent: 'rgba(255,255,255,0)'
};
var board = {
  red: red,
  rose: rose,
  mint: mint,
  cyan: cyan,
  blue: blue,
  pink: pink,
  gray: gray,
  green: green,
  brand: brand,
  orange: orange,
  yellow: yellow,
  indigo: indigo,
  purple: purple,
  transparent: transparent
};
export { board as default, gray };
