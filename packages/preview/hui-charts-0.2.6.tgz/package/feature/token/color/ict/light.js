function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import board from './board.js';
import { getColorGroup, getThemeColor } from '../util.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

var gray = _extends({}, board.gray, board.transparent);

// 图表的状态颜色
var colorState = {
  // 紧急色
  colorError: '#F43146',
  colorAlert: '#EC6F1A',
  colorWarning: '#EEBA18',
  // 成功色
  colorSuccess: '#2DA769',
  // 提示色
  colorInfo: '#5990FD',
  // 失效
  colorNone: board.gray.colorGray30
};

// 告警色组
var colorAlarms = {
  // 暂定
  colorAlarmFatal: board.red.colorRed70,
  colorAlarmError: '#F43146',
  colorAlarmWarning: '#EC6F1A',
  colorAlarmSecondary: '#EEBA18',
  // 暂定
  colorAlarmOrdinary: board.yellow.colorYellow20
};

// 图表的配色对象
var colorChart = {
  colorChart1: board.blue.colorBlue40,
  colorChart2: board.mint.colorMint40,
  colorChart3: board.purple.colorPurple40,
  colorChart4: board.cyan.colorCyan30,
  colorChart5: board.yellow.colorYellow20,
  colorChart6: board.indigo.colorIndigo40,
  colorChart7: board.cyan.colorCyan40
};

// 图表内置的颜色组
var colorGroup = getColorGroup(colorChart);
var light = getThemeColor(gray, colorState, colorGroup, colorAlarms, board);
export { light as default };
