var _sceneTokenMap;
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import { THEMES } from '../../../util/constants.js';
import { getIctSceneToken as getSceneToken$1 } from '../theme/ict/getSceneToken.js';
import { getCloudSceneToken as getSceneToken$3 } from '../theme/cloud/getSceneToken.js';
import { getHdesignSceneToken as getSceneToken$2 } from '../theme/hdesign/getSceneToken.js';
import { getDpuiSceneToken as getSceneToken$4 } from '../theme/dpui/getSceneToken.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

var sceneTokenMap = (_sceneTokenMap = {}, _sceneTokenMap[THEMES.LIGHT] = getSceneToken$1, _sceneTokenMap[THEMES.DARK] = function (globalToken) {
  return getSceneToken$1(globalToken, false);
}, _sceneTokenMap[THEMES.BPIT_LIGHT] = getSceneToken$2, _sceneTokenMap[THEMES.BPIT_DARK] = function (globalToken) {
  return getSceneToken$2(globalToken, false);
}, _sceneTokenMap[THEMES.CLOUD_LIGHT] = getSceneToken$3, _sceneTokenMap[THEMES.CLOUD_DARK] = function (globalToken) {
  return getSceneToken$3(globalToken, false);
}, _sceneTokenMap[THEMES.HDESIGN_LIGHT] = getSceneToken$2, _sceneTokenMap[THEMES.HDESIGN_DARK] = function (globalToken) {
  return getSceneToken$2(globalToken, false);
}, _sceneTokenMap[THEMES.DPUI_LIGHT] = getSceneToken$4, _sceneTokenMap[THEMES.DPUI_DARK] = function (globalToken) {
  return getSceneToken$4(globalToken, false);
}, _sceneTokenMap);

/**
 *  根据globalToken获取aliasToken
 * @param {string} themeName  主题名称
 * @param {object} globalToken  globalToken
 */
function getSceneToken(themeName, globalToken) {
  return _extends({}, sceneTokenMap[themeName](globalToken));
}
export { getSceneToken as default, sceneTokenMap };
