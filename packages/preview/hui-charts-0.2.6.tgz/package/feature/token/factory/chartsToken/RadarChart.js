/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
function RadarChart(aliasToken) {
  var lineWidth = aliasToken.lineWidth,
    lineWidthNone = aliasToken.lineWidthNone,
    colorNone = aliasToken.colorNone,
    symbolBorderWidth = aliasToken.symbolBorderWidth,
    symbolBorderWidthNone = aliasToken.symbolBorderWidthNone,
    colorMask = aliasToken.colorMask,
    symbolFillHover = aliasToken.symbolFillHover,
    symbolSizeSecondary = aliasToken.symbolSizeSecondary;
  return {
    itemBorderWidth: symbolBorderWidthNone,
    emphasisItemBorderWidth: symbolBorderWidth,
    areaColor: colorNone,
    symbolSize: symbolSizeSecondary,
    lineWidth: lineWidth,
    thresholdLineWidth: lineWidthNone,
    itemBorderColor: colorNone,
    emphasisItemColor: symbolFillHover,
    gradientItemBorderColor: colorMask
  };
}
export { RadarChart as default };
