/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
function JadeJueChart(aliasToken) {
  var colorPlaceholder = aliasToken.colorPlaceholder,
    colorLabel = aliasToken.colorLabel,
    colorTextName = aliasToken.colorTextName,
    padding = aliasToken.padding,
    borderWidthLG = aliasToken.borderWidthLG,
    borderRadius = aliasToken.borderRadius,
    colorMask = aliasToken.colorMask,
    barWidth = aliasToken.barWidth;
  return {
    itemBorderColor: colorMask,
    itemColor: colorPlaceholder,
    labelValueColor: colorTextName,
    labelRatioColor: colorLabel,
    labelPadding: padding,
    itemBorderWidth: borderWidthLG,
    itemBorderRadius: borderRadius,
    barWidth: barWidth
  };
}
export { JadeJueChart as default };
