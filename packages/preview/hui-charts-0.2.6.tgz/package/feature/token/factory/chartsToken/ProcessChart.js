/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
function ProcessChart(aliasToken) {
  var colorLabel = aliasToken.colorLabel,
    colorPlaceholder = aliasToken.colorPlaceholder,
    borderWidth = aliasToken.borderWidth,
    colorNone = aliasToken.colorNone,
    borderRadius = aliasToken.borderRadius,
    textFontSize = aliasToken.textFontSize,
    labelFontSize = aliasToken.labelFontSize,
    colorLabelSecondary = aliasToken.colorLabelSecondary,
    barWidth = aliasToken.barWidth,
    barWidthSecondary = aliasToken.barWidthSecondary;
  return {
    nameColor: colorLabelSecondary,
    labelColor: colorLabel,
    itemBgEmpty: colorPlaceholder,
    borderWidth: borderWidth,
    borderColor: colorNone,
    borderRadius: borderRadius,
    fontSize: textFontSize,
    labelFontSize: labelFontSize,
    barWidth: barWidth,
    stackBarWidth: barWidthSecondary
  };
}
export { ProcessChart as default };
