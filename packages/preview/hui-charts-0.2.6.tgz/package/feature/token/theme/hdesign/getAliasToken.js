/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
function getAliasToken(globalToken, sceneToken) {
  var fontSizeBase = globalToken.fontSizeBase,
    fontSizeMd = globalToken.fontSizeMd,
    space05x = globalToken.space05x,
    space2x = globalToken.space2x,
    spaceBase = globalToken.spaceBase,
    lineTypeSolid = globalToken.lineTypeSolid,
    borderNone = globalToken.borderNone,
    borderBase = globalToken.borderBase,
    borderRadiusBase = globalToken.borderRadiusBase,
    border2x = globalToken.border2x,
    fontSizeLg = globalToken.fontSizeLg,
    borderRadiusNone = globalToken.borderRadiusNone,
    fontSize4xl = globalToken.fontSize4xl,
    size3x = globalToken.size3x,
    size2x = globalToken.size2x,
    size4x = globalToken.size4x,
    sizeBase = globalToken.sizeBase,
    spaceNone = globalToken.spaceNone,
    space4x = globalToken.space4x,
    size6x = globalToken.size6x,
    size05x = globalToken.size05x,
    borderRadiusLg = globalToken.borderRadiusLg,
    fontSize3xl = globalToken.fontSize3xl,
    fontSize5xl = globalToken.fontSize5xl,
    fontSize2xl = globalToken.fontSize2xl;
  var colorBgMask = sceneToken.colorBgMask,
    colorBgPrimary = sceneToken.colorBgPrimary,
    colorBgSecondary = sceneToken.colorBgSecondary,
    colorBgPlaceholder = sceneToken.colorBgPlaceholder,
    colorBgHover = sceneToken.colorBgHover,
    colorBgHandle = sceneToken.colorBgHandle,
    colorBgActive = sceneToken.colorBgActive,
    colorTextPrimary = sceneToken.colorTextPrimary,
    colorTextSecondary = sceneToken.colorTextSecondary,
    colorTextPlaceholder = sceneToken.colorTextPlaceholder,
    colorTextDisabled = sceneToken.colorTextDisabled,
    colorIconPrimary = sceneToken.colorIconPrimary,
    colorIconDisabled = sceneToken.colorIconDisabled,
    colorLine = sceneToken.colorLine,
    colorLineSecondary = sceneToken.colorLineSecondary,
    colorLinePointer = sceneToken.colorLinePointer,
    colorLineSeparator = sceneToken.colorLineSeparator,
    colorFillNone = sceneToken.colorFillNone,
    colorFill = sceneToken.colorFill,
    colorFillSelect = sceneToken.colorFillSelect,
    colorFillSelectSecondary = sceneToken.colorFillSelectSecondary,
    colorFillHover = sceneToken.colorFillHover,
    colorFillHandle = sceneToken.colorFillHandle,
    colorBorder = sceneToken.colorBorder,
    colorBorderSelect = sceneToken.colorBorderSelect,
    colorShadowPrimary = sceneToken.colorShadowPrimary,
    colorShadowSecondary = sceneToken.colorShadowSecondary,
    shadowOffsetYPrimary = sceneToken.shadowOffsetYPrimary,
    shadowOffsetYSecondary = sceneToken.shadowOffsetYSecondary,
    shadowBlurPrimary = sceneToken.shadowBlurPrimary,
    shadowBlurSecondary = sceneToken.shadowBlurSecondary;
  return {
    // -----------------------------------------------------颜色-------------------------------------------------------------------------
    // 卡片背景
    colorBgContainer: colorBgPrimary,
    // tip背景
    colorBgContainerSecondary: colorBgSecondary,
    // 悬浮背景
    colorBgContainerHover: colorBgHover,
    // 仪表盘中心文本卡片
    colorBgControl: colorBgActive,
    // 标题颜色
    colorTitle: colorTextPrimary,
    // 副标题颜色
    colorSubTitle: colorTextSecondary,
    // 名称文本（轴名称等）
    colorTextName: colorTextSecondary,
    // 图例名称
    colorLegendName: colorTextSecondary,
    // 轴label
    colorAxisLabel: colorTextPlaceholder,
    // label颜色
    colorLabel: colorTextPrimary,
    // 进度图专用name名称和pie图使用
    colorLabelSecondary: colorTextPrimary,
    // label禁用颜色
    colorLabelDisabled: colorTextDisabled,
    // 图标色
    colorIcon: colorIconPrimary,
    // 图标失效色
    colorIconInactive: colorIconDisabled,
    // 坐标轴线颜色
    colorAxisLine: colorLine,
    // 刻度线颜色
    colorAxisTickLine: colorLine,
    // 确定
    // 分隔线颜色
    colorAxisSplitLine: colorLineSecondary,
    // 确定
    // 用于极坐标的径向轴和雷达坐标的分隔线颜色，和坐标轴线颜色保持一致，特殊处理专用
    colorAxisSplitLineSecondary: colorLine,
    // 坐标轴指示器悬浮线
    colorAxisPointerLine: colorLinePointer,
    // 分隔线
    colorSeparatorLine: colorLineSeparator,
    // lableline
    colorLabelLine: colorLinePointer,
    // 无色
    colorNone: colorFillNone,
    // 占位色
    colorPlaceholder: colorBgPlaceholder,
    // 遮盖色
    colorMask: colorBgMask,
    // zoom背景色
    colorZoomBg: colorBgHover,
    // zoom border颜色
    colorZoomBorder: colorBgHover,
    // zoom 数据区域 border
    colorZoomDataAreaBorder: colorBorder,
    // zoom 数据区域填充
    colorZoomDataAreaFill: colorFill,
    // zoom 选中区域填充
    colorZoomFill: colorFillSelect,
    // zoom 选中区域数据border
    colorZoomSelectDataAreaBorder: colorBorderSelect,
    // zoom 选中区域数据填充
    colorZoomSelectDataAreaFill: colorFillSelectSecondary,
    // zoom 手柄颜色
    colorZoomHandle: colorFillHandle,
    // zoom 手柄border
    colorZoomHandleBorder: colorBgHandle,
    // hover阴影
    colorShadowHover: colorFillHover,
    // tip阴影
    colorShadowContainer: colorShadowPrimary,
    // 手柄阴影
    colorShadowHandle: colorShadowSecondary,
    // symbol hover填充
    symbolFillHover: colorBgMask,
    // 中心center数值
    colorCenterValue: colorTextPrimary,
    // 中心center单位
    colorCenterUnit: colorTextPrimary,
    // 中心center名称
    colorCenterName: colorTextSecondary,
    // 图例 item hover
    colorLegendItemHover: colorFillHover,
    // ---------------------------------------------------阴影-------------------------------------------------
    // tip阴影offsetY
    shadowOffsetYContainer: shadowOffsetYPrimary,
    // 手柄阴影offsetY
    shadowOffsetYHandle: shadowOffsetYSecondary,
    // tip阴影模糊
    shadowBlurContainer: shadowBlurPrimary,
    // 手柄阴影模糊
    shadowBlurHandle: shadowBlurSecondary,
    // ------------------------------------------------------------------字号---------------------------------------------------
    // 主文本字号
    textFontSize: fontSizeMd,
    // 次级文本字号
    subtextFontSize: fontSizeBase,
    // 标题文本字号
    titleFontSize: fontSize4xl,
    // 副标题文本字号
    subtitleFontSize: fontSizeLg,
    // label字号
    labelFontSize: fontSizeBase,
    // 中心数值字号
    centerValueFontSize: fontSize5xl * 2,
    // 中心单位字号
    centerUnitFontSize: fontSize3xl,
    // 中心名称字号
    centerNameFontSize: fontSize2xl,
    // ----------------------------------------------线宽---------------------------------------------------------
    // 坐标轴线宽 2
    axisLineWidth: border2x,
    // 用于极坐标系和雷达坐标系
    axisLineWidthSecondary: borderBase,
    // 确定
    // 刻度线线宽 2
    axisTickLineWidth: border2x,
    // 刻度线长度 2
    axisTickLineLength: border2x + borderBase,
    // 长度 + 1
    // 分隔线线宽 1
    axisSplitLineWidth: borderBase,
    // 坐标轴指示器的标线线宽 1
    axisPointerLineWidth: borderBase,
    // 常规线宽
    lineWidth: border2x,
    // 二级线宽
    lineWidthSecondary: borderBase,
    // 无线宽
    lineWidthNone: borderNone,
    // -------------------------------------------------------------------线型-------------------------------------------------------------------
    // 坐标轴类型
    axisLineType: lineTypeSolid,
    // 刻度线类型
    axisTickLineType: lineTypeSolid,
    // 直角坐标系分隔线类型
    axisSplitLineType: lineTypeSolid,
    // 极坐标系分隔线类型
    axisSplitLineTypeSecondary: lineTypeSolid,
    // 坐标轴指示器标线类型
    axisPointerLineType: lineTypeSolid,
    // ---------------------------------------------------------------------间距-------------------------------------------------------------------------------
    // 坐标轴名称间距
    axisNameSpace: space2x,
    // 坐标轴文本间距
    axisLabelSpace: spaceBase,
    // 标题文本间距
    titleSpace: space2x,
    // 容器的间距
    containerGap: spaceBase,
    // 图例的间距
    legendSpace: space4x,
    // 图例文字与图标的间距(只需要调整最后一位数)
    legendTextAndIconSpace: -space05x * 3 + spaceBase,
    // 图例value字体大小
    legendTextValueFontSize: fontSizeBase,
    // 图例名称字体大小
    legendTextNameFontSize: fontSizeBase,
    // 无padding
    paddingNone: spaceNone,
    paddingSM: spaceBase,
    padding: space2x,
    paddingLG: space4x,
    tipItemGap: size2x,
    tipIconGap: size2x,
    tipValueGap: size4x,
    //中心文本主副标题间距
    centerTitleSpace: space4x,
    // -----------------------------------------------------------------边框------------------------------------------------------------------------------
    // zoom数据区域边框
    zoomDataAreaBorderWidth: borderBase,
    // 边框 细
    borderWidth: borderBase,
    // 边框
    borderWidthLG: border2x,
    //  border 0
    borderWidthNone: borderNone,
    // 图元的边框0
    symbolBorderWidthNone: borderNone,
    // 图元的边框
    symbolBorderWidth: border2x,
    // -------------------------------------------------------------size----------------------------------------------------------------------------------------
    // 图元(线图) 
    symbolSize: size2x,
    // 雷达图和箱型图使用
    symbolSizeSecondary: size2x - 2,
    // 散点图使用
    symbolSizeTertiary: size3x,
    // 图元  线形图离散点用
    symbolSizeSM: sizeBase,
    // 柱条的宽度
    barWidth: size4x,
    // 柱条的最小宽度
    barMinWidth: size05x,
    // 柱条的最大宽度
    barMaxWidth: size4x,
    // 堆叠进度图宽度
    barWidthSecondary: size4x,
    // 图例单元尺寸
    legendItemSize: size05x,
    // 图例圆形单元尺寸
    legendCircleItemSize: size2x,
    // labelLine的长度
    labelLineLength: size6x,
    // ------------------------------------------------圆角---------------------------------------------------
    // 容器的圆角
    containerBoderRadius: borderRadiusLg,
    // 圆角 0
    borderRadiusNone: borderRadiusNone,
    // 圆角 小
    borderRadius: borderRadiusBase,
    // 全局透明度
    colorAlpha: 0.15
  };
}
export { getAliasToken as getHdesignAliasToken };
