function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import { lightColor, darkColor, virtualNodeSymbol, lightArrow, darkArrow } from './BaseOption.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

/**
 * 配置节点的样式，与节点的category属性有关
 * @param {*} iChartOption
 * @param {*} baseOption
 * @param {*} theme
 */
var handleCategories = function handleCategories(iChartOption, baseOption, theme) {
  var baseCategories = [
  // 根节点样式
  {
    symbol: 'circle',
    symbolSize: 12,
    itemStyle: {
      color: '#dfba3f'
    }
  },
  // 子节点样式
  {
    symbol: 'circle',
    symbolSize: 12,
    itemStyle: {
      color: theme.indexOf('light') !== -1 ? lightColor : darkColor
    }
  },
  // 虚拟节点样式(方形小黄块)
  {
    symbol: virtualNodeSymbol,
    symbolSize: 20,
    // symbol: 'path://M10 10,L20 10,L20 20, L10 20 Z',
    itemStyle: {
      color: '#dfba3f'
    }
  }];
  var iChartCategories = [];
  if (iChartOption.categories && iChartOption.categories.length) {
    iChartOption.categories.forEach(function (item, index) {
      item = Object.assign(baseCategories[index], item);
      iChartCategories.push(item);
    });
  }
  var categories = iChartOption.categories && iChartOption.categories.length ? iChartCategories : baseCategories;
  baseOption.series[0].categories = categories;
};

/**
 * 处理force配置(节点间距、节点密集度、节点连线长度、树趋近率)
 * @param {*} iChartOption
 * @param {*} baseOption
 */
var handleForce = function handleForce(iChartOption, baseOption) {
  var baseForce = {
    repulsion: 10,
    gravity: 0.12,
    edgeLength: [16, 28],
    layoutAnimation: false,
    friction: 0.05
  };
  var force = iChartOption.force;
  if (force) {
    baseOption.series[0].force = Object.assign(baseForce, force);
  } else {
    baseOption.series[0].force = _extends({}, baseForce);
  }
};

/**
 * 根据主题配置节点连线箭头样式
 * @param {*} iChartOption
 * @param {*} baseOption
 * @param {*} theme
 */
var handleArrow = function handleArrow(iChartOption, baseOption, theme) {
  baseOption.series[0].edgeSymbol = iChartOption.edgeSymbol !== undefined ? iChartOption.edgeSymbol : theme.indexOf('light') !== -1 ? [lightArrow, 'none'] : [darkArrow, 'none'];
};

/**
 * 处理图表位置
 * @param {*} iChartOption
 * @param {*} baseOption
 */
var handlePosition = function handlePosition(iChartOption, baseOption) {
  var chartPosition = iChartOption.chartPosition;
  if (chartPosition && chartPosition.length) {
    switch (chartPosition.length) {
      case 1:
        baseOption.series[0].top = iChartOption.chartPosition[0];
        baseOption.series[0].left = iChartOption.chartPosition[0];
        break;
      case 2:
        baseOption.series[0].top = iChartOption.chartPosition[0];
        baseOption.series[0].left = iChartOption.chartPosition[1];
        break;
    }
  } else {
    chartPosition = ['center', 'center'];
    baseOption.series[0].top = chartPosition[0];
    baseOption.series[0].left = chartPosition[1];
  }
};

/**
 * 配置节点连线样式
 * @param {*} iChartOption
 * @param {*} baseOption
 * @param {*} theme
 */
var handleLineStyle = function handleLineStyle(iChartOption, baseOption, theme) {
  var baseLineStyle = {
    width: 1,
    type: 'solid',
    color: theme.indexOf('light') !== -1 ? lightColor : darkColor,
    opacity: 1
  };
  var lineStyle = iChartOption.lineStyle;
  if (lineStyle) {
    baseOption.series[0].lineStyle = Object.assign(baseLineStyle, lineStyle);
  } else {
    baseOption.series[0].lineStyle = _extends({}, baseLineStyle);
  }
};
export { handleArrow, handleCategories, handleForce, handleLineStyle, handlePosition };
