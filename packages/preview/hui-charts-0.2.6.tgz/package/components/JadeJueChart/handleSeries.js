function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import { getColor } from '../../util/color.js';
import { handleMinRatio } from './handleOption.js';
import chartToken from './chartToken.js';
import merge from '../../util/merge.js';
import { getTextWidth } from '../../util/dom.js';
import { CHARTTYPE, defaultSeries, borderRadiusText } from './BaseOption.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 根据数据值绑定上圆角
var bindBorderRaduis = function bindBorderRaduis(data) {
  data.forEach(function (item) {
    var hasValueIndexArr = [];
    item.children.forEach(function (v, key) {
      if (v.value) {
        hasValueIndexArr.push(key);
      }
    });
    item.children.forEach(function (v, key) {
      if (hasValueIndexArr.includes(key)) {
        if (hasValueIndexArr.length === 1) {
          v.itemStyle = {
            borderRadius: [borderRadiusText, borderRadiusText, borderRadiusText, borderRadiusText]
          };
          return;
        }
        var keyIndex = hasValueIndexArr.findIndex(function (a) {
          return a === key;
        });
        if (keyIndex === 0) {
          v.itemStyle = {
            borderRadius: [borderRadiusText, 0, borderRadiusText, 0]
          };
        } else if (keyIndex === hasValueIndexArr.length - 1) {
          v.itemStyle = {
            borderRadius: [0, borderRadiusText, 0, borderRadiusText]
          };
        } else {
          v.itemStyle = {
            borderRadius: [0, 0, 0, 0]
          };
        }
      }
    });
  });
};
function createSeries(iChartOption, baseOpt, sum, legendData) {
  var _iChartOption$showBac = iChartOption.showBackground,
    showBackground = _iChartOption$showBac === void 0 ? true : _iChartOption$showBac,
    data = iChartOption.data;
  bindBorderRaduis(data);
  var _loop = function _loop(i) {
    var seriesData = [];
    data.forEach(function (item) {
      seriesData.push(item.children.find(function (v) {
        if (v.type === legendData[i]) {
          v.sum = baseOpt.angleAxis.sum;
          return v;
        }
      }));
    });
    baseOpt.series.push(_extends({}, defaultSeries, {
      data: seriesData,
      name: legendData[i]
    }));
  };
  for (var i = 0; i <= legendData.length - 1; i++) {
    _loop(i);
  }
  if (showBackground) {
    var placeHolderData = [];
    data.forEach(function (_, index) {
      var typeSum = 0;
      baseOpt.series.forEach(function (v) {
        var _v$data$index$value, _v$data$index;
        typeSum += (_v$data$index$value = (_v$data$index = v.data[index]) == null ? void 0 : _v$data$index.value) != null ? _v$data$index$value : 0;
      });
      placeHolderData.push({
        type: 'stack背景占位',
        value: baseOpt.angleAxis.sum - typeSum,
        itemStyle: {
          color: chartToken.itemColor
        },
        sum: 0
      });
    });
    baseOpt.series.push(_extends({}, defaultSeries, {
      data: placeHolderData,
      silent: true,
      roundCap: true,
      z: 1
    }));
  }
  baseOpt.series.forEach(function (series, index) {
    series.sum = sum;
    series.itemStyle = {
      borderColor: chartToken.itemBorderColor,
      borderWidth: chartToken.itemBorderWidth
    };
  });
}
var setRadiusAxis = function setRadiusAxis(baseOpt, data, chartType, iChartOption) {
  var _iChartOption$radiusA, _iChartOption$radiusA2;
  var _iChartOption$labelCo = iChartOption.labelContent,
    labelContent = _iChartOption$labelCo === void 0 ? 'name' : _iChartOption$labelCo,
    _iChartOption$showBac2 = iChartOption.showBackground,
    showBackground = _iChartOption$showBac2 === void 0 ? true : _iChartOption$showBac2;
  baseOpt.radiusAxis.z = 10;
  if (chartType === CHARTTYPE.PROCESS) {
    baseOpt.radiusAxis.data = [];
    return;
  } else {
    baseOpt.radiusAxis.data = data.map(function (item) {
      return item.name;
    });
  }
  var getRatio = function getRatio(params) {
    var index = params[1];
    var value = 0;
    var ratio = 0;
    if (chartType === CHARTTYPE.STACK) {
      (showBackground ? baseOpt.series.slice(0, -1) : baseOpt.series).forEach(function (val) {
        var _val$data$index$value, _val$data$index;
        value += (_val$data$index$value = (_val$data$index = val.data[index]) == null ? void 0 : _val$data$index.value) != null ? _val$data$index$value : 0;
      });
    } else {
      var _ref, _baseOpt$series$index;
      value = (_ref = (_baseOpt$series$index = baseOpt.series[index].data[index].beforeChangeValue) != null ? _baseOpt$series$index : baseOpt.series[index].data[index].value) != null ? _ref : 0;
    }
    ratio = value / baseOpt.angleAxis.sum;
    return ratio;
  };
  var iChartLabelFormatter = iChartOption == null ? void 0 : (_iChartOption$radiusA = iChartOption.radiusAxis) == null ? void 0 : (_iChartOption$radiusA2 = _iChartOption$radiusA.axisLabel) == null ? void 0 : _iChartOption$radiusA2.formatter;
  if (iChartLabelFormatter) {
    baseOpt.radiusAxis.axisLabel.formatter = function () {
      for (var _len = arguments.length, params = new Array(_len), _key = 0; _key < _len; _key++) {
        params[_key] = arguments[_key];
      }
      return iChartLabelFormatter.apply(void 0, params.concat([getRatio(params)]));
    };
  } else {
    if (labelContent === 'name') {
      return;
    } else if (labelContent === 'nameWithRatio') {
      var _iChartOption$radiusA3, _iChartOption$radiusA4, _iChartOption$radiusA5;
      var iChartLabelRich = (_iChartOption$radiusA3 = iChartOption == null ? void 0 : (_iChartOption$radiusA4 = iChartOption.radiusAxis) == null ? void 0 : (_iChartOption$radiusA5 = _iChartOption$radiusA4.axisLabel) == null ? void 0 : _iChartOption$radiusA5.rich) != null ? _iChartOption$radiusA3 : {};
      var defaultLabelRich = {
        name: {
          color: chartToken.labelValueColor,
          padding: [0, chartToken.labelPadding, 0, 0],
          align: 'right'
        },
        ratio: {
          color: chartToken.labelRatioColor,
          // 设置宽度才能保证name也右对齐
          width: getTextWidth('100%', baseOpt.radiusAxis.axisLabel.fontSize),
          fontWeight: iChartOption.theme.includes('hdesign') ? 'bold' : 'normal',
          align: 'right'
        }
      };
      baseOpt.radiusAxis.axisLabel.rich = merge(defaultLabelRich, iChartLabelRich);
      baseOpt.radiusAxis.axisLabel.formatter = function () {
        for (var _len2 = arguments.length, params = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
          params[_key2] = arguments[_key2];
        }
        return "{name|" + params[0] + "}{ratio|" + ((getRatio(params) * 100).toFixed(0) + '%') + "}";
      };
      baseOpt.radiusAxis.axisLabel.show = false;
    }
  }
};

// 配置玉玦图的seriesData数据（value,name,color）
function setSeriesData(iChartOption, baseOpt, chartType) {
  var _iChartOption$showBac3 = iChartOption.showBackground,
    showBackground = _iChartOption$showBac3 === void 0 ? true : _iChartOption$showBac3,
    data = iChartOption.data,
    color = iChartOption.color,
    _iChartOption$roundCa = iChartOption.roundCap,
    roundCap = _iChartOption$roundCa === void 0 ? true : _iChartOption$roundCa;
  if (chartType === CHARTTYPE.PROCESS) {
    data.forEach(function (dataItem, index) {
      baseOpt.series.push(_extends({}, defaultSeries, {
        data: [dataItem.value],
        roundCap: false,
        name: dataItem.name,
        beforeChangeValue: undefined,
        showBackground: showBackground,
        backgroundStyle: {
          color: chartToken.itemColor
        }
      }));
    });
  } else if (chartType === CHARTTYPE.BASE) {
    data.forEach(function (dataItem, index) {
      var newData = [];
      data.forEach(function (v) {
        var newIndex = data.length - 1 - index;
        newData.push(_extends({}, v, {
          value: v.name === dataItem.name ? dataItem.value : 0,
          itemStyle: {
            color: Array.isArray(color) ? getColor(color, newIndex) : color
          },
          sum: baseOpt.angleAxis.sum,
          beforeChangeValue: undefined,
          index: newIndex
        }));
      });
      baseOpt.series.push(_extends({}, defaultSeries, {
        data: newData,
        roundCap: roundCap,
        name: dataItem.name
      }));
    });
    if (showBackground) {
      var bgData = [];
      data.forEach(function (dataItem) {
        var _dataItem$value;
        bgData.push(_extends({}, dataItem, {
          itemStyle: {
            color: chartToken.itemColor
          },
          value: baseOpt.angleAxis.sum - ((_dataItem$value = dataItem.value) != null ? _dataItem$value : 0),
          sum: 0
        }));
      });
      baseOpt.series[data.length] = _extends({}, defaultSeries, {
        data: bgData,
        z: 1,
        roundCap: roundCap,
        // 关闭灰色进度鼠标hover事件
        silent: true
      });
    }
  } else {
    var legendData = [];
    data.forEach(function (item) {
      legendData = legendData.concat(item.children.map(function (v) {
        return v.type;
      }));
    });
    legendData = Array.from(new Set(legendData));
    // 将数据按照legend的顺序排列好
    data.forEach(function (item, index) {
      item.children.sort(function (a, b) {
        return legendData.findIndex(function (v) {
          return v === a.type;
        }) - legendData.findIndex(function (v) {
          return v === b.type;
        });
      });
    });
    createSeries(iChartOption, baseOpt, baseOpt.angleAxis.sum, legendData);
  }

  // 自定义柱体最小占比
  handleMinRatio(iChartOption, baseOpt, chartType);

  // 配置展示每项data的名称,及显示层级
  setRadiusAxis(baseOpt, data, chartType, iChartOption);
}

// 对非堆叠类型数据取反（已对iChartOption进行深拷贝），实现数据从外向内展示（echarts默认为内向外）
function reverseData(iChartOption, that) {
  var _iChartOption$type = iChartOption.type,
    type = _iChartOption$type === void 0 ? CHARTTYPE.BASE : _iChartOption$type,
    data = iChartOption.data;
  var noChildData = data.every(function (item) {
    return !item.children || !item.children.length;
  });
  if (type === CHARTTYPE.PROCESS) {
    that.chartType = CHARTTYPE.PROCESS;
  } else if (type === CHARTTYPE.BASE || noChildData) {
    that.chartType = CHARTTYPE.BASE;
    iChartOption.data = iChartOption.data.reverse();
  } else {
    that.chartType = CHARTTYPE.STACK;
  }
}
export { reverseData, setSeriesData };
