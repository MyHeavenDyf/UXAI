import { appendHTML } from '../../util/dom.js';
import loadingSvg from './loading.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 雷达图dom
var radarContainer = '<div class=\'wave_radar_container\'></div>';

// 中心dom
var domContainer = '<div class=\'wave_dom_container\'></div>';

// 最内环dom
var innerContainer = '<div class=\'wave_inner_container\'></div>';

// 加载dom
var loadingContainer = "<div class='wave_loading_container'><div class=\"loading_dom\"></div><div class=\"loading_svg\">" + loadingSvg + "</div></div>";
function initContainer(dom) {
  var container = "\n    <div class='wave_container'>\n        <div class=\"wave_chart_container\">\n            " + radarContainer + "\n            " + innerContainer + "\n            " + domContainer + "\n        </div>\n        " + loadingContainer + "\n    </div>";
  appendHTML(dom, container);
}
export { initContainer };
