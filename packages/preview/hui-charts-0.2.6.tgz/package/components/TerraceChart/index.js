function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function _inheritsLoose(t, o) { t.prototype = Object.create(o.prototype), t.prototype.constructor = t, _setPrototypeOf(t, o); }
function _setPrototypeOf(t, e) { return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) { return t.__proto__ = e, t; }, _setPrototypeOf(t, e); }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import BaseChart from '../BaseChart/index.js';
import defaultPath from './defaultPath.js';
import { initContainer } from './insert.js';
import defendXSS from '../../util/defendXSS.js';
import defaultGradient from './defaultGradient.js';
import { isString, isDOM, isNumber, isArray } from '../../util/type.js';
import { percentToDecimal } from '../../util/math.js';
import { insertStateDom, removeStateDom } from '../../util/init/insert.js';
import { createDom, setStyle, appendHTML, appendDom } from '../../util/dom.js';
import { CHART_TYPE } from '../../util/constants.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var TerraceChart = /*#__PURE__*/function (_BaseChart) {
  function TerraceChart() {
    var _this;
    _this = _BaseChart.call(this) || this;
    // 图表渲染容器
    _this.dom = null;
    // 图表配置项
    _this.option = null;
    // 图表所需数据
    _this.data = null;
    // 梯田容器
    _this.svg = null;
    // 自定义dom容器
    _this.domContainer = null;
    // 位置
    _this.center = null;
    // 大小
    _this.radius = null;
    // loading状态容器
    _this.loadingContainer = null;
    // loading文本容器
    _this.loadingDom = null;
    // 图表容器的宽高变化监听器
    _this.resizeObserver = null;
    // 是否显示梯田
    _this.showTerrace = null;
    return _this;
  }

  // 初始化图表渲染容器
  _inheritsLoose(TerraceChart, _BaseChart);
  var _proto = TerraceChart.prototype;
  _proto.init = function init(dom) {
    this.dom = dom;
  }

  // 初始化图表渲染配置
;
  _proto.setSimpleOption = function setSimpleOption(chartName, option) {
    this.option = option;
  }

  // 图表渲染回调
;
  _proto.render = function render() {
    this.data = this.option.data;
    // 渲染dom
    this.initDom();
    // 渲染refresh相关dom
    this.initFlagParams();
    // 位置定位
    this.handlePosition();
    this.setResizeObserver();
    this.renderCallBack && this.renderCallBack(this);
  }

  // 渲染dom
;
  _proto.initDom = function initDom() {
    initContainer(this.dom);
    this.svg = this.dom.getElementsByClassName('terrace_svg_container')[0];
    this.container = this.dom.getElementsByClassName('terrace_chart_container')[0];
    var gContainer = this.dom.getElementsByClassName('terrace_g_container')[0];
    this.domContainer = this.dom.getElementsByClassName('terrace_dom_container')[0];
    this.loadingContainer = this.dom.getElementsByClassName('terrace_loading_container')[0];
    this.loadingDom = this.dom.getElementsByClassName('loading_dom')[0];
    defaultPath.forEach(function (item, index) {
      var gItem = createDom('g');
      setStyle(gItem, {
        "class": "g_Item_" + index
      });
      appendHTML(gItem, item.path);
      appendDom(gContainer, gItem);
    });
    var gContainerInfo = gContainer.getBoundingClientRect();
    var width = gContainerInfo.width;
    var height = gContainerInfo.height;
    setStyle(this.svg, {
      width: width,
      height: height
    });
  }

  // refresh相关dom
;
  _proto.initFlagParams = function initFlagParams() {
    var _this2 = this;
    // 自定义dom插入
    var centerDom = this.option.centerDom;
    if (centerDom) {
      this.insertCenterDom(centerDom, this.domContainer);
    }
    // 梯田图渲染
    var _this$option$type = this.option.type,
      type = _this$option$type === void 0 ? 'health' : _this$option$type;
    defaultGradient.forEach(function (item) {
      if (item.type === type) {
        appendHTML(_this2.svg, item.lineGradient);
      }
    });
    // 是否显示梯田图
    this.showTerrace = this.option.showTerrace !== undefined ? this.option.showTerrace : true;
    if (!this.showTerrace) {
      this.svg.style.opacity = 0;
    } else {
      this.svg.style.opacity = 1;
    }
  }

  // 自定义dom插入
;
  _proto.insertCenterDom = function insertCenterDom(centerDom, dom) {
    if (!dom) return;
    var initCustomdom = centerDom(dom);
    isString(initCustomdom) && appendHTML(dom, initCustomdom);
    isDOM(initCustomdom) && appendDom(dom, initCustomdom);
  }

  // 更新内外半径
;
  _proto.getNewRadius = function getNewRadius(radius) {
    var _this3 = this;
    if (isNumber(radius)) {
      var outerRadius = radius / (Math.min(this.container.getBoundingClientRect().width, this.container.getBoundingClientRect().height) / 2) * 100;
      return ['30%', outerRadius];
    } else if (isString(radius)) {
      var _outerRadius = radius.endsWith('%') ? radius : parseFloat(radius) / (Math.min(this.container.getBoundingClientRect().width, this.container.getBoundingClientRect().height) / 2) * 100;
      return ['30%', _outerRadius];
    } else if (isArray(radius)) {
      var radiusArr = radius.map(function (r) {
        return isNumber(r) ? r / (Math.min(_this3.container.getBoundingClientRect().width, _this3.container.getBoundingClientRect().height) / 2) * 100 : r.endsWith('%') ? r : parseFloat(r) / (Math.min(_this3.container.getBoundingClientRect().width, _this3.container.getBoundingClientRect().height) / 2) * 100;
      });
      return radiusArr;
    }
  }

  // 配置dom位置
;
  _proto.handlePosition = function handlePosition() {
    var basePosition = null;
    // 位置和大小
    basePosition = {
      center: ['50%', '50%'],
      radius: ['30%', '70%']
    };
    var position = this.option.position;
    this.radius = position && position.radius ? this.getNewRadius(position.radius) : basePosition.radius;
    this.center = position && position.center || basePosition.center;
    var newPosition = this.center.map(function (item) {
      if (item.indexOf('px') === -1 && item.indexOf('%') === -1) {
        item = item + "px";
      }
      return item;
    });
    var left = newPosition[0];
    var top = newPosition[1];
    this.svg.style.left = left;
    this.svg.style.top = top;
    this.domContainer.style.left = left;
    this.domContainer.style.top = top;
    this.loadingContainer.style.left = left;
    this.loadingContainer.style.top = top;
  };
  _proto.resizeDom = function resizeDom() {
    var width = this.svg.getAttribute('width');
    var height = this.svg.getAttribute('height');
    var clientWidth = this.container.clientWidth;
    var clientHeight = this.container.clientHeight;
    this.innerDecimal = percentToDecimal(this.radius[0]);
    this.outerDecimal = percentToDecimal(this.radius[1]);
    var scaleX = (clientWidth * this.outerDecimal / width).toFixed(2);
    var scaleY = (clientHeight * this.outerDecimal / height).toFixed(2);
    var scale = clientWidth >= clientHeight ? scaleY : scaleX;
    this.svg.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
    var loadingSvg = this.dom.getElementsByClassName('terrace_loading_svg')[0];
    var scaleWidth = Math.min(clientWidth, clientHeight) * this.innerDecimal + "px";
    this.domContainer.style.width = scaleWidth;
    this.domContainer.style.height = scaleWidth;
    this.loadingDom.style.width = scaleWidth;
    this.loadingDom.style.height = scaleWidth;
    loadingSvg.style.width = scaleWidth;
    loadingSvg.style.height = scaleWidth;
  }

  // 监听容器变化
;
  _proto.setResizeObserver = function setResizeObserver() {
    var _this4 = this;
    this.resizeObserver = new ResizeObserver(function (entries) {
      _this4.resizeDom();
    });
    this.resizeObserver.observe(this.dom);
  }

  // 图表渲染完成时回调
;
  _proto.onRenderReady = function onRenderReady(callback) {
    this.renderCallBack = callback;
  }

  // 图表刷新，刷新配置项
;
  _proto.refresh = function refresh(option) {
    this.domContainer.innerHTML = '';
    var defsDom = this.svg.getElementsByTagName('defs')[0];
    if (defsDom) {
      this.svg.removeChild(defsDom);
    }
    this.initFlagParams();
    this.handlePosition();
    this.resizeDom();
  }

  // 图表刷新，仅刷新数据
;
  _proto.refreshData = function refreshData(data) {
    this.option.data = data;
    this.refresh(this.option);
  }

  // 刷新图表自适应宽度
;
  _proto.setResize = function setResize() {
    this.resizeDom();
  }

  // 加载状态
;
  _proto.showLoading = function showLoading(option) {
    if (this.loadingContainer) {
      this.loadingDom.innerHTML = '';
      option = _extends({
        theme: 'light'
      }, option);
      var text = option.text || '加载中...';
      var textSize = option.textSize || 14;
      var textShow = option.textShow === false ? false : true;
      var textColor = option.textColor || (option.theme.indexOf('dark') !== -1 ? '#FFFFFF' : '#808080');
      var centerDom = function centerDom() {
        var dom = "\n                <div style=\"color: " + defendXSS(textColor) + ";font-size: " + defendXSS(textSize) + "px;line-height: " + defendXSS(textSize) + "px;display: " + defendXSS(textShow ? 'block' : 'none') + ";letter-spacing: 0.5px;\">\n                    " + defendXSS(text) + "\n                </div>";
        return dom;
      };
      this.insertCenterDom(centerDom, this.loadingDom);
      this.loadingContainer.style.display = 'block';
      this.svg.style.opacity = 0;
    } else {
      // 显示通用性loading
      insertStateDom(this.dom, 'loading', option);
    }
  }

  // 关闭加载
;
  _proto.closeLoading = function closeLoading() {
    // 通用性loading也要关闭
    removeStateDom(this.dom, 'loading');
    if (this.loadingContainer) {
      this.loadingContainer.style.display = 'none';
    }
    if (this.showTerrace && this.svg) {
      this.svg.style.opacity = 1;
    }
  };
  _proto.hideLoading = function hideLoading() {
    this.closeLoading();
  }

  // 销毁图表
;
  _proto.uninstall = function uninstall() {
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
      this.resizeObserver = null;
    }
    this.dom.innerHTML = '';
  };
  return TerraceChart;
}(BaseChart);
_defineProperty(TerraceChart, "name", CHART_TYPE.TERRACE);
export { TerraceChart as default };
