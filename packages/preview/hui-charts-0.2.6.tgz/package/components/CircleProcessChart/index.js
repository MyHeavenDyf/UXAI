function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import init from '../../option/init/index.js';
import miniCircleProcess from '../../feature/mini/miniCircleProcessChart.js';
import { setTooltip, getSeriesData, setTitle } from './handleOption.js';
import { setRadius, setSeries, updateMarkLine } from './handleSeries.js';
import PolarCoordSys from '../../option/PolarSys/index.js';
import { CHART_TYPE } from '../../util/constants.js';
import { mergeSeries } from '../../util/merge.js';
import updateTitle from '../../option/config/polarTitle/handleCenterTitle.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var CircleProcessChart = /*#__PURE__*/function () {
  function CircleProcessChart(iChartOption, chartInstance) {
    this.baseOption = {};
    this.iChartOption = {};
    // 组装 iChartOption, 补全默认值
    this.iChartOption = init(iChartOption);
    this.chartInstance = chartInstance;
    // 根据 iChartOption 组装 baseOption
    this.updateOption(chartInstance);
  }
  var _proto = CircleProcessChart.prototype;
  _proto.updateOption = function updateOption(chartInstance) {
    var _this$baseOption, _this$baseOption$titl, _this$baseOption2, _this$baseOption2$tit;
    var iChartOption = this.iChartOption;
    // 装载除series之外的其他配置
    PolarCoordSys(this.baseOption, iChartOption, CHART_TYPE.CIRCLE_PROCESS);
    // tooltip悬浮框
    setTooltip(this.baseOption);
    // legend数据
    this.baseOption.legend.data = iChartOption.data;
    // series bar数据
    var seriesData = getSeriesData(iChartOption.data);
    setRadius(this.baseOption, chartInstance, iChartOption);
    this.baseOption.series = setSeries(seriesData, iChartOption, chartInstance);
    // 范围设置
    this.baseOption.angleAxis.max = iChartOption.max || 100;
    if (this.baseOption.title) setTitle(iChartOption);
    if ((_this$baseOption = this.baseOption) != null && (_this$baseOption$titl = _this$baseOption.title) != null && _this$baseOption$titl.text || (_this$baseOption2 = this.baseOption) != null && (_this$baseOption2$tit = _this$baseOption2.title) != null && _this$baseOption2$tit.subtext) {
      var position = iChartOption.position || this.baseOption.polar;
      updateTitle(position, chartInstance, this.baseOption, iChartOption);
    }
    mergeSeries(iChartOption, this.baseOption);
    miniCircleProcess(iChartOption, this.baseOption);
  };
  _proto.getOption = function getOption() {
    return this.baseOption;
  };
  _proto.resize = function resize(callback) {
    var _this$iChartOption, _this$baseOption3, _this$baseOption3$tit, _this$baseOption4, _this$baseOption4$tit;
    if (!((_this$iChartOption = this.iChartOption) != null && _this$iChartOption.mini)) setRadius(this.baseOption, this.chartInstance, this.iChartOption);
    if ((_this$baseOption3 = this.baseOption) != null && (_this$baseOption3$tit = _this$baseOption3.title) != null && _this$baseOption3$tit.text || (_this$baseOption4 = this.baseOption) != null && (_this$baseOption4$tit = _this$baseOption4.title) != null && _this$baseOption4$tit.subtext) {
      var position = this.iChartOption.position || this.baseOption.polar;
      updateTitle(position, this.chartInstance, this.baseOption, this.iChartOption);
    }
    // 有阈值线时，更新阈值线位置
    if (this.iChartOption.markLine) {
      updateMarkLine(this.iChartOption, this.baseOption, this.chartInstance);
    }
    callback(this.baseOption);
  };
  return CircleProcessChart;
}();
_defineProperty(CircleProcessChart, "name", CHART_TYPE.CIRCLE_PROCESS);
export { CircleProcessChart as default };
