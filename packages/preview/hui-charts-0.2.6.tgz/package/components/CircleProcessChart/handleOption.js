import defendXSS from '../../util/defendXSS.js';
import chartToken from './chartToken.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
// 获取bar的series数据
function getSeriesData(data) {
  var seriesData = [];
  data.forEach(function (item, i) {
    seriesData[i] = [];
    seriesData[i][0] = item.value;
  });
  return seriesData;
}
function tooltipFormatter(params) {
  var seriesName = params.seriesName;
  var color = params.color;
  var value = params.value;
  var htmlString = "<div>\n                            <span style=\"display:inline-block;width:10px;height:10px;\n                            margin-right:8px;border-radius:5px;border-style: solid;border-width:1px;\n                            border-color:" + defendXSS(color) + ";background-color:" + defendXSS(color) + ";\"></span>\n                            <span style=\"margin-right:16px\">" + defendXSS(seriesName) + "</span>\n                            <span>" + defendXSS(value) + "</span>\n                       </div>";
  return htmlString;
}

/**
 * 配置默认的鼠标悬浮提示框
 */
function setTooltip(baseOpt) {
  if (!baseOpt.tooltip.formatter) {
    baseOpt.tooltip.formatter = tooltipFormatter;
  }
}

/**
 * 配置Title
 */
function setTitle(iChartOption) {
  var _title$subtextStyle, _title$textStyle;
  var title = iChartOption.title;
  if (!title.subtextStyle || !((_title$subtextStyle = title.subtextStyle) != null && _title$subtextStyle.color)) {
    if (!title.subtextStyle) title.subtextStyle = {};
    title.subtextStyle.color = chartToken.descRichColor;
  }
  if (!title.textStyle || !((_title$textStyle = title.textStyle) != null && _title$textStyle.color)) {
    if (!title.textStyle) title.textStyle = {};
    title.textStyle.color = chartToken.detailRichColor;
  }
  if (title.textStyle && title.textStyle.rich) {
    for (var key in title.textStyle.rich) {
      var element = title.textStyle.rich[key];
      if (!element.color) {
        element.color = chartToken.detailRichColor;
      }
    }
  }
}
export { getSeriesData, setTitle, setTooltip };
