import chartToken from './chartToken.js';
import { emptySeriesUnit } from '../GaugeChart/handleSeries.js';
import cloneDeep from '../../util/cloneDeep.js';
import Token from '../../feature/token/index.js';
import { isNumber, isString } from '../../util/type.js';
import { percentToDecimal } from '../../util/math.js';
import updatePosition from '../PieChart/handleCenterPosition.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

function getSeriesInit() {
  return {
    type: 'bar',
    coordinateSystem: 'polar',
    emphasis: {
      focus: 'series'
    },
    animation: false,
    stack: 'total',
    showBackground: true,
    backgroundStyle: {
      color: ''
    },
    data: []
  };
}
function setSeriesUnit(data, index, itemStyle, seriesData, iChartOption) {
  var seriesUnit = getSeriesInit();
  seriesUnit.name = data.name;
  seriesUnit.data = seriesData[index];
  seriesUnit.itemStyle = data.itemStyle || itemStyle || {};
  seriesUnit.backgroundStyle.color = chartToken.background;
  // seriesUnit.barWidth = barWidth;
  seriesUnit.emphasis = iChartOption.emphasis;
  return seriesUnit;
}
function setSeries(seriesData, iChartOption, chartInstance) {
  var data = iChartOption.data,
    itemStyle = iChartOption.itemStyle,
    markLine = iChartOption.markLine;
  var series = [];
  var barWidth = Number(iChartOption.barWidth) || chartToken.barWidth;
  data.forEach(function (item, i) {
    var seriesUnit = setSeriesUnit(item, i, itemStyle, seriesData, iChartOption);
    series.push(seriesUnit);
  });
  // 没有数据时显示空白圆
  if (!data || data.length === 0) {
    var bgData = {
      value: 0
    };
    var bgsSeriesData = [[0]];
    var seriesUnit = setSeriesUnit(bgData, 0, itemStyle, bgsSeriesData, iChartOption);
    series.push(seriesUnit);
  }
  if (!(itemStyle != null && itemStyle.borderRadius)) {
    setBordRadius(series, iChartOption, barWidth);
  }
  // 阈值线
  if (markLine) {
    var markLineUnit = setMarkLine(data, markLine, iChartOption, chartInstance, barWidth);
    series.push(markLineUnit);
  }
  return series;
}
function setBordRadius(series, iChartOption, barWidth) {
  var data = iChartOption.data;
  var borderRadius = barWidth / 2;
  var len = series.length;
  if (!len || !series) return;
  if (len === 1) {
    series[0].itemStyle.borderRadius = borderRadius;
  } else {
    series[0].itemStyle.borderRadius = [borderRadius, 0, borderRadius, 0];
    var lastPosition = len - 1;
    //最后一个值不存在时纠正圆角显示位置
    if (!data[len - 1].value) {
      lastPosition = len - 2;
    }
    series[lastPosition].itemStyle.borderRadius = [0, borderRadius, 0, borderRadius];
  }
}
function setRadius(baseOption, chartInstance, iChartOption) {
  var _iChartOption$positio;
  var radius = ((_iChartOption$positio = iChartOption.position) == null ? void 0 : _iChartOption$positio.radius) || '50%';
  var barWidth = Number(iChartOption.barWidth) || chartToken.barWidth;
  var width = chartInstance == null ? void 0 : chartInstance.getWidth == null ? void 0 : chartInstance.getWidth();
  var height = chartInstance == null ? void 0 : chartInstance.getHeight == null ? void 0 : chartInstance.getHeight();
  var canvasRadius = Math.min(width / 2, height / 2);
  //内圆-4为纠正为实际显示尺寸
  if (isNumber(radius)) {
    baseOption.polar.radius = [radius - barWidth - 4, radius];
  } else if (isString(radius)) {
    var newRadius = radius.includes('%') ? percentToDecimal(radius) * Math.min((chartInstance == null ? void 0 : chartInstance.getWidth == null ? void 0 : chartInstance.getWidth()) / 2, (chartInstance == null ? void 0 : chartInstance.getHeight == null ? void 0 : chartInstance.getHeight()) / 2) : parseFloat(radius);
    baseOption.polar.radius = [newRadius - barWidth - 4, newRadius];
  } else {
    if (radius.length === 1) {
      // 数组1项时，根据barWidth补齐内圆
      var outerRing = radius[0].includes('%') ? percentToDecimal(radius[0]) * canvasRadius : parseFloat(radius[0]);
      baseOption.polar.radius = [outerRing - barWidth - 4, radius[0]];
    } else {
      baseOption.polar.radius = radius;
    }
  }
  if (!iChartOption.position) iChartOption.position = {};
  var position = updatePosition(iChartOption, baseOption.legend, chartInstance);
  if (iChartOption.adaptive) {
    if (position && position.radius) {
      var _outerRing = position.radius;
      iChartOption.position.radius = position.radius;
      baseOption.polar.radius = [_outerRing - barWidth - 4, _outerRing];
    }
    if (position && position.center) {
      baseOption.polar.center = position.center;
      iChartOption.position.center = position.center;
    }
  }
}
function getThemeStatusColor(status) {
  if (status === void 0) {
    status = 'success';
  }
  var _Token$config$colorSt = Token.config.colorState,
    colorError = _Token$config$colorSt.colorError,
    colorAlert = _Token$config$colorSt.colorAlert,
    colorWarning = _Token$config$colorSt.colorWarning,
    colorSuccess = _Token$config$colorSt.colorSuccess;
  var statusColorGroup = {
    error: colorError,
    alert: colorAlert,
    warning: colorWarning,
    success: colorSuccess
  };
  return statusColorGroup[status];
}

// 添加一个空series，使用该空series的pointer来作为阈值线的红线
function setMarkLine(data, markLine, iChartOption, chartInstance, barWidth) {
  var color = markLine.color,
    _markLine$status = markLine.status,
    status = _markLine$status === void 0 ? 'success' : _markLine$status,
    value = markLine.value;
  var marklineColor = getThemeStatusColor(status);
  var temp = cloneDeep(emptySeriesUnit);
  var markLineUnit = cloneDeep(temp);
  var sumValue = data.reduce(function (a, b) {
    return a + b.value;
  }, 0);
  if (sumValue > value) {
    color = '#FFFFFF';
  }
  markLineUnit.name = 'markLine';
  markLineUnit.min = iChartOption.min || 0;
  markLineUnit.max = iChartOption.max || 100;
  markLineUnit.startAngle = 90;
  markLineUnit.endAngle = -270;
  markLineUnit.center = iChartOption.position.center || ['50%', '50%'];
  markLineUnit.radius = iChartOption.position.radius || '50%';
  markLineUnit.animation = false;
  var markLineParameter = computeMarkLine(markLineUnit.radius, barWidth, chartInstance) || {};
  markLineUnit.pointer = {
    icon: 'path://M0 0 L30 0 L30 100 L0 100 Z',
    width: 2,
    length: (markLineParameter.actualBarWidth || barWidth) / 2,
    offsetCenter: iChartOption.markLine.offsetCenter || [0, -markLineParameter.position],
    itemStyle: {
      color: color || marklineColor
    }
  };
  markLineUnit.data = [{
    value: markLine.value
  }];
  markLineUnit.silent = true;
  markLineUnit.zlevel = 2;
  return markLineUnit;
}

// 计算阈值线位置 
function computeMarkLine(radius, barWidth, chartInstance) {
  var position;
  var actualBarWidth;
  var width = chartInstance == null ? void 0 : chartInstance.getWidth == null ? void 0 : chartInstance.getWidth();
  var height = chartInstance == null ? void 0 : chartInstance.getHeight == null ? void 0 : chartInstance.getHeight();
  var canvasRadius = Math.min(width / 2, height / 2);
  // 位置-2为纠正阈值线的位置
  if (isNumber(radius)) {
    position = radius - 2 - barWidth / 4 * 3;
  } else if (isString(radius)) {
    radius = radius.includes('%') ? percentToDecimal(radius) * canvasRadius : parseFloat(radius);
    position = radius - 2 - barWidth / 4 * 3;
  } else {
    if (radius.length === 1) {
      var outerRing = radius[0].includes('%') ? percentToDecimal(radius[0]) * canvasRadius : parseFloat(radius[0]);
      position = outerRing - 2 - barWidth / 4 * 3;
    } else {
      // 数组2项时，根据内外圆大小计算出位置以及阈值线的长度
      var _outerRing2 = radius[1].includes('%') ? percentToDecimal(radius[1]) * canvasRadius : parseFloat(radius[1]);
      var innerRing = radius[0].includes('%') ? percentToDecimal(radius[0]) * canvasRadius : parseFloat(radius[0]);
      actualBarWidth = _outerRing2 - innerRing - 4;
      position = _outerRing2 - 2 - actualBarWidth / 4 * 3;
    }
  }
  return {
    position: position,
    actualBarWidth: actualBarWidth
  };
}

// 更新阈值线位置
function updateMarkLine(iChartOption, eChartOption, chartInstance) {
  var radius = iChartOption.position.radius || '50%';
  var barWidth = Number(iChartOption.barWidth) || chartToken.barWidth;
  var markLineParameter = computeMarkLine(radius, barWidth, chartInstance) || {};
  eChartOption.series.forEach(function (item) {
    if (item.name === 'markLine') {
      item.pointer.offsetCenter = iChartOption.markLine.offsetCenter || [0, -markLineParameter.position];
      item.pointer.length = (markLineParameter.actualBarWidth || barWidth) / 2;
    }
  });
}
export { setRadius, setSeries, updateMarkLine };
