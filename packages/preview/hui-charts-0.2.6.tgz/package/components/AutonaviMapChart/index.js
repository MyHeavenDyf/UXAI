function _inheritsLoose(t, o) { t.prototype = Object.create(o.prototype), t.prototype.constructor = t, _setPrototypeOf(t, o); }
function _setPrototypeOf(t, e) { return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) { return t.__proto__ = e, t; }, _setPrototypeOf(t, e); }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import BaseChart from '../BaseChart/index.js';
import * as echarts from 'echarts';
import { CHART_TYPE } from '../../util/constants.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 常规的调用方法
var amapPromise = null;
var AutonaviMapChart = /*#__PURE__*/function (_BaseChart) {
  function AutonaviMapChart() {
    var _this;
    _this = _BaseChart.call(this) || this;
    // 图表echarts实例
    _this.echartsIns = null;
    // 图表icharts实例
    _this.ichartsIns = null;

    // 图表echarts配置项
    _this.eChartOption = null;
    // 图表icharts配置项
    _this.iChartOption = null;

    // 图表渲染容器
    _this.dom = null;
    // 图表配置项
    _this.option = null;
    return _this;
  }
  _inheritsLoose(AutonaviMapChart, _BaseChart);
  var _proto = AutonaviMapChart.prototype;
  _proto.getAmap = function getAmap(option) {
    if (!amapPromise) {
      var key = option.key;
      var url = option.url;
      var version = option.version || option.ver || option.v;
      amapPromise = new Promise(function (resolve) {
        var cbName = 'amap' + Date.now();
        var script = document.createElement('script');
        window[cbName] = resolve;
        var src = url + "?v=" + version + "&key=" + key;
        if (option.plugin) {
          src += "&plugin=" + option.plugin;
        }
        script.src = src + "&callback=" + cbName;
        script.onload = function () {
          return resolve();
        };
        document.body.appendChild(script);
      });
    }
    return amapPromise;
  }

  // 初始化图表渲染容器
;
  _proto.init = function init(dom) {
    this.uninstall();
    this.dom = dom;
    this.echartsIns = echarts.init(this.dom);
  }

  // 初始化图表渲染配置
;
  _proto.setSimpleOption = function setSimpleOption(chartName, option) {
    var _this2 = this;
    this.option = option;
    this.getAmap(this.option).then(function () {
      _this2.echartsIns.setOption(_this2.option);
      _this2.setResizeObserver();
    });
  }

  // 图表渲染回调
;
  _proto.render = function render() {
    this.initDom(); // 渲染dom
    this.renderCallBack && this.renderCallBack(this);
  }

  // 图表渲染完成时回调
;
  _proto.onRenderReady = function onRenderReady(callback) {
    this.renderCallBack = callback;
  }

  // 渲染dom
;
  _proto.initDom = function initDom() {}

  // 监听容器变化
;
  _proto.setResizeObserver = function setResizeObserver() {
    var _this3 = this;
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
      this.resizeObserver = null;
    }
    this.resizeObserver = new ResizeObserver(function (entries) {
      _this3.resizeDom();
    });
    this.resizeObserver.observe(this.dom);
  };
  _proto.resizeDom = function resizeDom() {
    this.echartsIns && this.echartsIns.resize && this.echartsIns.resize();
  }

  // 图表刷新，刷新配置项
;
  _proto.refresh = function refresh(option) {
    this.iChartOption = option;
    this.setSimpleOption('AutonaviMapChart', this.iChartOption);
    this.resizeDom();
  }

  // 图表刷新，仅刷新数据
;
  _proto.refreshData = function refreshData(data) {
    this.iChartOption.series[0].data = data;
    this.refresh(this.iChartOption);
  }

  // 刷新图表自适应宽度
;
  _proto.setResize = function setResize() {
    this.resizeDom();
  }

  // 销毁图表
;
  _proto.uninstall = function uninstall() {
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
      this.resizeObserver = null;
    }
    // 销毁ECharts实例
    if (this.echartsIns && !this.echartsIns.isDisposed()) {
      this.echartsIns.dispose();
    }
    this.echartsIns = null;
    this.dom = null;
  }

  // 获取到ECharts实例
;
  _proto.getEchartsInstance = function getEchartsInstance() {
    return this.echartsIns;
  }

  // 获取到ECharts配置项
;
  _proto.getEchartsOption = function getEchartsOption() {
    return this.echartsIns.getOption();
  }

  // 获取 ECharts 高德地图组件
;
  _proto.getAmapComponent = function getAmapComponent() {
    return this.echartsIns.getModel().getComponent('amap');
  }

  // 获取高德地图实例
;
  _proto.getAmapInstance = function getAmapInstance() {
    return this.getAmapComponent().getAMap();
  };
  return AutonaviMapChart;
}(BaseChart);
_defineProperty(AutonaviMapChart, "name", CHART_TYPE.AUTONAVI_MAP);
export { AutonaviMapChart as default };
