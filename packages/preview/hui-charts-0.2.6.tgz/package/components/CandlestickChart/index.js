function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import init from '../../option/init/index.js';
import RectCoordSys from '../../option/RectSys/index.js';
import { handleData, handleGrid, handleAxis, handleTooltip, handleDataZoom, handleLegend, handleAxisPointer } from './hanleOption.js';
import { handleSeries } from './hanleSeries.js';
import { mergeSeries } from '../../util/merge.js';
import { CHART_TYPE } from '../../util/constants.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var CandlestickChart = /*#__PURE__*/function () {
  function CandlestickChart(iChartOption, chartInstance) {
    this.baseOption = {};
    this.iChartOption = {};
    this.chartInstance = chartInstance;
    // 组装 iChartOption, 补全默认值
    this.iChartOption = init(iChartOption);
    // 根据 iChartOption 组装 baseOption
    this.updateOption();
  }
  var _proto = CandlestickChart.prototype;
  _proto.updateOption = function updateOption() {
    var iChartOption = this.iChartOption;
    var volume = this.iChartOption.volume;
    var data = handleData(iChartOption);
    if (!data) return;
    handleSeries(this.baseOption, iChartOption, data, this.chartInstance);
    RectCoordSys(this.baseOption, iChartOption);
    // 装载除series之外的其他配置
    handleGrid(this.baseOption, iChartOption);
    // 平均线和成交量,在这部分对ma和vol的图表进行处理
    handleAxis(this.baseOption, data, volume);
    handleTooltip(this.baseOption, iChartOption);
    handleDataZoom(this.baseOption, iChartOption);
    handleLegend(this.baseOption, iChartOption);
    handleAxisPointer(this.baseOption);
    mergeSeries(iChartOption, this.baseOption);
  };
  _proto.getOption = function getOption() {
    return this.baseOption;
  };
  _proto.setOption = function setOption(option) {
    this.baseOption = option;
  };
  return CandlestickChart;
}();
_defineProperty(CandlestickChart, "name", CHART_TYPE.CANDLESTICK);
export { CandlestickChart as default };
