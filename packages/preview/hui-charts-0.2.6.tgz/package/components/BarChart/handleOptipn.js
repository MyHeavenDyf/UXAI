import chartToken from './chartToken.js';
import getTooltipContentHtmlStr from '../../option/config/tooltip/formatter.js';
import { isNumber } from '../../util/type.js';
import mobile from '../../util/mobile.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

/**
 * 给堆叠图的柱子中间加上空白缝隙, 处理柱子圆角的递进关系
 */
function setStack(baseOption, iChartOption, legendData, seriesData) {
  var type = iChartOption.type;
  if (type && type === 'stack') {
    // 添加堆叠图空白缝隙
    baseOption.series.forEach(function (item) {
      item.itemStyle.borderWidth = chartToken.borderWidth;
      item.itemStyle.borderColor = chartToken.borderColor;
    });
    // 柱子圆角，上层数值为空时，圆角递进到下层
    var direction = iChartOption.direction;
    iChartOption.data.forEach(function (item, i) {
      for (var j = legendData.length - 1; j >= 0; j--) {
        var name = legendData[j];
        if (item[name]) {
          seriesData[name][i] = {
            value: seriesData[name][i],
            itemStyle: {
              borderRadius: direction === 'horizontal' ? [0, chartToken.borderRadius, chartToken.borderRadius, 0] : [chartToken.borderRadius, chartToken.borderRadius, 0, 0]
            }
          };
          break;
        }
      }
    });
  }
}

// 将y轴文本都转为正数
function setAbsoluteYaxisLabel(baseOption) {
  var yAxis = baseOption.yAxis;
  yAxis.forEach(function (item) {
    item.axisLabel.formatter = function (value) {
      return Math.abs(value);
    };
  });
}
function setTipFormatter(params, hideEmpty, tooltip, iChartOption) {
  var _iChartOption$theme;
  var config = {
    title: '',
    children: [],
    hideEmpty: hideEmpty
  };
  params.forEach(function (item, index) {
    if (index === 0) {
      config.title = item.name;
    }
    var value = isNumber(item.value) ? Math.abs(item.value) : item.value;
    var dataItem = {
      name: item.seriesName,
      value: value,
      iconColor: item.color
    };
    config.children.push(dataItem);
  });
  var isMobile = iChartOption.isMobile || mobile();
  var isHdesign = (_iChartOption$theme = iChartOption.theme) == null ? void 0 : _iChartOption$theme.includes('hdesign');
  config.isMobile = iChartOption.adaptive && isHdesign && isMobile;
  return getTooltipContentHtmlStr(config, tooltip);
}

/**
 * 将所有y轴的label都转为正数
 * 内置好转为正数的tooltip
 */
function setDoubleSides(baseOption, iChartOption) {
  var type = iChartOption.type;
  if (type && type === 'double-sides') {
    setAbsoluteYaxisLabel(baseOption);
    if (!baseOption.tooltip.formatter) {
      baseOption.tooltip.formatter = function (echartsParams, ticket, callback) {
        var _baseOption$tooltip;
        setTipFormatter(echartsParams, (_baseOption$tooltip = baseOption.tooltip) == null ? void 0 : _baseOption$tooltip.hideEmpty, baseOption.tooltip, iChartOption);
      };
    }
  }
}

/**
 * 设置柱状图的方向
 */
function setDirection(baseOption, direction) {
  if (direction && direction === 'horizontal') {
    var temp = baseOption.xAxis;
    baseOption.xAxis = baseOption.yAxis;
    baseOption.yAxis = temp;
  }
}

/**
 * 设置柱状图的datazoom时最大最小柱宽
 */
function setBarMinMaxWidth(iChartOption, baseOption) {
  baseOption.series.forEach(function (item) {
    var _iChartOption$itemSty;
    item.barMaxWidth = chartToken.barMaxWidth;
    item.barMinWidth = chartToken.barMinWidth;
    if (!((_iChartOption$itemSty = iChartOption.itemStyle) != null && _iChartOption$itemSty.barWidth)) {
      delete item.barWidth;
    }
  });
}
export { setBarMinMaxWidth, setDirection, setDoubleSides, setStack };
