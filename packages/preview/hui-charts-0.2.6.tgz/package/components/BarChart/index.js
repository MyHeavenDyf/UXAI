function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import LineChart from '../LineChart/index.js';
import miniBar from '../../feature/mini/miniBarChart.js';
import init from '../../option/init/index.js';
import cloneDeep from '../../util/cloneDeep.js';
import base from '../../option/base/index.js';
import updateWidth from './barChartOption.js';
import { getDatasetData } from '../../util/dataset.js';
import { mergeSeries, mergeVisualMap } from '../../util/merge.js';
import { setStack, setDoubleSides, setDirection, setBarMinMaxWidth } from './handleOptipn.js';
import RectCoordSys from '../../option/RectSys/index.js';
import { setSeries, setWaterFall, setRange, setMarkLine, setLimitFormatter, setDatasetSeries } from './handleSeries.js';
import { handleMarkLineMax } from '../../option/config/mark/index.js';
import { CHART_TYPE, ADAPTIVE_THEME } from '../../util/constants.js';
import AdaptiveRectSys from '../../option/RectSys/adaptive.js';
import legend from '../../option/config/legend/index.js';
import setA2ui from '../../feature/a2ui/index.js';
import xkey from '../../option/config/xAxis/xkey.js';
import xdata from '../../option/config/xAxis/xdata.js';
import ldata from '../../option/config/legend/ldata.js';
import ydata from '../../option/config/yAxis/ydata.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var BarChart = /*#__PURE__*/function () {
  function BarChart(iChartOption, chartInstance) {
    this.baseOption = {};
    this.baseOption = cloneDeep(base);
    this.chartInstance = chartInstance;
    this.chartName = CHART_TYPE.BAR;
    this.dom = chartInstance._dom;
    getDatasetData(iChartOption);
    // 组装 iChartOption, 补全默认值
    this.iChartOption = init(iChartOption);
    // 根据 iChartOption 组装 baseOption
    this.updateOption();
  }
  var _proto = BarChart.prototype;
  _proto.updateOption = function updateOption() {
    var _iChartOption$dataset, _this$baseOption$data, _this$baseOption$data2;
    var iChartOption = this.iChartOption;
    // 装载除series之外的其他配置
    RectCoordSys(this.baseOption, this.iChartOption, CHART_TYPE.BAR, this.chartInstance);
    // x轴key值
    var xAxisKey = xkey(iChartOption);
    // x轴数据
    var xAxisData = xdata(iChartOption.data, xAxisKey);
    // 图例数据
    var legendData = ldata(iChartOption.data, xAxisKey);
    if ((_iChartOption$dataset = iChartOption.dataset) != null && _iChartOption$dataset.dimensions) {
      legendData = iChartOption.dataset.dimensions.slice(1);
    }
    // 连线的数据
    var seriesData = ydata(iChartOption.data, legendData);
    // 赋值数据
    this.baseOption.legend.data = iChartOption.legend.data || legendData;
    this.baseOption.xAxis.forEach(function (item) {
      item.data = xAxisData;
    });
    this.baseOption.series = setSeries(seriesData, legendData, iChartOption);
    // 给堆叠图的柱子中间加上空白缝隙，并覆盖图例的点击事件
    setStack(this.baseOption, iChartOption, legendData, seriesData);
    // 针对数据均为正数的双向柱状图进行一些特殊处理
    setDoubleSides(this.baseOption, iChartOption);
    // 针对瀑布图表需求，图表需要进行特殊处理
    setWaterFall(this.baseOption, iChartOption);
    // 针对区间图表需求，图表需要进行特殊处理
    setRange(this.baseOption, iChartOption);
    // 针对阈值线变色，图表需要进行特殊处理
    setMarkLine(this.baseOption, iChartOption);
    // 设置柱状图的方向
    setDirection(this.baseOption, iChartOption.direction);
    // 对 tooltip.formatter 进行二次封装
    setLimitFormatter(this.baseOption, iChartOption, seriesData);
    // 是否关闭hover态的效果，默认为false
    if (iChartOption.silent) {
      this.baseOption.tooltip = {};
    }
    // 合并用户自定义series
    if (iChartOption.dataset) {
      setDatasetSeries(this.baseOption, iChartOption);
    } else {
      mergeSeries(iChartOption, this.baseOption);
    }
    //在datazoom下添加最小最大柱宽
    if (((_this$baseOption$data = this.baseOption.dataZoom) == null ? void 0 : (_this$baseOption$data2 = _this$baseOption$data[0]) == null ? void 0 : _this$baseOption$data2.show) === true) {
      setBarMinMaxWidth(iChartOption, this.baseOption);
    }
    // 合并用户自定义visualMap
    mergeVisualMap(iChartOption, this.baseOption);
    // 处理特性
    miniBar(iChartOption, this.baseOption);
  }

  // 根据渲染出的结果，二次计算option
;
  _proto.updateOptionAgain = function updateOptionAgain() {
    var _baseOption$dataZoom, _baseOption$dataZoom$, _this$iChartOption$it;
    var baseOption = this.baseOption;
    var iChartOption = this.iChartOption;
    var lineDataName = iChartOption.lineDataName;
    // 折柱混合
    if (lineDataName && lineDataName.length > 0) {
      var lineChartBaseOpt = new LineChart(iChartOption, {}, this.chartInstance);
      var lineBaseOption = lineChartBaseOpt.getOption();
      var lineSeries = lineBaseOption.series;
      var barSeries = baseOption.series;
      lineDataName.forEach(function (lineName) {
        var bar = null;
        var line = null;
        for (var i = 0; i < lineSeries.length; i++) {
          if (lineSeries[i].name === lineName) {
            line = lineSeries[i];
            break;
          }
        }
        for (var _i = 0; _i < barSeries.length; _i++) {
          if (barSeries[_i].name === lineName) {
            bar = barSeries[_i];
            break;
          }
        }
        for (var key in line) {
          if (Object.hasOwnProperty.call(line, key)) {
            bar[key] = line[key];
          }
        }
      });
    }

    // 处理用户设置的阈值大于y轴，设置y轴max保证阈值显示
    if (iChartOption.markLine) {
      handleMarkLineMax(baseOption, this.chartInstance, this.iChartOption);
    }

    // 如果用户自定义了 barWidth 或 存在 dataZoom，则不主动刷新柱宽
    if (!((_baseOption$dataZoom = baseOption.dataZoom) != null && (_baseOption$dataZoom$ = _baseOption$dataZoom[0]) != null && _baseOption$dataZoom$.show) && !((_this$iChartOption$it = this.iChartOption.itemStyle) != null && _this$iChartOption$it.barWidth) && ADAPTIVE_THEME.includes(this.iChartOption.theme)) {
      updateWidth(baseOption, this.chartInstance, this.iChartOption);
    }
    // 坐标轴二次计算
    AdaptiveRectSys(baseOption, this.iChartOption, this.chartInstance);
  };
  _proto.getOption = function getOption() {
    return this.baseOption;
  };
  _proto.setOption = function setOption() {}

  // 自适应柱条宽度
;
  _proto.resize = function resize(callback) {
    var _this$baseOption$data3, _this$baseOption$data4, _this$iChartOption$it2;
    if (this.iChartOption.adaptive || this.iChartOption.a2ui) {
      this.baseOption.legend = legend(this.iChartOption, 'BarChart', this.chartInstance);
      if (this.iChartOption.a2ui) {
        setA2ui(this.iChartOption, this);
        miniBar(this.iChartOption, this.baseOption);
        updateWidth(this.baseOption, this.chartInstance, this.iChartOption);
      }
      // 坐标轴二次计算
      AdaptiveRectSys(this.baseOption, this.iChartOption, this.chartInstance);
    }

    // 如果用户自定义了 barWidth 或 存在 dataZoom，则不主动刷新柱宽
    if (!((_this$baseOption$data3 = this.baseOption.dataZoom) != null && (_this$baseOption$data4 = _this$baseOption$data3[0]) != null && _this$baseOption$data4.show) && !((_this$iChartOption$it2 = this.iChartOption.itemStyle) != null && _this$iChartOption$it2.barWidth) && ADAPTIVE_THEME.includes(this.iChartOption.theme)) {
      updateWidth(this.baseOption, this.chartInstance, this.iChartOption);
    }
    callback && callback(this.baseOption, {
      notMerge: false
    });
  };
  return BarChart;
}();
_defineProperty(BarChart, "name", CHART_TYPE.BAR);
export { BarChart as default };
