function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import { isArray, isObject } from '../../util/type.js';
import cloneDeep from '../../util/cloneDeep.js';
import defendXSS from '../../util/defendXSS.js';
import merge from '../../util/merge.js';
import tips from '../../util/tips.js';
import title from '../../option/config/polarTitle/index.js';
import tooltip from '../../option/config/tooltip/index.js';
import legend from '../../option/config/legend/index.js';
import Token from '../../feature/token/index.js';
import getRadar, { getMarkRadarOption, getThresholdSeries } from './BaseOption.js';
import { getColor } from '../../util/color.js';
import updatePosition from '../PieChart/handleCenterPosition.js';
import mobile from '../../util/mobile.js';
import { getCloseIcon } from '../../option/config/tooltip/formatter.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

function initRadarSys(baseOpt, iChartOpt) {
  baseOpt.color = iChartOpt.color;
  baseOpt.tooltip = tooltip(iChartOpt, 'RadarChart');
  baseOpt.title = title(iChartOpt);
  baseOpt.legend = legend(iChartOpt);
  baseOpt.radar = [];
  baseOpt.series = [];
}
function handleCusMax(iChartOpt) {
  var max = 0;
  var radarMax = iChartOpt.radarMax,
    radar = iChartOpt.radar;
  if (isArray(radarMax)) {
    radarMax.forEach(function (item) {
      if (item.max > max) max = item.max;
    });
  }
  if (radar != null && radar.indicator) {
    radar.indicator.forEach(function (el) {
      if (el.max > max) max = el.max;
    });
  }
  return max;
}
function findDataMax(keys, data) {
  var max;
  for (var j = 0; j < keys.length; j++) {
    var key = keys[j];
    if (max === undefined) {
      max = data[key];
    }
    max = Math.max(max, data[key]);
  }
  return max;
}

/**
 * 雷达图数据的最大值
 */
function getRadarMax(data, iChartOpt, isCustomMaxVal) {
  var max;
  // 处理自定义max情况下的雷达图的默认最大值为未自定义的系列数据的最大值
  var cusDataName;
  var radarMax = iChartOpt.radarMax,
    radar = iChartOpt.radar;
  if (isCustomMaxVal) {
    if (isArray(radarMax)) {
      cusDataName = radarMax.map(function (item) {
        return item.name;
      });
    }
    if (radar != null && radar.indicator) {
      cusDataName = radar.indicator.map(function (i) {
        return i.name;
      });
    }
  }
  var names = Object.keys(data);
  var _loop = function _loop() {
    var name = names[i];
    var keys = Object.keys(data[name]);
    if (isCustomMaxVal) {
      // 过滤出自定义的系列
      var dataKeys = [];
      keys.forEach(function (name) {
        if (!cusDataName.includes(name)) {
          dataKeys.push(name);
        }
      });
      var seriesDataMax = findDataMax(dataKeys, data[name]);
      if (max === undefined) max = seriesDataMax;
      // 所有系列都自定义的情况，最大值取自定义里面的最大值
      if (max === undefined) {
        max = handleCusMax(iChartOpt);
      }
    } else {
      var _seriesDataMax = findDataMax(keys, data[name]);
      if (max === undefined) max = _seriesDataMax;
      // 多个系列的数据值做处理
      if (max || max === 0) {
        max = Math.max(max, _seriesDataMax);
      }
    }
  };
  for (var i = 0; i < names.length; i++) {
    _loop();
  }
  return max;
}

/**
 * 从数据中拿出雷达的所有维度
 */
function getRadarKeys(data) {
  var radarKeys = [];
  var seriesNames = Object.keys(data);
  for (var i = 0; i < seriesNames.length; i++) {
    var seriesName = seriesNames[i];
    var seriesData = data[seriesName];
    var dataNames = Object.keys(seriesData);
    for (var j = 0; j < dataNames.length; j++) {
      var dataName = dataNames[j];
      if (radarKeys.indexOf(dataName) === -1) {
        radarKeys.push(dataName);
      }
    }
  }
  return radarKeys;
}
function setCenterAndRadius(radar, iChartOpt, baseOpt, chartInstance) {
  var chartPosition = iChartOpt.chartPosition || iChartOpt.position || {};
  if (chartPosition.center) radar.center = chartPosition.center;
  if (chartPosition.radius) radar.radius = chartPosition.radius;
  var position = updatePosition(iChartOpt, baseOpt.legend, chartInstance);
  if (!iChartOpt.isWaveRadar && position != null && position.radius) {
    radar.radius = position.radius;
  }
}
function setIndicator(radar, radarKeys, isCustomMaxVal, iChartOpt) {
  var radarMax = iChartOpt.radarMax,
    data = iChartOpt.data,
    radarMark = iChartOpt.radarMark;
  var isRadarMaxArr = isArray(radarMax);
  radar.indicator = radarKeys.map(function (name, index) {
    if (!isRadarMaxArr) {
      // 非数组的形式默认所有维度共享一个最大值，只显示一个维度的刻度
      return index === 0 ? {
        name: name,
        max: radarMax
      } : {
        name: name,
        max: radarMax,
        axisLabel: {
          show: false
        }
      };
    } else {
      var inerMax = getRadarMax(data, iChartOpt, isCustomMaxVal);
      var isName = radarMax.find(function (item) {
        return item.name === name;
      });
      var cusIndicator = isName || {};
      return _extends({
        name: name,
        max: inerMax,
        axisLabel: {
          show: !!radarMark
        }
      }, cusIndicator);
    }
  });
}
function mergeRadar(radar, iChartOpt, isCommon) {
  var _iChartOpt$radar;
  if (iChartOpt.radar) merge(radar, iChartOpt.radar);
  // 开发针对单个轴做特殊配置
  if ((_iChartOpt$radar = iChartOpt.radar) != null && _iChartOpt$radar.indicator) {
    var mixinIndicator = radar.indicator.map(function (i) {
      var coveredIndicator = iChartOpt.radar.indicator.find(function (indicate) {
        return indicate.name === i.name;
      });
      return coveredIndicator || i;
    });
    radar.indicator = mixinIndicator;
  }
}
function setAxisLabel(radar, iChartOpt) {
  var radarMark = iChartOpt.radarMark;
  // 此处是因为默认情况情况下开启刻度特殊处理
  radar.axisLabel.show = radarMark === undefined ? true : !!radarMark;
}
function setRadarShape(radar, baseOpt) {
  radar.shape = baseOpt.radar[0].shape;
}
function setRadar(baseOpt, iChartOpt, radarKeys, isCustomMaxVal, chartInstance) {
  var radar = getRadar();
  // 坐标轴射线的刻度,只显示一条射线的刻度,其他射线的刻度需要在指示器数据indicator中每项单独配置axisLabel: { show: false }
  setAxisLabel(radar, iChartOpt);
  setCenterAndRadius(radar, iChartOpt, baseOpt, chartInstance);
  setIndicator(radar, radarKeys, isCustomMaxVal, iChartOpt);
  mergeRadar(radar, iChartOpt);
  baseOpt.radar.push(radar);
}
function handletipHtml(tooltip, tipHtml, radarKeys) {
  tooltip.formatter = function (params, ticket, callback) {
    return tipHtml(params, radarKeys, ticket, callback);
  };
}
function checkValue(val) {
  return val || val === 0 ? val : '-';
}
function getCommonDataColor(iChartOpt, data, dataName) {
  var dataNames = Object.keys(data);
  var curNameIndex = dataNames.indexOf(dataName);
  if (curNameIndex !== -1) return getColor(iChartOpt.color, curNameIndex);
}
function handleFormatter(tooltip, iChartOpt, radarKeys, data) {
  var markLine = iChartOpt.markLine,
    theme = iChartOpt.theme;
  var _Token$config = Token.config,
    tooltipItemGap = _Token$config.tooltipItemGap,
    tooltipTitleColor = _Token$config.tooltipTitleColor,
    tooltipIconGap = _Token$config.tooltipIconGap,
    tooltipValueGap = _Token$config.tooltipValueGap,
    legendCircleItemHeight = _Token$config.legendCircleItemHeight,
    tooltipDataNameColor = _Token$config.tooltipDataNameColor,
    tooltipValueColor = _Token$config.tooltipValueColor,
    tooltipCloseColor = _Token$config.tooltipCloseColor;
  var alarmColor = Token.config.colorState.colorError;
  var isThreshold = !!(isObject(markLine) && markLine != null && markLine.threshold);
  var isMobile = iChartOpt.isMobile || mobile();
  var valueFontWeight = theme.includes('hdesign') ? 'font-weight:bold;' : '';
  tooltip.formatter = function (params) {
    var seriesdata = params.data;
    var dataName = seriesdata.name;
    var tipData = seriesdata.value;
    var dataColor = params.color;
    // 处理阈值情况下的数据来源
    if (params.seriesName === 'threshold') {
      tipData = radarKeys.map(function (key) {
        return data[dataName][key];
      });
      dataColor = getCommonDataColor(iChartOpt, data, dataName);
    }
    var htmlString = "<div class=\"hui-charts-tooltip-title\" style=\"margin-bottom:4px;color:" + tooltipTitleColor + "\">" + defendXSS(dataName) + "</div>";
    if (isMobile) {
      htmlString += "<div class=\"hui-charts-tooltip-close\">" + getCloseIcon(tooltipCloseColor) + "</div>";
    }
    tipData.forEach(function (item, index) {
      var color = dataColor;
      if (markLine) {
        var markVal = isThreshold ? markLine.threshold[radarKeys[index]] : markLine;
        if (item >= markVal) color = alarmColor;
      }
      var marginBottomStyle = index + 1 === tipData.length ? '' : 'margin-bottom:4px;';
      htmlString += "<div class=\"hui-charts-tooltip-item\" style=" + marginBottomStyle + ">\n        <div style=\"display:inline-block;vertical-align: middle;\">\n          <span style=\"display:inline-block;width:" + legendCircleItemHeight + "px;height:" + legendCircleItemHeight + "px;margin-right:" + tooltipIconGap + "px;border-radius:5px;background-color:" + defendXSS(color) + ";\"></span>\n          <span style=\"display:inline-block;margin-right:8px;min-width:60px;font-size:12px\">" + defendXSS(radarKeys[index]) + "</span>\n        </div>  \n        <span style=\"font-size:14px;" + valueFontWeight + "\">" + defendXSS(checkValue(item)) + "</span>\n      </div>";
    });
    return htmlString;
  };
}

/**
 * 配置鼠标悬浮提示框
 */
function setTooltip(baseOpt, iChartOpt, radarKeys, data) {
  var tipHtml = iChartOpt.tipHtml,
    tooltip = iChartOpt.tooltip,
    gradient = iChartOpt.gradient;
  if (gradient) return;
  tipHtml ? handletipHtml(baseOpt.tooltip, tipHtml, radarKeys) : handleFormatter(baseOpt.tooltip, iChartOpt, radarKeys, data);
  // 针对tooltip中传formatter做特殊处理
  if (tooltip != null && tooltip.formatter) {
    baseOpt.tooltip.formatter = function (params, ticket, callback) {
      return tooltip.formatter(params, radarKeys, ticket, callback);
    };
  }
}
function setMarkCenterAndRadius(radar, baseOpt) {
  radar.center = baseOpt.radar[0].center;
  radar.radius = baseOpt.radar[0].radius;
}
function setCustomMarkLine(markRadar, baseOpt, iChartOpt, radarKeys) {
  var threshold = iChartOpt.markLine.threshold;
  markRadar.indicator = cloneDeep(baseOpt.radar[0].indicator);
  markRadar.splitLine.show = false;
  var thresholdData = radarKeys.map(function (item) {
    var data = threshold[item] || 0;
    return data;
  });
  var thresholdSeries = getThresholdSeries();
  thresholdSeries.data = [{
    name: '',
    value: thresholdData
  }];
  baseOpt.series.push(thresholdSeries);
}
function setCommonMarkLine(markRadar, baseOpt, iChartOpt, radarKeys) {
  // 雷达图半径
  var radius = baseOpt.radar[0].radius;
  // 雷达图有中心文本的情况下radius需要写成数组
  var radiusIsArray = isArray(radius);
  // 雷达图最大值
  var radarMax = iChartOpt.radarMax,
    markLine = iChartOpt.markLine;
  if (isObject(radarMax)) {
    tips.error('If markLine is of the number type, radarMax must be of the number type. If radarMax is of the object type, set markLine.threshold');
    return;
  }
  var markLineValue = Number.parseFloat(markLine);
  var marklineRadius;
  if (radiusIsArray) {
    var disRadius = Number.parseFloat(radius[1]) - Number.parseFloat(radius[0]);
    marklineRadius = disRadius * (markLineValue / radarMax) + Number.parseFloat(radius[0]) + (radius[0].toString().indexOf('%') !== -1 ? '%' : '');
  } else {
    marklineRadius = markLineValue / radarMax * Number.parseFloat(radius) + (radius.toString().indexOf('%') !== -1 ? '%' : '');
  }
  // 阈值线
  markRadar.radius = marklineRadius;
  markRadar.indicator = Array(radarKeys.length).fill({
    name: ''
  });
}
function setMarkLine(baseOpt, iChartOpt, radarKeys) {
  var markLine = iChartOpt.markLine,
    gradient = iChartOpt.gradient;
  if (gradient) return;
  if (markLine) {
    var markRadar = getMarkRadarOption();
    setRadarShape(markRadar, baseOpt);
    setMarkCenterAndRadius(markRadar, baseOpt);
    var isThreshold = !!(isObject(markLine) && markLine != null && markLine.threshold);
    isThreshold ? setCustomMarkLine(markRadar, baseOpt, iChartOpt, radarKeys) : setCommonMarkLine(markRadar, baseOpt, iChartOpt, radarKeys);
    baseOpt.radar.push(markRadar);
  }
}
function setMiniRadar(baseOpt, iChartOpt) {
  var mini = iChartOpt.mini;
  merge(baseOpt.radar[0], {
    axisName: {
      show: !mini
    },
    axisLabel: {
      show: !mini
    }
  });
  // baseOpt.tooltip.show = !mini;
}
export { checkValue, getRadarKeys, getRadarMax, handletipHtml, initRadarSys, setMarkLine, setMiniRadar, setRadar, setRadarShape, setTooltip };
