function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import Paint from '../../../util/paint.js';
import { appendDom } from '../../../util/dom.js';
import { isArray, isString } from '../../../util/type.js';
import { handleRedPointerRadar, getExceededMarkLineValue } from '../handleSeries.js';
import { getStateList, setStateBarColor } from '../../ProcessChart/handleSeries.js';
import { codeToRGB, getColor } from '../../../util/color.js';
import { checkValue, handletipHtml } from '../handleOptipn.js';
import defendXSS from '../../../util/defendXSS.js';
import merge from '../../../util/merge.js';
import chartToken from '../chartToken.js';
import { handleRedPointerSeries } from '../BaseOption.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

var SUFFIX_CLASSNAME = 'radarCanvas';
var COEFFICIENT_X = [1, 1, -1, -1];
var COEFFICIENT_Y = [-1, 1, 1, -1];
var GradientRadar = /*#__PURE__*/function () {
  function GradientRadar(echartsIns, params) {
    this.painter = null;
    this.centerPoint = {
      x: 0,
      y: 0
    };
    this.canvasDom = null;
    this.echartsIns = null;
    this.iChartOption = null;
    // 容器dom信息
    this.containerDom = {
      target: null,
      width: 0,
      height: 0
    };
    // 计算半径的标尺
    this.radiusScale = 0;
    this.radius = {
      isArray: false,
      value: undefined
    };
    this.pointsMap = null;
    this.baseOption = null;
    this.radarKeys = null;
    this.echartsIns = echartsIns;
    var container = echartsIns.getDom();
    this.containerDom.target = container;
    this.getContainerSize();
    var iChartOption = params.iChartOption,
      baseOption = params.baseOption,
      radarKeys = params.radarKeys;
    this.iChartOption = iChartOption;
    this.baseOption = baseOption;
    this.radarKeys = radarKeys;
  }

  // 初始化canvas
  var _proto = GradientRadar.prototype;
  _proto.init = function init() {
    if (!this.iChartOption.gradient) return;
    if (!this.containerDom.target) return;
    this.initCanvas();
    this.moveStartToRadarCenter();
    this.getRadius();
    this.getPointsMap();
    this.paintView();
  };
  _proto.paintView = function paintView() {
    this.paintGradientArea();
    this.paintRadarArea();
  };
  _proto.getContainerSize = function getContainerSize() {
    var _this$echartsIns, _this$echartsIns2;
    this.containerDom.width = (_this$echartsIns = this.echartsIns) == null ? void 0 : _this$echartsIns.getWidth == null ? void 0 : _this$echartsIns.getWidth();
    this.containerDom.height = (_this$echartsIns2 = this.echartsIns) == null ? void 0 : _this$echartsIns2.getHeight == null ? void 0 : _this$echartsIns2.getHeight();
  };
  _proto.setCanvasSize = function setCanvasSize() {
    this.canvasDom.width = this.containerDom.width;
    this.canvasDom.height = this.containerDom.height;
  };
  _proto.initCanvas = function initCanvas() {
    if (this.containerDom.target) {
      var dom = this.containerDom.target.getElementsByClassName("huicharts-" + SUFFIX_CLASSNAME)[0];
      if (dom) this.containerDom.target.removeChild(dom);
    }
    var canvas = document.createElement('canvas');
    this.canvasDom = canvas;
    canvas.id = SUFFIX_CLASSNAME;
    canvas.className = "huicharts-" + SUFFIX_CLASSNAME;
    this.setCanvasSize();
    canvas.style.width = '100%';
    canvas.style.height = '100%';
    canvas.style.position = 'absolute';
    canvas.style.left = 0;
    canvas.style.top = 0;
    canvas.style['pointer-events'] = 'none';
    appendDom(this.containerDom.target, canvas);
    this.initPainter();
  };
  _proto.initPainter = function initPainter() {
    var ctx = this.canvasDom.getContext('2d');
    this.painter = new Paint(ctx);
    this.setPainter();
  };
  _proto.setPainter = function setPainter() {
    this.painter.lineCap('round');
    this.painter.lineJoin('round');
    this.painter.lineWidth(3);
  }

  // 根据配置获取实际半径的像素尺寸
;
  _proto.convertsRadiusToNub = function convertsRadiusToNub(val) {
    var r = this.formatterVal(val);
    return this.isPctString(val) ? r * this.radiusScale / 2 : r;
  };
  _proto.getRadius = function getRadius() {
    this.getRadiusScale();
    var position = this.iChartOption.position;
    var radius = (position == null ? void 0 : position.radius) || '50%';
    if (isArray(radius)) {
      this.radius.isArray = true;
      var inner = radius[0],
        outer = radius[1];
      var innerR = this.convertsRadiusToNub(inner);
      var outerR = this.convertsRadiusToNub(outer);
      this.radius.value = [innerR, outerR];
    } else {
      this.radius.value = this.convertsRadiusToNub(radius);
    }
  };
  _proto.getRadiusScale = function getRadiusScale() {
    // val若是百分比，采用可视区尺寸（容器高宽中较小一项），echarts的说明
    this.radiusScale = this.containerDom.width >= this.containerDom.height ? this.containerDom.height : this.containerDom.width;
  }

  // 移动canvas起点到雷达的起点
;
  _proto.moveStartToRadarCenter = function moveStartToRadarCenter() {
    this.getCenterPoint();
    // 保存初始画布
    this.painter.save();
    this.painter.translate(this.centerPoint.x, this.centerPoint.y);
  };
  _proto.formatterVal = function formatterVal(val) {
    if (this.isPctString(val)) {
      return Number.parseFloat(val) / 100;
    }
    return Number.parseFloat(val);
  };
  _proto.getPoint = function getPoint(val, isY) {
    var size = isY ? this.containerDom.height : this.containerDom.width;
    var actualVal = this.formatterVal(val);
    return this.isPctString(val) ? actualVal * size : actualVal;
  }

  // 判断是否是百分比
;
  _proto.isPctString = function isPctString(val) {
    return isString(val) && val.includes('%');
  }

  // 获取中心坐标
;
  _proto.getCenterPoint = function getCenterPoint() {
    var position = this.iChartOption.position;
    var center = (position == null ? void 0 : position.center) || ['50%', '50%'];
    var x = this.getPoint(center[0]);
    var y = this.getPoint(center[1], true);
    this.centerPoint.x = x;
    this.centerPoint.y = y;
  }

  //   清空画布
;
  _proto.clearCanvas = function clearCanvas() {
    this.painter.restore();
    this.painter.clearRect(0, 0, this.containerDom.width, this.containerDom.height);
  };
  _proto.paintRadarArea = function paintRadarArea() {
    var _this = this;
    if (!this.pointsMap) return;
    this.pointsMap.forEach(function (point, pointIndex) {
      pointIndex === _this.pointsMap.length - 1 ? _this.paintRadarSide(point, _this.pointsMap[0]) : _this.paintRadarSide(point, _this.pointsMap[pointIndex + 1]);
    });
    this.pointsMap.forEach(function (point) {
      _this.paintPoint(point);
    });
  };
  _proto.clipGradientArea = function clipGradientArea() {
    var _this2 = this;
    this.painter.save();
    this.painter.beginPath();
    this.pointsMap.forEach(function (point, index) {
      var _point$point = point.point,
        x = _point$point[0],
        y = _point$point[1];
      index === 0 ? _this2.painter.moveTo(x, y) : _this2.painter.lineTo(x, y);
      if (index === _this2.pointsMap.length - 1) {
        var first = _this2.pointsMap[0];
        _this2.painter.lineTo(first.point[0], first.point[1]);
      }
    });
    this.painter.clip();
  };
  _proto.paintGradientArea = function paintGradientArea() {
    var _this3 = this;
    if (!this.pointsMap) return;
    this.clipGradientArea();
    var colorEnd = 'rgba(255,255,255,0.01)';
    this.pointsMap.forEach(function (point) {
      var _point$point2 = point.point,
        x = _point$point2[0],
        y = _point$point2[1];
      var color = point.color;
      if (!color.includes('#')) throw new Error('RadarChart.gradient,currently, only hexadecimal colors are supported,such as #FFFFFF');
      var colorStart = codeToRGB(color, 0.2);
      var radius = point.distance * 0.9;
      var radialGradient = _this3.painter.createRadialGradient(x, y, 0, x, y, radius);
      radialGradient.addColorStop(0, colorStart);
      radialGradient.addColorStop(1, colorEnd);
      _this3.painter.beginPath();
      _this3.painter.fillStyle(radialGradient);
      _this3.painter.moveTo(x, y);
      _this3.painter.arc(x, y, radius, 0, 2 * Math.PI);
      _this3.painter.fill();
      _this3.painter.closePath();
    });
    this.painter.restore();
  };
  _proto.paintPoint = function paintPoint(point) {
    var x = point.point[0];
    var y = point.point[1];
    var fillColor = chartToken.gradientItemBorderColor;
    // echarts使用canvas绘画拐点加边框时中线边框(即如果symbol的size时10，边框是2，hover的symbol尺寸是12)
    var halfBorder = chartToken.lineWidth / 2;
    var fillSize = chartToken.symbolSize - halfBorder * 2;
    var r = fillSize < 0 ? 0 : fillSize / 2;
    this.painter.fillStyle(fillColor);
    this.painter.beginPath();
    this.painter.moveTo(x, y);
    this.painter.arc(x, y, r, 0, 2 * Math.PI);
    this.painter.fill();
    this.painter.closePath();
  };
  _proto.paintRadarSide = function paintRadarSide(point, nextPoint) {
    var x = point.point[0];
    var y = point.point[1];
    var x1 = nextPoint.point[0];
    var y1 = nextPoint.point[1];
    var linearGradient = this.painter.createLinearGradient(x, y, x1, y1);
    linearGradient.addColorStop(0, point.color);
    linearGradient.addColorStop(1, nextPoint.color);
    this.painter.strokeStyle(linearGradient);
    this.painter.beginPath();
    this.painter.moveTo(x, y);
    this.painter.lineTo(x1, y1);
    this.painter.stroke();
    this.painter.closePath();
  }

  // 点到圆心的距离
;
  _proto.getPointDistanceFromCenter = function getPointDistanceFromCenter(dataItem) {
    var dataName = dataItem.dataName,
      dataValue = dataItem.dataValue;
    var max = this.baseOption.radar[0].indicator.find(function (item) {
      return item.name === dataName;
    }).max;
    if (this.radius.isArray) {
      return (this.radius.value[1] - this.radius.value[0]) * (dataValue / max) + this.radius.value[0];
    }
    return this.radius.value * (dataValue / max);
  }

  //  逆时针方向方向，象限特殊判断和常规角度不一致
;
  _proto.judgeQuadrants = function judgeQuadrants(angle) {
    if (angle >= 0 && angle < 90) {
      return 4;
    } else if (angle >= 90 && angle < 180) {
      return 3;
    } else if (angle >= 180 && angle < 270) {
      return 2;
    } else if (angle >= 270 && angle <= 360) {
      return 1;
    }
  };
  _proto.getJsAngle = function getJsAngle(angle) {
    return angle * Math.PI / 180;
  };
  _proto.getPointCoordinate = function getPointCoordinate(dataItem, dataIndex, distance) {
    // echarts加角度以逆时针的方向从90度加角度，特殊处理
    var angle = 360 / this.radarKeys.length * dataIndex;
    var x = 0;
    var y = 0;
    var quadrant = this.judgeQuadrants(angle);
    var nubAngle = angle - 90 * (4 - quadrant);
    var actualAngle = this.getJsAngle(nubAngle);
    var isEvenQuadrant = quadrant % 2 === 0;
    x = (isEvenQuadrant ? Math.sin(actualAngle) : Math.cos(actualAngle)) * COEFFICIENT_X[quadrant - 1];
    y = (isEvenQuadrant ? Math.cos(actualAngle) : Math.sin(actualAngle)) * COEFFICIENT_Y[quadrant - 1];
    x = x * distance;
    y = y * distance;
    return [x, y];
  };
  _proto.setSeries = function setSeries() {
    var _this4 = this;
    if (!this.pointsMap) return;
    var seriesUnit = this.baseOption.series[0];
    seriesUnit.lineStyle.opacity = 0;
    seriesUnit.areaStyle.opacity = 0;
    seriesUnit.emphasis = {};
    this.pointsMap.forEach(function (item, index) {
      var seriesName = item.seriesName,
        dataName = item.dataName,
        dataValue = item.dataValue,
        color = item.color;
      var dataNameIndex = _this4.radarKeys.indexOf(dataName);
      var unitRadar = handleRedPointerRadar(_this4.baseOption, _this4.radarKeys, dataNameIndex, dataName);
      var unitPointerSeries = handleRedPointerSeries(index, dataValue, seriesName, true);
      unitPointerSeries.itemStyle.color = color;
      unitPointerSeries.emphasis.itemStyle.color = color;
      unitPointerSeries.emphasis.itemStyle.borderColor = color;
      _this4.baseOption.radar.push(unitRadar);
      _this4.baseOption.series.push(unitPointerSeries);
    });
  };
  _proto.getPointColor = function getPointColor(value, index) {
    var _this$iChartOption = this.iChartOption,
      state = _this$iChartOption.state,
      color = _this$iChartOption.color;
    if (state) {
      var stateList = getStateList(state);
      return setStateBarColor(value, stateList);
    } else {
      return getColor(color, index);
    }
  }

  // 获取数据点的集合
;
  _proto.getPointsMap = function getPointsMap() {
    var _this5 = this;
    var data = this.iChartOption.data;
    var exceeded = getExceededMarkLineValue(data, 0, false);
    this.pointsMap = exceeded.map(function (item, index) {
      var color = _this5.getPointColor(item.dataValue, index);
      var distance = _this5.getPointDistanceFromCenter(item);
      var point = _this5.getPointCoordinate(item, index, distance);
      return _extends({}, item, {
        color: color,
        point: point,
        distance: distance
      });
    });
  };
  _proto.setLegend = function setLegend() {
    this.baseOption.legend.show = false;
  };
  _proto.tipFormatter = function tipFormatter() {
    var _this6 = this;
    this.baseOption.tooltip.formatter = function (params) {
      var seriesdata = params.data;
      var dataName = seriesdata.name;
      var value = seriesdata.value;
      if (params.seriesName === 'threshold') {
        value = _this6.radarKeys.map(function (key) {
          return _this6.iChartOption.data[dataName][key];
        });
      }
      var htmlString = "<div style=\"margin-bottom:4px;\">" + defendXSS(dataName) + "</div>";
      value.forEach(function (item, index) {
        var color = _this6.pointsMap[index].color;
        htmlString += "<div style=\"margin-bottom:4px;\">\n            <span style=\"display:inline-block;width:8px;\n            height:8px;margin-right:8px;border-radius:5px;\n            background-color:" + defendXSS(color) + ";\"></span>\n            <span style=\"display:inline-block;margin-right:8px;\n            min-width:60px;font-size:12px\">" + defendXSS(_this6.radarKeys[index]) + "</span>\n            <span style=\"font-size:14px\">" + defendXSS(checkValue(item)) + "</span>\n            </div>";
      });
      return htmlString;
    };
  };
  _proto.setTooltip = function setTooltip() {
    var _this7 = this;
    var _this$iChartOption2 = this.iChartOption,
      tipHtml = _this$iChartOption2.tipHtml,
      tooltip = _this$iChartOption2.tooltip;
    tipHtml ? handletipHtml(this.baseOption.tooltip, tipHtml, this.radarKeys) : this.tipFormatter();
    if (tooltip) {
      merge(this.baseOption.tooltip, tooltip);
    }
    // 针对tooltip中传formatter做特殊处理
    if (tooltip != null && tooltip.formatter) {
      this.baseOption.tooltip.formatter = function (params, ticket, callback) {
        return tooltip.formatter(params, _this7.radarKeys, ticket, callback);
      };
    }
  };
  _proto.refreshConfig = function refreshConfig() {
    this.getContainerSize();
    this.setCanvasSize();
    // 修改canva的宽高属性会导致之前的ctx失效
    this.setPainter();
    this.moveStartToRadarCenter();
    this.getRadius();
    this.getPointsMap();
  };
  _proto.resize = function resize() {
    if (this.containerDom.target && this.canvasDom) {
      if (this.painter) this.clearCanvas();
      this.refreshConfig();
      this.paintView();
    }
  };
  return GradientRadar;
}();
export { GradientRadar as default };
