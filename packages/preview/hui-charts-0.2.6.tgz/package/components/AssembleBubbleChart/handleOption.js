import defendXSS from '../../util/defendXSS.js';
import { CHARTTYPE } from './BaseOption.js';
import cloneDeep from '../../util/cloneDeep.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 配置默认鼠标悬浮提示框
function defaultTooltipFormatter(baseOpt) {
  if (!baseOpt.tooltip.formatter) {
    baseOpt.tooltip.formatter = function (params) {
      var htmlString = '';
      var bgColor = params.data.borderColor || params.data.color;
      htmlString += "<span style=\"display:inline-block;margin-right:5px;border-radius:50%;width:10px;height:10px;background-color\n          :" + defendXSS(bgColor) + ";\">" + '</span>' + ("<span style=\"display:inline-block;margin-left:5px\">" + defendXSS(params.data.type) + "</span>") + '<br/>' + ("<span style=\"display:inline-block;\">" + defendXSS(params.data.label) + "</span>") + ("<span style=\"display:inline-block;margin-left:10px;\">" + defendXSS(params.data.value) + "</span>") + '<br/>';
      return htmlString;
    };
  }
}
var judgeType = function judgeType(that) {
  var _that$iChartOption = that.iChartOption,
    type = _that$iChartOption.type,
    data = _that$iChartOption.data;
  if (!data || !data.length) throw new Error('聚合气泡图必须定义data数据');
  var noChild = data.every(function (item) {
    return !item.children || !item.children.length;
  });
  for (var i in CHARTTYPE) {
    if (type === CHARTTYPE[i]) {
      that.chartType = CHARTTYPE[i];
    }
  }
  if (!that.chartType) {
    that.chartType = CHARTTYPE[noChild ? 'NON_NESTED' : 'NESTED'];
  }
};
var bindLegendEvent = function bindLegendEvent(baseOpt, chartInstance) {
  var originSource = cloneDeep(baseOpt.dataset[0].source);
  chartInstance.on('legendselectchanged', function (params) {
    var newSource = [originSource[0]];
    var _loop = function _loop(type) {
      if (params.selected[type]) {
        newSource = newSource.concat(originSource.filter(function (v) {
          return v.type === type;
        }));
      }
    };
    for (var type in params.selected) {
      _loop(type);
    }
    baseOpt.dataset[0].source = newSource;
    setTimeout(function () {
      chartInstance.setOption(baseOpt);
    }, 20);
  });
};
export { bindLegendEvent, defaultTooltipFormatter, judgeType };
