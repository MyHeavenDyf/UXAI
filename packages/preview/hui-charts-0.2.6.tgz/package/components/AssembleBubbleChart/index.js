function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import cloneDeep from '../../util/cloneDeep.js';
import BaseOption from './BaseOption.js';
import { judgeType, defaultTooltipFormatter, bindLegendEvent } from './handleOption.js';
import { handleRootData } from './handleRootData.js';
import { handleSeriesData } from './handleSeriesData.js';
import init from '../../option/init/index.js';
import { isArray } from '../../util/type.js';
import { CHART_TYPE } from '../../util/constants.js';
import PolarCoordSys from '../../option/PolarSys/index.js';
import { mergeSeries } from '../../util/merge.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var AssembleBubbleChart = /*#__PURE__*/function () {
  function AssembleBubbleChart(iChartOption, chartInstance, plugins) {
    this.baseOption = cloneDeep(BaseOption);
    this.iChartOption = init(iChartOption);
    this.chartInstance = chartInstance;
    this.plugins = plugins;
    this.updateOption(chartInstance);
  }
  var _proto = AssembleBubbleChart.prototype;
  _proto.updateOption = function updateOption(chartInstance) {
    var _this$iChartOption$po;
    this.iChartOption.position = (_this$iChartOption$po = this.iChartOption.position) != null ? _this$iChartOption$po : this.iChartOption.chartPosition;
    var d3 = this.plugins.d3;
    if (!d3) throw new Error('您必须安装d3才可以使用聚合气泡图');
    if (!isArray(this.iChartOption.color)) {
      this.iChartOption.color = [this.iChartOption.color];
    }
    // 判断图表类型
    judgeType(this);
    // 装载除series之外的其他配置
    PolarCoordSys(this.baseOption, this.iChartOption, CHART_TYPE.ASSEMBLE_BUBBLE);
    // 补齐默认的tooltip.formatter
    defaultTooltipFormatter(this.baseOption);
    // 处理dataset、legend.data、补全series
    handleSeriesData(this.iChartOption, this.baseOption, this.chartType);
    // 编写自定义renderItem函数
    handleRootData(d3, this);
    // 聚合气泡图属于自定义系列，使用polar会报错，需要删除
    delete this.baseOption.polar;
    // 自定义系列的图例点击事件需要自行绑定
    bindLegendEvent(this.baseOption, chartInstance);
    // 合并用户自定义series
    mergeSeries(this.iChartOption, this.baseOption);
  };
  _proto.getOption = function getOption() {
    return this.baseOption;
  };
  _proto.setOption = function setOption(option) {
    this.baseOption = option;
  };
  return AssembleBubbleChart;
}();
_defineProperty(AssembleBubbleChart, "name", CHART_TYPE.ASSEMBLE_BUBBLE);
AssembleBubbleChart.chartType = void 0;
export { AssembleBubbleChart as default };
