import { changeRgbaOpacity } from '../../util/color.js';
import { SYMBOLCOLOR, CHARTTYPE } from './BaseOption.js';
import xAxis from '../../option/config/xAxis/index.js';
import yAxis from '../../option/config/yAxis/index.js';
import grid from '../../option/config/grid/index.js';
import tooltip from '../../option/config/tooltip/index.js';
import defendXSS from '../../util/defendXSS.js';
import { CHART_TYPE } from '../../util/constants.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

function setHeatMapDeaultIchartOption(iChartOpt) {
  if (!iChartOpt.color) {
    iChartOpt.color = SYMBOLCOLOR[iChartOpt.type];
  }
  var padding = iChartOpt.chartPadding || iChartOpt.padding;
  if (!padding && iChartOpt.type === CHARTTYPE[1]) {
    iChartOpt.padding = iChartOpt.handle ? [50, 120, 20, 20] : [50, 30, 20, 20];
  }
}

/**
 * 矩形热力图自定义提示框回调函数
 */
function rectangularFormatter(params) {
  var color = params.color;
  var data = params.data;
  var x = data[0],
    y = data[1],
    z = data[2],
    name = data[3];
  var htmlString = "<div style=\"margin-bottom:4px;\">\n                                \u77E9\u5F62\u70ED\u529B\u56FE\n                            </div>";
  htmlString += "<div style=\"margin-bottom:4px;\">\n                            <span style=\"display:inline-block;width:10px;height:10px;\n                            margin-right:8px;border-style: solid;border-width:1px;\n                            border-color:" + defendXSS(changeRgbaOpacity(color, 1)) + ";background-color:" + defendXSS(color) + ";\"></span>\n                            <span>" + defendXSS(name) + "</span>\n                        </div>";
  htmlString += "\n                            <div>\n                                <span style=\"display:inline-block;margin-right:8px;min-width:60px;\">x\u7EF4\u5EA6</span> \n                                <span>" + defendXSS(x) + "</span>\n                            </div>";
  htmlString += "\n                            <div>\n                                <span style=\"display:inline-block;margin-right:8px;min-width:60px;\">y\u7EF4\u5EA6</span> \n                                <span>" + defendXSS(y) + "</span>\n                            </div>";
  htmlString += "\n                            <div>\n                                <span style=\"display:inline-block;margin-right:8px;\n                                min-width:60px;\">\u900F\u660E\u5EA6\u7EF4\u5EA6</span> \n                                <span>" + defendXSS(z) + "</span>\n                            </div>";
  return htmlString;
}

/**
 * 日历热力图自定义提示框回调函数
 */
function calendarFormatter(params) {
  var color = params.color;
  var data = params.data;
  var name = params.name;
  var z = data[2];
  var htmlDom = "<div style=\"margin-bottom:4px;\">\n                                \u65E5\u5386\u70ED\u529B\u56FE\n                            </div>";
  htmlDom += "<div style=\"margin-bottom:4px;\">\n                            <span style=\"display:inline-block;width:10px;\n                            height:10px;margin-right:8px;border-style: solid;\n                            border-width:1px;border-color:" + defendXSS(changeRgbaOpacity(color, 1)) + ";background-color:" + defendXSS(color) + ";\"></span>\n                            <span>" + defendXSS(name) + "</span>\n                        </div>";
  htmlDom += "\n                            <div>\n                                <span style=\"display:inline-block;margin-right:8px;\n                                min-width:60px;\">Value</span> \n                                <span>" + defendXSS(z) + "</span>\n                            </div>";
  return htmlDom;
}

/**
 * 蜂窝热力图自定义提示框回调函数
 */
function hexagonFormatter(params) {
  var color = params.color;
  var data = params.data;
  var x = data[0],
    y = data[1],
    z = data[2],
    name = data[3];
  var html = "<div style=\"margin-bottom:4px;\">\n                            \u8702\u7A9D\u70ED\u529B\u56FE\n                            </div>";
  html += "<div style=\"margin-bottom:4px;\">\n                            <span style=\"display:inline-block;width:10px;\n                            height:10px;margin-right:8px;border-style: solid;\n                            border-width:1px;border-color:" + defendXSS(changeRgbaOpacity(color, 1)) + ";background-color:" + defendXSS(color) + ";\"></span>\n                            <span>" + defendXSS(name) + "</span>\n                        </div>";
  html += "\n                            <div>\n                                <span style=\"display:inline-block;margin-right:8px;min-width:60px;\">x\u7EF4\u5EA6</span> \n                                <span>" + defendXSS(x) + "</span>\n                            </div>";
  html += "\n                            <div>\n                                <span style=\"display:inline-block;margin-right:8px;min-width:60px;\">y\u7EF4\u5EA6</span> \n                                <span>" + defendXSS(y) + "</span>\n                            </div>";
  html += "\n                            <div>\n                                <span style=\"display:inline-block;margin-right:8px;min-width:60px;\">\u989C\u8272\u7EF4\u5EA6</span> \n                                <span>" + defendXSS(z) + "</span>\n                            </div>";
  return html;
}
var heatMapTooltipFormatter = {
  RectangularHeatMapChart: rectangularFormatter,
  CalendarHeatMapChart: calendarFormatter,
  HexagonHeatMapChart: hexagonFormatter
};
function setTooltip(baseOpt, iChartOpt, type) {
  function setChartTooltip(opt) {
    var _iChartOpt$tooltip;
    if (!iChartOpt.tipHtml && !(iChartOpt != null && (_iChartOpt$tooltip = iChartOpt.tooltip) != null && _iChartOpt$tooltip.formatter)) {
      opt.formatter = heatMapTooltipFormatter[type];
    }
  }
  baseOpt.tooltip = tooltip(iChartOpt, CHART_TYPE.HEAT_MAP, setChartTooltip);
}
function handleCalendarYaxis(yAxis, data) {
  yAxis.type = 'category';
  yAxis.data = data[1];
  yAxis.splitLine.show = false;
  yAxis.axisLine.show = true;
}
function handleHexagonYaxis(yAxis, data) {
  yAxis.splitLine.show = false;
  yAxis.axisLabel.show = false;
  yAxis.min = 0;
  yAxis.max = data[2];
}

// y轴的处理函数
var yAxisHandler = {
  CalendarHeatMapChart: handleCalendarYaxis,
  HexagonHeatMapChart: handleHexagonYaxis
};
function setYaxis(baseOpt, iChartOpt, chartType, data) {
  function setChartYaxis(opt, index) {
    if (chartType !== CHARTTYPE[0] && index === 0) {
      yAxisHandler[chartType](opt, data);
    }
  }
  baseOpt.yAxis = yAxis(baseOpt, iChartOpt, CHART_TYPE.HEAT_MAP, setChartYaxis);
}
function handleRectangularXaxis(xAxis) {
  xAxis.type = 'value';
  xAxis.axisLine.show = false;
}
function handleCalendarXaxis(xAxis, data) {
  xAxis.data = data[0];
  xAxis.axisTick.show = false;
}
function handleHexagonXaxis(xAxis, data) {
  xAxis.type = 'value';
  xAxis.axisLine.show = false;
  xAxis.axisTick.show = false;
  xAxis.axisLabel.show = false;
  xAxis.min = 0;
  xAxis.max = data[1];
}

// x轴的处理函数
var xAxisHandler = {
  RectangularHeatMapChart: handleRectangularXaxis,
  CalendarHeatMapChart: handleCalendarXaxis,
  HexagonHeatMapChart: handleHexagonXaxis
};
function setXaxis(baseOpt, iChartOpt, chartType, data) {
  function setChartXaxis(opt, index) {
    if (index === 0) xAxisHandler[chartType](opt, data);
  }
  baseOpt.xAxis = xAxis(iChartOpt, setChartXaxis);
}
function setGrid(baseOpt, iChartOpt) {
  var basicGrid = grid(iChartOpt);
  baseOpt.grid = basicGrid;
}
function initRectSys(baseOpt, iChartOpt, chartType, data) {
  baseOpt.color = iChartOpt.color;
  // 设置chartpadding
  setGrid(baseOpt, iChartOpt);
  // 图表x轴
  setXaxis(baseOpt, iChartOpt, chartType, data);
  // 图表y轴
  setYaxis(baseOpt, iChartOpt, chartType, data);
  // 图表鼠标悬浮提示框
  setTooltip(baseOpt, iChartOpt, chartType);
}
export { initRectSys, setHeatMapDeaultIchartOption };
