function _inheritsLoose(t, o) { t.prototype = Object.create(o.prototype), t.prototype.constructor = t, _setPrototypeOf(t, o); }
function _setPrototypeOf(t, e) { return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) { return t.__proto__ = e, t; }, _setPrototypeOf(t, e); }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import { insertDom, setDefault, setAttribute, onImageLoad, isDataDisabled, arrFlat, pxToNumber, getStyle, getDistance, compareRefresh, getAreaScope, getWaistLength, setStyle } from './util.js';
import BranchManager from './BranchManager.js';
import BaseChart from '../BaseChart/index.js';
import defaultOption from './defaultOption.js';
import image5R from './assets/image5R.svg.js';
import image5L from './assets/image5L.svg.js';
import image2R from './assets/image2R.svg.js';
import image2L from './assets/image2L.svg.js';
import imageUp from './assets/up.svg.js';
import imageDown from './assets/down.svg.js';
import wirelessR from './assets/wirelessR.svg.js';
import wirelessL from './assets/wirelessL.svg.js';
import { CHART_TYPE } from '../../util/constants.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 1、在全网进行缩放会影响家庭的canvas连线和定位 ok
// 2、悬浮提示框的定位问题   ok
// 3、branchManager代码整理
// 下钻前得到缩放不回印象下钻后的，下钻后开启自适应。

// 最顶层：用来管理所有branch和下转功能
var SnowFlakeChart = /*#__PURE__*/function (_BaseChart) {
  function SnowFlakeChart() {
    var _this;
    _this = _BaseChart.call(this) || this;
    _this.dom;
    _this.drag;
    _this.option;
    _this.data;
    _this.branchs = []; // branch的集合
    _this.renderCallBack = null; // 图表渲染完毕的回调
    _this.firstRecordStatus = true; // 只需要在首次获取到0.5-0.75 缩放值的时候，记录下主从网关的距离、宽高等。 不需要每次都记录，会导致0.75-0.5过渡也记录，再切换到1的时候，视图异常。
    return _this;
  }
  _inheritsLoose(SnowFlakeChart, _BaseChart);
  var _proto = SnowFlakeChart.prototype;
  _proto.init = function init(dom) {
    this.dom = dom;
    this.dom.innerHTML = '';
    this.container = insertDom(this.dom);
  };
  _proto.setSimpleOption = function setSimpleOption(chartName, option, _ref) {
    var drag = _ref.drag;
    setDefault(option, defaultOption);
    this.data = option.data;
    this.option = option;
    this.drag = drag;
    setAttribute(this.container, {
      "class": "sfc-container " + (option.overAll ? 'overAll' : '')
    });
  };
  _proto.setResize = function setResize() {}

  // 首次render需要等所有内置的图片全部加载完毕
;
  _proto.render = function render(assets, callback) {
    var _this2 = this;
    this.initImage(assets);
    onImageLoad(this.imageList, function () {
      _this2.renderBranch();
      callback && callback();
    });
    // 监听drag：每次达到预设的缩放界限值时，触发视图更新
    window.addEventListener('dragScaleChange', this.dragScaleChange.bind(this));
  }

  // 创建canvas用到图片的实例对象
;
  _proto.initImage = function initImage(assets) {
    if (assets === void 0) {
      assets = {};
    }
    this.imageList = {
      'image5R': {
        src: assets.image5R || image5R
      },
      'image5L': {
        src: assets.image5L || image5L
      },
      'image2R': {
        src: assets.image2R || image2R
      },
      'image2L': {
        src: assets.image2L || image2L
      },
      'imageUp': {
        src: assets.imageUp || imageUp
      },
      'imageDown': {
        src: assets.imageDown || imageDown
      },
      'wirelessR': {
        src: assets.wirelessR || wirelessR
      },
      'wirelessL': {
        src: assets.wirelessL || wirelessL
      }
    };
    for (var item in this.imageList) {
      if (Object.hasOwnProperty.call(this.imageList, item)) {
        var img = new Image();
        img.src = this.imageList[item]['src'];
        this.imageList[item]['image'] = img;
      }
    }
  };
  _proto.renderBranch = function renderBranch() {
    var _this3 = this;
    if (this.option.theme.indexOf('dark') === -1) {
      this.container.classList.add('snowLight');
    }
    if (this.data && this.data.length > 0) {
      this.data.forEach(function (dataItem) {
        _this3.branchs.push(new BranchManager(dataItem, _this3.container, _this3));
      });
      // 判断数据的disabled，给外层容器挂上类名,设置容器外环的样式
      isDataDisabled(arrFlat(this.data), this.container, this.option);
    }
    if (!this.option.overAll) {
      this.setPositionLeft();
      this.setTransformOrigin();
      this.setTagPosition();
    }
    // 首次进入家庭视口，开启自适应缩放功能后，寻找合适的drag缩放值
    this.findFitScale();
    setTimeout(function () {
      _this3.renderCallBack && _this3.renderCallBack(_this3);
    }, 0);
  }

  // 考虑多个多终端的容器，相邻不得重叠。需要调整其定位值
  // 这样的方法有bug会导致两个很小的从网关之间插了个很大的从网关。从网关到主网关的连线会特别长
;
  _proto.setPositionLeft = function setPositionLeft() {
    var centerDomArr = [].concat(this.branchs[0].centerDomArr);
    centerDomArr.splice(0, 1);
    centerDomArr.forEach(function (item, index) {
      var equalDeg = item.equalDeg,
        level = item.data.level;
      var itemBranch = item.container.parentNode.parentNode;
      var itemBranchWidth = pxToNumber(getStyle(itemBranch, 'width'));
      // newLeftVal和oldLeftVal得到的都是从主网关最右侧到从网关圆心的距离，定位直接从100%开始累计
      var newLeftVal = (itemBranchWidth / 2 + 40) / Math.sin(equalDeg / 2 * Math.PI / 180) - pxToNumber(getStyle(itemBranch.parentNode, 'width')) / 2; // 给相邻容器设置一个40的间隔
      var oldLeftVal = pxToNumber(getStyle(itemBranch, 'left')) - pxToNumber(getStyle(itemBranch.parentNode, 'width'));
      if (newLeftVal > oldLeftVal) {
        // 进入到这个判断内说明是个多终端的从网关，要计算最合适的newLeftVal
        if (centerDomArr.length >= 3) {
          // 获取其相邻branch的尺寸
          var sameLevelArr = centerDomArr.filter(function (node) {
            return node.data.level === level;
          });
          var getIndex = sameLevelArr.findIndex(function (same) {
            return same.data.mac === item.data.mac;
          });
          var lastBranch = sameLevelArr[getIndex - 1 === -1 ? sameLevelArr.length - 1 : getIndex - 1].container.parentNode.parentNode;
          var nextBranch = sameLevelArr[getIndex + 1 === sameLevelArr.length ? 0 : getIndex + 1].container.parentNode.parentNode;
          var lastBranchWidth = pxToNumber(getStyle(lastBranch, 'width'));
          var nextBranchWidth = pxToNumber(getStyle(nextBranch, 'width'));
          if (itemBranchWidth > lastBranchWidth && itemBranchWidth > nextBranchWidth) {
            // 至少满足当前分支要大于兄弟分支的尺寸(有bug，待解决)
            var minEqual = itemBranchWidth / (Math.max(lastBranchWidth, nextBranchWidth) + itemBranchWidth + 40) * equalDeg;
            newLeftVal = (itemBranchWidth / 2 + 40) / Math.sin(minEqual * Math.PI / 180) - pxToNumber(getStyle(itemBranch.parentNode, 'width')) / 2;
          }
        }
        itemBranch.style.left = "calc(100% + " + newLeftVal + "px)";
      }
    });
  }

  // 给所有的外环容器设置旋转中心（因为要等全部的外环大小确定下来，才能统一计算）
;
  _proto.setTransformOrigin = function setTransformOrigin() {
    var _this4 = this;
    var centerDomArr = this.branchs[0].centerDomArr;
    centerDomArr.forEach(function (item, index) {
      if (index === 0) return;
      var branchContainer = item.container;
      while (!branchContainer.classList.contains('sfc-branch')) {
        branchContainer = branchContainer.parentNode;
      }
      var centerNode = branchContainer.querySelector('.sfc-node-center');
      var parentCenterNode = branchContainer.parentNode.querySelector('.sfc-node-center');
      var scale = getStyle(_this4.drag.dom, 'transform').replace('matrix(', '').split(',')[0];
      var distance = getDistance(centerNode, parentCenterNode) / scale; // getBoundingClientRect获取的x,y要去掉scale的影响。未避免用户修改，不直接从drag拿
      branchContainer.style.transformOrigin = "calc(50% - " + distance + "px) center";
      // 更新主从网关间的canvas连线
      var centerLine = _this4.branchs[0].centerLineArr.find(function (line) {
        return line.data.mac === branchContainer.getAttribute('data-mac');
      });
      centerLine.distance = distance - pxToNumber(getStyle(branchContainer.parentNode, 'width')) / 2;
      centerLine.destroyCanvas();
      centerLine.createCanvas();
      centerLine.draw();
    });
  };
  _proto.setTagPosition = function setTagPosition() {
    var centerTagArr = this.branchs[0].centerTagArr;
    centerTagArr.forEach(function (tag) {
      tag.setAngle();
    });
  }

  // 切换下钻状态（需要重刷dom结构）,下钻后可以设置居中的dom。默认中心dom(允许传入mac，自定义居中的dom)下钻后居中
;
  _proto.switchView = function switchView(drill, mac, callback) {
    if (drill === void 0) {
      drill = true;
    }
    if (!drill) this.drag.reset(); // 取消下钻，切换为全网，恢复drag初始值
    this.branchs.forEach(function (item) {
      item.centerDomArr[0].drillDown(drill, true, false, mac);
    });
    callback && callback();
  }

  // 已经是下钻状态下且状态不变（不用重刷dom结构），设置切换居中点
;
  _proto.switchCenterByDrill = function switchCenterByDrill(mac) {
    var _this5 = this;
    this.branchs.forEach(function (item) {
      // 先去遍历一遍中心dom，判断是否一致
      item.centerDomArr.forEach(function (center) {
        if (center.data.mac === mac) {
          _this5.drag.moveTargetToCenter(center.dom);
        }
      });
      // 再去遍历一遍叶子dom，判断是否一致
      item.leafsArr.forEach(function (leaf) {
        if (leaf.node.data.mac === mac) {
          _this5.drag.moveTargetToCenter(leaf.node.dom);
        }
      });
    });
  }

  // 图表渲染完毕的回调
;
  _proto.onRenderReady = function onRenderReady(callback) {
    this.renderCallBack = callback;
  }

  // 销毁图表
;
  _proto.uninstall = function uninstall() {
    this.dom.innerHTML = '';
    window.removeEventListener('dragScaleChange', this.dragScaleChange.bind(this));
  }

  // 移除所有的节点高亮状态
;
  _proto.removeNodeActive = function removeNodeActive() {
    this.branchs.forEach(function (item) {
      item.centerDomArr.forEach(function (center) {
        if (center.dom.classList.contains('nodeActive')) {
          center.dom.classList.remove('nodeActive');
        }
      });
      item.leafsArr.forEach(function (leaf) {
        if (leaf.node.dom.classList.contains('nodeActive')) {
          leaf.node.dom.classList.remove('nodeActive');
          // 叶子节点高亮前后内部的dom变更了，需要重新调用一下它的渲染内容方法
          leaf.node.insertContent();
        }
      });
    });
  }

  // 刷新line，不会重构dom
;
  _proto.refreshLine = function refreshLine(data) {
    this.data = data;
    compareRefresh(data, this.branchs, {
      centerArr: 'centerLineArr',
      target: 'line'
    }, this);
  }

  // 刷新tag，不会重构dom
;
  _proto.refreshTag = function refreshTag(data) {
    this.data = data;
    compareRefresh(data, this.branchs, {
      centerArr: 'centerTagArr',
      target: 'tag'
    }, this);
  }

  // 刷新node，不会重构dom
;
  _proto.refreshNode = function refreshNode(data, callback) {
    this.data = data;
    compareRefresh(data, this.branchs, {
      centerArr: 'centerDomArr',
      target: 'node'
    }, this);
    callback && callback();
  }

  // 刷新option,会重构dom
;
  _proto.refresh = function refresh(option, callback) {
    this.branchs = [];
    this.container.innerHTML = null;
    this.firstRecordStatus = true;
    this.setSimpleOption(null, option, {
      drag: this.drag
    });
    this.renderBranch();
    callback && callback();
  }

  // 刷新data，会重构dom
;
  _proto.refreshData = function refreshData(data, callback) {
    this.option.data = data;
    this.refresh(this.option, callback);
  };
  _proto.findFitScale = function findFitScale(callback) {
    if (!this.option.scaleAdaptive || this.option.overAll) return;
    var dragScale = this.drag.scale;
    var branchArr = Array.from(this.dom.querySelectorAll('.sfc-branch'));
    var leafArr = Array.from(this.dom.querySelectorAll('.sfc-branch .sfc-node-item'));
    var centerNodeArr = Array.from(this.dom.querySelectorAll('.sfc-branch .sfc-node-center'));
    var _getAreaScope = getAreaScope(leafArr.length ? leafArr : branchArr),
      snowWidth = _getAreaScope.width,
      snowHeight = _getAreaScope.height;
    var viewContainer = this.drag.container;
    var _viewContainer$getBou = viewContainer.getBoundingClientRect(),
      viewWidth = _viewContainer$getBou.width,
      viewHeight = _viewContainer$getBou.height,
      x = _viewContainer$getBou.x,
      y = _viewContainer$getBou.y;
    var fitScale;
    // 判定scale=0.75时，能否显示全雪花图
    if (viewWidth >= snowWidth * 0.75 / dragScale && viewHeight >= snowHeight * 0.75 / dragScale) {
      // 0.75以上展示的下，不改变主从网关的距离,只需调整到合适的scale值
      fitScale = Math.min(viewWidth / (snowWidth / dragScale), viewHeight / (snowHeight / dragScale));
      fitScale = Math.min(this.drag.scaleLimit.max, Math.floor(fitScale * 10) / 10);
      fitScale = Math.max(0.75, Math.floor(fitScale * 10) / 10);
    } else {
      // 0.75以上展示不下，需要拉近主从网关的距离,同时需调整到合适的scale值
      this.lowScaleView();
      var _getAreaScope2 = getAreaScope(centerNodeArr),
        _snowWidth = _getAreaScope2.width,
        _snowHeight = _getAreaScope2.height;
      fitScale = Math.min(viewWidth / (_snowWidth / dragScale), viewHeight / (_snowHeight / dragScale));
      fitScale = Math.min(0.75, Math.floor(fitScale * 10) / 10);
      fitScale = Math.max(this.drag.scaleLimit.min, Math.floor(fitScale * 10) / 10);
    }
    this.drag.scale = fitScale;
    this.drag.scaleDom(x + viewWidth / 2, y + viewHeight / 2, fitScale - dragScale, false);
    var dragCurrentVal = this.drag.container.querySelector('.drag-currentVal');
    dragCurrentVal.innerHTML = (fitScale * 100).toFixed(0) + '%';
    this.refreshNode(this.data);
    this.refreshLine(this.data);
    this.refreshTag(this.data);
    callback && callback();
  };
  _proto.dragScaleChange = function dragScaleChange(e) {
    var _this6 = this;
    if (this.option.overAll || !this.option.scaleAdaptive) return;
    var scale = e.detail.scaleVal;

    // 0.75以下隐藏主从网关的外环边框，拉近主从网关的间距
    if (scale >= 0.5 && scale <= 0.75) {
      this.lowScaleView();
      // 如果叶子节点居中的，但是缩小了，叶子节点都隐藏了，为了视觉效果，将整个图表居中
      setTimeout(function () {
        _this6.drag.moveTargetToCenter(_this6.container);
      }, this.drag.throldHold);
    } else {
      this.highScaleView();
    }
    this.refreshNode(this.data);
    this.refreshLine(this.data);
    this.refreshTag(this.data);
  };
  // 0.5-0.75倍的显示
  _proto.lowScaleView = function lowScaleView() {
    var _this7 = this;
    // 拉近主从网关的间距
    var branchArr = Array.from(this.dom.querySelectorAll('.sfc-branch'));
    if (this.firstRecordStatus) {
      setAttribute(branchArr[0], {
        'data-width': branchArr[0].style.width,
        'data-height': branchArr[0].style.height
      });
    }
    branchArr[0].style.width = '150px';
    branchArr[0].style.height = '150px';
    branchArr.shift();
    branchArr.forEach(function (branch, index) {
      var equalDeg = _this7.branchs[0].centerDomArr[index + 1].equalDeg;
      var centerDomWidth = pxToNumber(getStyle(branch.querySelector('.sfc-node-center'), 'width'));
      var distance = Math.max(getWaistLength(equalDeg, centerDomWidth + 20), _this7.option.distance.minDistanceDrill); // 避免ap重叠，需要动态计算distance
      var parentBranchWidth = pxToNumber(getStyle(branch.parentNode, 'width'));
      var centerLine = _this7.branchs[0].centerLineArr.find(function (item) {
        return item.data.mac === branch.getAttribute('data-mac');
      });
      if (_this7.firstRecordStatus) {
        setAttribute(branch, {
          // 需要将scle为1的left和transformOrigin记录下来；也需要将其width和height切换掉。不然中心节点无法点击，会被容器盖住
          'data-left': branch.style.left,
          'data-transformOrigin': branch.style.transformOrigin,
          'data-distance': centerLine.distance,
          'data-width': branch.style.width,
          'data-height': branch.style.height
        });
      }
      branch.style.transformOrigin = "calc(50% - " + distance + "px) center";
      branch.style.left = "calc(100% + " + distance + "px - " + parentBranchWidth / 2 + "px)";
      branch.style.width = '150px';
      branch.style.height = '150px';
      // 更新主从网关间的canvas连线     
      centerLine.distance = distance - parentBranchWidth / 2;
      centerLine.destroyCanvas();
      centerLine.createCanvas();
      centerLine.draw();
    });
    var coreContainerArr = this.dom.querySelectorAll('.sfc-core');
    coreContainerArr.forEach(function (item) {
      setStyle(item, {
        backgroundSize: 0
      });
    });
    this.firstRecordStatus = false;
  }

  // 0.75-1.5倍的显示
;
  _proto.highScaleView = function highScaleView() {
    var _this8 = this;
    if (this.firstRecordStatus) this.lowScaleView(); // 如果设备比较少，初始化scale的时候，没走lowScaleView。那么首次放大时需要这边手动调一次，拿到自定义数据
    var branchArr = Array.from(this.dom.querySelectorAll('.sfc-branch'));
    branchArr[0].style.width = branchArr[0].getAttribute('data-width');
    branchArr[0].style.height = branchArr[0].getAttribute('data-height');
    branchArr.shift();
    branchArr.forEach(function (item) {
      item.style.left = item.getAttribute('data-left');
      item.style.transformOrigin = item.getAttribute('data-transformOrigin');
      item.style.width = item.getAttribute('data-width');
      item.style.height = item.getAttribute('data-height');
      // 更新主从网关间的canvas连线
      var centerLine = _this8.branchs[0].centerLineArr.find(function (line) {
        return line.data.mac === item.getAttribute('data-mac');
      });
      centerLine.distance = item.getAttribute('data-distance');
      centerLine.destroyCanvas();
      centerLine.createCanvas();
      centerLine.draw();
    });
    var coreContainerArr = this.dom.querySelectorAll('.sfc-core');
    coreContainerArr.forEach(function (item) {
      setStyle(item, {
        backgroundSize: '100% 100%'
      });
    });
  };
  return SnowFlakeChart;
}(BaseChart);
_defineProperty(SnowFlakeChart, "name", CHART_TYPE.SNOWFLAKE);
export { SnowFlakeChart as default };
