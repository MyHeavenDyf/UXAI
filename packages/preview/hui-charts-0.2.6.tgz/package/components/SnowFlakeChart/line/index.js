var _LineFactory;
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import { degPositive, setDirection, pxToNumber, getStyle, insertDom, judgeDisabled, setStyle, getTextWidth, extractNumbersAndDots, getUnitText } from '../util.js';
import { ConnectType, interval, textStyle, LineType, direction, IntervalType, tagPosition } from '../CommonConstant.js';
import LineStraight from './LineStraight.js';
import Line2G from './LineArrow.js';
import LineDashed from './LineDashed.js';
import LineDotted from './LineDotted.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

var LineFactory = (_LineFactory = {}, _LineFactory[LineType.TYPE_Straight] = LineStraight, _LineFactory[LineType.TYPE_Arrow] = Line2G, _LineFactory[LineType.TYPE_Dashed] = LineDashed, _LineFactory[LineType.TYPE_Dotted] = LineDotted, _LineFactory);
var LineManager = /*#__PURE__*/function () {
  function LineManager(_ref, data, deg, _ref2, isSubRoot, tagWidth) {
    var lineWrapper = _ref.lineWrapper,
      leafNode = _ref.leafNode;
    var imageList = _ref2.imageList,
      option = _ref2.option,
      centerDom = _ref2.centerDom,
      distance = _ref2.distance,
      drag = _ref2.drag;
    this.isSubRoot = isSubRoot;
    this.container = lineWrapper;
    this.data = data;
    this.option = option;
    this.deg = degPositive(deg); // 判断方向前，控制角度在0-360区间
    this.imageList = imageList; // canvas用到的图片实例
    this.canvasWidth;
    this.canvasHeight = 150;
    this.direction = setDirection(this.deg);
    this.canvas;
    this.ctx;
    this.iconSize = 10; // 上下行速率图标尺寸
    this.distance = distance;
    this.centerDom = centerDom.dom;
    this.leafNode = leafNode.dom;
    this.drag = drag;
    this.tagWidth = isSubRoot ? 0 : tagWidth;
    this.createCanvas();
    this.draw();
  }

  // 获取canvas的宽度
  var _proto = LineManager.prototype;
  _proto.createCanvas = function createCanvas() {
    var containerWidth = pxToNumber(getStyle(this.container, 'width')); // 连线分组容器的宽度
    var centerDomWidth = pxToNumber(getStyle(this.centerDom, 'width')); // 中心dom的宽度
    var centerparentWidth = pxToNumber(getStyle(this.centerDom.parentNode, 'width')); // 中心dom外环的宽度
    var leafNodeWidth = pxToNumber(getStyle(this.leafNode, 'width')); // 叶子dom的宽度
    this.canvasWidth = containerWidth / 2 - centerDomWidth / 2;
    if (this.isSubRoot) {
      // 主从网关的连线，需要考虑distance属性
      // data.distance  只是为了让巴展那边调整主网关上行设备的距离，不推荐使用
      // this.distance是主网关的最右侧到从网关圆心的距离
      this.canvasWidth = (this.data.distance || this.distance) - leafNodeWidth / 2 + centerparentWidth / 2 - centerDomWidth / 2;
    }
    var left = direction.left;
    // 判断canvas所在的角度，如果是在三四象限，修改canvas的样式(为了解决旋转导致的文本镜像问题)
    var canvasStyle;
    if (this.direction === left) {
      canvasStyle = {
        right: "calc(50% + " + centerDomWidth / 2 + "px)",
        transformOrigin: "calc(100% + " + centerDomWidth / 2 + "px) center",
        transform: "translate(0,-50%) rotate(" + (this.deg - 180) + "deg)"
      };
    } else {
      canvasStyle = {
        left: "calc(50% + " + centerDomWidth / 2 + "px)",
        transformOrigin: -1 * centerDomWidth / 2 + "px center",
        transform: "translate(0,-50%) rotate(" + this.deg + "deg)"
      };
    }
    this.canvas = insertDom(this.container, {
      "class": 'sfc-line-item',
      width: this.canvasWidth * 2,
      height: this.canvasHeight * 2
    }, _extends({}, canvasStyle), 'canvas');
    this.ctx = this.canvas.getContext('2d');
    // 确保字体清晰
    this.canvas.style.width = this.canvasWidth + 'px';
    this.canvas.style.height = this.canvasHeight + 'px';
    this.ctx.scale(2, 2);
  }

  // 卸载canvas
;
  _proto.destroyCanvas = function destroyCanvas() {
    this.container.removeChild(this.canvas);
  }

  // 绘制canvas连线
;
  _proto.draw = function draw() {
    judgeDisabled(this.option, [this.canvas]);
    // overAll视图，非次级根节点，不生成划线和文本
    if (this.option.overAll && !this.isSubRoot) {
      return;
    }
    this.ctx.clearRect(0, 0, 10000, 10000);
    this.ctx.beginPath();
    // canvas 纵向绘制起始点
    var verCenterPoint = (this.canvasHeight - this.iconSize) / 2;
    this.drawLine(verCenterPoint);
    if (!this.option.overAll && this.option.scaleAdaptive) {
      // 家庭视口
      var scale = this.drag.scale;
      if (scale >= 0.5 && scale <= 0.75) {
        // 0.5-0.75 隐藏叶子节点的canvas、文本
        !this.isSubRoot && setStyle(this.canvas, {
          display: 'none'
        });
      } else if (scale > 0.75 && scale < 0.95) {
        // 0.75-0.95 展示canvas不展示文本
        setStyle(this.canvas, {
          display: 'block'
        });
      } else if (scale >= 0.95 && scale <= 1.5) {
        this.drawText(verCenterPoint); // 0.95-1.5 正常展示
        setStyle(this.canvas, {
          display: 'block'
        });
      }
    } else {
      // 全网视口正常展示文本和canvas
      this.drawText(verCenterPoint);
      setStyle(this.canvas, {
        display: 'block'
      });
    }
    this.ctx.closePath();
  };
  _proto.drawLine = function drawLine(verCenterPoint) {
    var _this$data = this.data,
      connectInterface = _this$data.connectInterface,
      lineStrokeColor = _this$data.lineStrokeColor;
    var lineType;
    var intervalType;
    if (connectInterface.indexOf(ConnectType.SSID) !== -1) {
      if (connectInterface === ConnectType.SSID_MIX) {
        lineType = LineType.TYPE_Straight;
      } else {
        lineType = LineType.TYPE_Arrow;
        intervalType = connectInterface.slice(5);
      }
    } else if (connectInterface.indexOf(ConnectType.Wireless) !== -1) {
      lineType = LineType.TYPE_Arrow;
      intervalType = IntervalType.Wireless;
    } else if (connectInterface.indexOf(ConnectType.Dashed) !== -1) {
      lineType = LineType.TYPE_Dashed;
    } else if (connectInterface.indexOf(ConnectType.Dotted) !== -1) {
      lineType = LineType.TYPE_Dotted;
    } else {
      lineType = LineType.TYPE_Straight;
    }
    var line = new LineFactory[lineType](this, verCenterPoint, interval[intervalType], lineStrokeColor, intervalType);
    line.draw();
  }

  // 待调整  提到drawline内部
;
  _proto.drawText = function drawText(verCenterPoint) {
    var _this$imageList = this.imageList,
      imageUp = _this$imageList.imageUp,
      imageDown = _this$imageList.imageDown;
    var _this$data2 = this.data,
      upRate = _this$data2.upRate,
      downRate = _this$data2.downRate;
    var left = direction.left;
    var maxTextWidth = Math.max(getTextWidth(upRate), getTextWidth(downRate));
    // canvas 横向绘制起始点  // 设备取居中往内偏位置
    var actualCanvasRatio = (100 - (100 - tagPosition) * 2) / 100; // 文本在tag和中心点之间的位置
    var horCenterPoint;
    if (this.direction === left) {
      horCenterPoint = this.canvasWidth - maxTextWidth - (this.canvasWidth * actualCanvasRatio - maxTextWidth - this.tagWidth) / 2;
    } else {
      horCenterPoint = (this.canvasWidth * actualCanvasRatio - maxTextWidth - this.tagWidth) / 2;
    }
    // let horCenterPoint = (this.canvasWidth - maxTextWidth) / (this.direction === left ? 2 * 0.6 : 2 / 0.6);
    if (this.isSubRoot) {
      // 主从网关默认去居中位置
      horCenterPoint = (this.canvasWidth - maxTextWidth) / 2;
    }
    var _textStyle = textStyle(this.option.theme),
      font = _textStyle.font,
      bgStyle = _textStyle.bgStyle,
      fillStyle = _textStyle.fillStyle,
      unitStyle = _textStyle.unitStyle;
    this.ctx.font = font;

    // // 上文字背景块，文字居中往左移24
    // this.ctx.roundRect(horCenterPoint - 24, verCenterPoint - 28, maxTextWidth + 24 + 8, 24, 12);
    // // 下文字背景块
    // this.ctx.roundRect(horCenterPoint - 24, verCenterPoint + 12, maxTextWidth + 24 + 8, 24, 12);
    // this.ctx.fillStyle = bgStyle;
    // this.ctx.fill();

    if (upRate) {
      this.ctx.fillStyle = fillStyle;
      // 上行icon,文本居中往左移16
      this.ctx.drawImage(imageUp.image, horCenterPoint - 16, verCenterPoint - 12, this.iconSize, this.iconSize);
      // 上行速率，文本居中
      this.ctx.fillText(extractNumbersAndDots(upRate), horCenterPoint, verCenterPoint - 2);
      // 上行单位
      this.ctx.fillStyle = unitStyle;
      this.ctx.fillText(getUnitText(upRate), horCenterPoint + getTextWidth(extractNumbersAndDots(upRate)) + 4, verCenterPoint - 2);
    }
    if (downRate) {
      this.ctx.fillStyle = fillStyle;
      // 下行icon,文本居中往左移16
      this.ctx.drawImage(imageDown.image, horCenterPoint - 16, verCenterPoint + 12, this.iconSize, this.iconSize);
      // 下行速率,文本居中
      this.ctx.fillText(extractNumbersAndDots(downRate), horCenterPoint, verCenterPoint + 22);
      // 下行单位
      this.ctx.fillStyle = unitStyle;
      this.ctx.fillText(getUnitText(downRate), horCenterPoint + getTextWidth(extractNumbersAndDots(downRate)) + 4, verCenterPoint + 22);
    }
  }

  // 刷新数据的方法
;
  _proto.refreshData = function refreshData(data) {
    this.data = data !== undefined ? data : this.data;
    this.draw();
  };
  return LineManager;
}();
export { LineManager as default };
