import { ConnectType } from '../CommonConstant.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var LineStraight = /*#__PURE__*/function () {
  function LineStraight(_ref, verCenterPoint, interval, lineStrokeColor) {
    var ctx = _ref.ctx,
      canvasWidth = _ref.canvasWidth,
      canvasHeight = _ref.canvasHeight,
      data = _ref.data;
    var lineWidth = data.lineWidth,
      connectInterface = data.connectInterface;
    this.ctx = ctx;
    this.canvasWidth = canvasWidth;
    this.canvasHeight = canvasHeight;
    this.lineStrokeColor = lineStrokeColor != null ? lineStrokeColor : connectInterface === ConnectType.SSID_MIX ? '#8c57af' : '';
    this.lineWidth = lineWidth != null ? lineWidth : connectInterface === ConnectType.SSID_MIX ? 8 : 2;
  }
  var _proto = LineStraight.prototype;
  _proto.draw = function draw() {
    this.ctx.moveTo(0, this.canvasHeight / 2);
    this.ctx.lineTo(this.canvasWidth, this.canvasHeight / 2);
    this.ctx.lineWidth = this.lineWidth;
    this.ctx.strokeStyle = this.lineStrokeColor;
    this.ctx.stroke();
  };
  return LineStraight;
}();
export { LineStraight as default };
