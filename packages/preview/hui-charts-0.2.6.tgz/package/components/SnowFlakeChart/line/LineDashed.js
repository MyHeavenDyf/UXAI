/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var LineDashed = /*#__PURE__*/function () {
  function LineDashed(_ref, verCenterPoint, interval, lineStrokeColor) {
    var ctx = _ref.ctx,
      canvasWidth = _ref.canvasWidth,
      canvasHeight = _ref.canvasHeight,
      data = _ref.data;
    var lineWidth = data.lineWidth;
    this.ctx = ctx;
    this.canvasWidth = canvasWidth;
    this.canvasHeight = canvasHeight;
    this.lineStrokeColor = lineStrokeColor;
    this.lineWidth = lineWidth != null ? lineWidth : 2;
  }
  var _proto = LineDashed.prototype;
  _proto.draw = function draw() {
    this.ctx.moveTo(0, this.canvasHeight / 2);
    this.ctx.lineTo(this.canvasWidth, this.canvasHeight / 2);
    this.ctx.lineWidth = this.lineWidth;
    this.ctx.strokeStyle = this.lineStrokeColor;
    this.ctx.setLineDash([this.lineWidth * 2, this.lineWidth * 2]);
    this.ctx.stroke();
  };
  return LineDashed;
}();
export { LineDashed as default };
