function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import { setStyle, getSingle } from './util.js';
import defendXSS from '../../util/defendXSS.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 主从网关。
var rootDefault = function rootDefault(data, nodeContainer, isRoot, option, scale) {
  var _data$children;
  var theme = option.theme,
    overAll = option.overAll;
  setStyle(nodeContainer, {
    width: isRoot ? '150px' : '110px',
    height: isRoot ? '150px' : '110px'
  });
  var _getSingle = getSingle(data, isRoot ? 'root' : 'ap'),
    single = _getSingle.single,
    singleTextColor = _getSingle.singleTextColor;
  var mainColor = theme.indexOf('dark') !== -1 ? '#f5f5f5' : '#191919';
  var subColor = theme.indexOf('dark') !== -1 ? '#bbbbbb' : '#999999';
  nodeContainer.innerHTML = "\n  <div class='centerNode_defaultRender'>\n    <img \n      class=" + (isRoot ? 'rootImg' : 'apImg') + "  \n      src='./image/device/" + defendXSS(data.deviceType) + ".png' \n      draggable=false>\n    </img>\n    <div \n      class='deviceName " + (isRoot ? 'rootName' : 'apName') + "' \n      style='color:" + mainColor + ";' \n      title=" + defendXSS(data.deviceName) + ">\n      " + defendXSS(data.deviceName) + "\n    </div>\n    <div \n      class='onlineDuration' \n      style='color:" + subColor + ";display:" + (data.onlineDuration ? 'block' : 'none') + ";' \n      title=" + defendXSS(data.onlineDuration) + ">\n      " + defendXSS(data.onlineDuration) + "\n    </div>\n    <div \n      style='color:" + defendXSS(singleTextColor) + ";display:" + (single ? 'block' : 'none') + "' \n      title=" + defendXSS(single) + ">\n      " + defendXSS(single) + "\n    </div>\n    <div \n      style='color:" + subColor + ";display:" + (data.trafficStatistics ? 'block' : 'none') + "' \n      title=" + defendXSS(data.trafficStatistics) + ">\n      " + defendXSS(data.trafficStatistics) + "\n    </div>\n    <div \n      class='terminalNumTip'\n      style='color:" + mainColor + "'>\n      \u7EC8\u7AEF\uFF1A" + (((_data$children = data.children) == null ? void 0 : _data$children.filter(function (item) {
    return !item.isAP;
  }).length) || 0) + "\u4E2A\n    </div>\n  </div>";
  if (scale >= 0.5 && scale < 0.95) {
    nodeContainer.innerHTML = "\n    <div class='centerNode_defaultRender'>\n      <div \n        class='deviceName " + (isRoot ? 'rootName' : 'apName') + "' \n        style='color:" + mainColor + ";' \n        title=" + defendXSS(data.deviceName) + ">\n        " + defendXSS(data.deviceName) + "\n      </div>\n    </div>";
  }
};
var overAllTag = function overAllTag(data, tagContainer) {
  // tag节点
  setStyle(tagContainer, {
    width: 0,
    height: 0,
    border: 0
  });
  tagContainer.innerHTML = null;
};

// 正常态叶子节点样式
var houseLeaf = function houseLeaf(data, nodeContainer, isActive, theme, scale) {
  setStyle(nodeContainer, {
    width: '100px',
    height: '100px',
    display: 'block'
  });
  var imageSrc = data.deviceType;
  var imgBg = 'staSelected'; // 终端选中态的图片周边阴影
  if (data.faultNumber) {
    imageSrc += '_error';
    imgBg += '_error';
  }
  if (isActive) {
    // 点击态的图片
    imageSrc = data.deviceType;
  } else {
    imgBg = 'unset';
  }
  var _getSingle2 = getSingle(data, 'leaf'),
    single = _getSingle2.single,
    singleTextColor = _getSingle2.singleTextColor;
  var mainColor = theme.indexOf('dark') !== -1 ? '#ffffff' : '#191919';
  var subColor = theme.indexOf('dark') !== -1 ? '#bbbbbb' : '#999999';
  var leafBg = theme.indexOf('dark') !== -1 ? 'rgba(25,25,25,.6)' : 'rgba(25,25,25,.1)';
  var HTMLstr = "\n  <div class='leafNode_defaultRender'>\n    <div class='imgBg' \n      style='background:" + (imgBg !== 'unset' ? "url(./image/device/" + defendXSS(imgBg) + ".svg)" : imgBg) + ";'>\n      <img \n        src='./image/device/" + defendXSS(imageSrc) + ".svg' \n        draggable=false>\n      </img>\n      <div class='deviceName' \n        style='color:" + mainColor + ";' \n        title=" + defendXSS(data.deviceName) + ">\n        " + defendXSS(data.deviceName) + "\n      </div>\n      <div \n        style='color:" + defendXSS(singleTextColor) + ";display:" + (single ? 'block' : 'none') + "' \n        title=" + defendXSS(single) + ">\n        " + defendXSS(single) + "\n      </div>\n      <div \n        style='color:" + subColor + ";display:" + (data.trafficStatistics ? 'block' : 'none') + "' \n        title=" + defendXSS(data.trafficStatistics) + ">\n        " + defendXSS(data.trafficStatistics) + "\n      </div>\n    </div>\n  </div>\n  <div class='leafNodeShadow'\n    style='background:" + leafBg + ";display:" + (isActive ? 'none' : 'block') + "'>\n  </div>";
  setTimeout(function () {
    nodeContainer.innerHTML = HTMLstr;
  }, 20);
  if (scale >= 0.5 && scale <= 0.75) {
    setStyle(nodeContainer, {
      display: 'none'
    });
  }
};
var overAllLeaf = function overAllLeaf(data, nodeContainer, option) {
  setStyle(nodeContainer, {
    // 宽高用户可自定义配置。
    width: '24px',
    height: '24px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
  });
  nodeContainer.innerHTML = null;
};
/**
 * 全网
 * @param {*} param0
 * @param {*} data
 * @param {*} option
 */
var handleOverall = function handleOverall(_ref, data, option) {
  var nodeContainer = _ref.nodeContainer,
    tagContainer = _ref.tagContainer;
  if (data.isRoot || data.isAP || data.children && data.children.length) {
    // 根节点(默认166*166)
    if (data.isRoot || data.mac === option.data[0].mac) {
      rootDefault(data, nodeContainer, true, option);
    } else {
      // 次级根节点(默认104*104)
      rootDefault(data, nodeContainer, false, option);
    }
  } else {
    // 叶子节点(默认38*38)
    overAllLeaf(data, nodeContainer);
  }
  // tag节点
  overAllTag(data, tagContainer);
};
var houseTag = function houseTag(data, tagContainer, theme, scale) {
  var _data$connectInterfac, _data$connectInterfac2;
  var commonStyle = {
    padding: '4px 12px',
    background: theme.indexOf('dark') !== -1 ? '#191919' : '#ffffff',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: '999px',
    whiteSpace: 'nowrap'
  };
  if (((_data$connectInterfac = data.connectInterface) == null ? void 0 : _data$connectInterfac.indexOf('SSID')) === -1 && ((_data$connectInterfac2 = data.connectInterface) == null ? void 0 : _data$connectInterfac2.indexOf('wireless')) === -1) {
    var _data$connectInterfac3;
    setStyle(tagContainer, _extends({}, commonStyle, {
      border: '1px solid #777777',
      display: ((_data$connectInterfac3 = data.connectInterface) == null ? void 0 : _data$connectInterfac3.indexOf('PON')) === -1 ? 'flex' : 'none'
    }));
    tagContainer.innerHTML = "<div>" + defendXSS(data.connectInterface.replace('Straight-', '')) + "</div>";
  } else {
    var _data$connectInterfac4;
    setStyle(tagContainer, _extends({}, commonStyle, {
      border: ((_data$connectInterfac4 = data.connectInterface) == null ? void 0 : _data$connectInterfac4.indexOf('2.4G')) !== -1 ? '1px solid #2070F3' : '1px solid #058358',
      display: data.wifiChannel ? 'flex' : 'none'
    }));
    setStyle(tagContainer, {
      // 当信道为三位数以下，固定宽度为40px
      width: String(data.wifiChannel).length <= 2 ? '40px' : 'unset'
    });
    tagContainer.innerHTML = defendXSS(data.wifiChannel);
  }
  if (scale >= 0.5 && scale < 0.95) {
    setStyle(tagContainer, {
      display: 'none'
    });
  }
};

/**
 * 家庭
 * @param {*} param0
 * @param {*} data
 * @param {*} option
 */
var handleHouse = function handleHouse(_ref2, data, option, scale) {
  var nodeContainer = _ref2.nodeContainer,
    tagContainer = _ref2.tagContainer;
  if (data.isRoot || data.isAP || data.children && data.children.length) {
    // 根节点(默认166*166)
    if (data.isRoot || data.mac === option.data[0].mac) {
      rootDefault(data, nodeContainer, true, option, scale);
    } else {
      // 次级根节点(默认166*166)
      rootDefault(data, nodeContainer, false, option, scale);
    }
  } else {
    var _nodeContainer$parent;
    // 叶子节点(默认104*104)
    var classList = (nodeContainer == null ? void 0 : (_nodeContainer$parent = nodeContainer.parentNode) == null ? void 0 : _nodeContainer$parent.classList) || [];
    var isActive = [].concat(classList).indexOf('nodeActive') !== -1;
    houseLeaf(data, nodeContainer, isActive, option.theme, scale);
  }
  // tag节点
  houseTag(data, tagContainer, option.theme, scale);
};
var defaultOption = {
  isLink: false,
  // 主网关是否预留一个位置
  distance: {
    minDistance: 200,
    // 全网视口，主从网关的圆心的最小距离
    minDistanceDrill: 400 // 下钻视口，主从网关的圆心的最小距离
  },
  ratio: {
    // 全网视口，递归生成的节点必定在minRatio-maxRatio之间，如果终端设备数量超过了该网关能展示的最大数量，后续终端不会展示出来，出现...
    minRatio: 0.5,
    // 全网视口 递归节点的最小尺寸占比
    maxRatio: 0.75,
    // 全网视口 递归节点的最大尺寸占比
    // 家庭视口，如果终端设备数量超过了该网关能展示的最大数量，则允许尺寸占比超出maxRatioDrill
    minRatioDrill: 0.7,
    // 家庭视口 递归节点的最小尺寸占比
    maxRatioDrill: 0.8 // 家庭视口 递归节点的最大尺寸占比
  },
  overAll: true,
  // 是否为全局视口（节点变小，隐藏tag、line)
  scaleAdaptive: false,
  // 家庭视口下，drag的不同缩放值会产生不同的视图（且首次进入家庭视口，会开启自适应缩放功能）
  // 默认渲染配置
  render: function render(_ref3, data, option, scale) {
    var nodeContainer = _ref3.nodeContainer,
      tagContainer = _ref3.tagContainer;
    if (option.overAll) {
      // 全网
      handleOverall({
        nodeContainer: nodeContainer,
        tagContainer: tagContainer
      }, data, option);
    } else {
      // 家庭
      handleHouse({
        nodeContainer: nodeContainer,
        tagContainer: tagContainer
      }, data, option, option.scaleAdaptive ? scale : null);
    }
  }
};
var defaultToolTip = function defaultToolTip(data, isLeaf) {
  var HTMLstr = "\n  <div class='sfcTipContainer'>\n    <div>" + data.deviceName + "</div>\n    <div class='rateInfo'>\n      <img src='./image/device/up.svg' />\n      " + data.upRate + "\n    </div>\n    <div class='rateInfo'>\n      <img src='./image/device/down.svg' />\n      " + data.downRate + "\n    </div>\n  </div>";
  if (!isLeaf) {
    HTMLstr = '点击查看详细拓扑';
  }
  return HTMLstr;
};
export { defaultOption as default, defaultToolTip };
