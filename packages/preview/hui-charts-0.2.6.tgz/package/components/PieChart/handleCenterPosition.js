import mobile from '../../util/mobile.js';
function updatePosition(iChartOption, legend, chartInstance) {
  // 兼容旧属性chartPosition
  var position = iChartOption.position || iChartOption.chartPosition;
  var adaptive = iChartOption == null ? void 0 : iChartOption.adaptive;
  var width = chartInstance == null ? void 0 : chartInstance.getWidth == null ? void 0 : chartInstance.getWidth();
  var height = chartInstance == null ? void 0 : chartInstance.getHeight == null ? void 0 : chartInstance.getHeight();
  // 暂时用来只开放华为云主题
  var theme = iChartOption == null ? void 0 : iChartOption.theme;
  var isMobile = iChartOption.isMobile || mobile();
  var mobileCenter = isMobile ? getMobilePositionCenter(iChartOption) : undefined;
  var graphHeight = iChartOption.graphHeight; //移动端左右布局图例大于50%时，图形剩余高度

  // 1.自适应处理圆环中心点位置，开启adaptive就会强行覆盖用户的position
  if (adaptive && theme.includes('hdesign')) {
    position = {}; // 初始化为空对象
    // 圆环外直径
    var circleDiameter;
    if (legend.show === true) {
      //上下布局
      if (legend.orient === 'horizontal') {
        var circleSection = height - 16 - (legend.bottom !== 'auto' ? legend.bottom : 4);
        position.center = isMobile ? mobileCenter : [width / 2, circleSection / 2];
        circleDiameter = isMobile && graphHeight ? graphHeight - 16 : Math.min(width, circleSection) * 0.6;
      } else {
        //左右布局
        position.center = isMobile ? mobileCenter : ['30%', '50%'];
        circleDiameter = isMobile ? width * 0.5 * 0.8 : width * 0.6 * 0.8;
      }
    } else {
      // 图例不显示中心就居中
      position.center = ['50%', '50%'];
      circleDiameter = width * 0.8;
    }
    position.radius = Math.max(60, Math.min(200, Math.min(circleDiameter, height))) / 2;
  }
  return position;
}
function getMobilePositionCenter(iChartOption) {
  var graphHeight = iChartOption.graphHeight; // 图形区高度 图例大于50%时
  var legend = iChartOption.legend; // 图形区高度 图例大于50%时
  if (!graphHeight) {
    if ((legend == null ? void 0 : legend.orient) === 'horizontal') {
      return ['25%', '50%'];
    } else {
      return ['25%', '50%'];
    }
  }
  var center = ['25%', '50%'];
  if (graphHeight < 120) {
    center = ['50%', 60];
  } else {
    center = ['50%', graphHeight / 2 - 4];
  }
  return center;
}
export { updatePosition as default };
