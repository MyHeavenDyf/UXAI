import merge from '../../util/merge.js';
import setLabel from './handleLabel.js';
import chartToken from './chartToken.js';
import cloneDeep from '../../util/cloneDeep.js';
import { percentToDecimal } from '../../util/math.js';
import { isArray, isString, isNumber } from '../../util/type.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

var seriesInit = function seriesInit() {
  return {
    type: 'pie',
    roundCap: true,
    radius: ['0%', '50%'],
    center: ['50%', '45%'],
    avoidLabelOverlap: true,
    itemStyle: {
      borderWidth: chartToken.borderWidth,
      borderColor: chartToken.borderColor,
      borderRadius: chartToken.borderRadius
    },
    selectedMode: false,
    roseType: false,
    label: {},
    labelLine: {},
    data: []
  };
};

/**
 * 根据参数计算出圆盘图的内外半径
 */
function handleRadius(pieType, radius, chartInstance, iChartOption, legend) {
  if (radius) {
    // 环形图且radius只有一项
    if (pieType === 'circle' && !(isArray(radius) && radius.length === 2)) {
      return setCircleRadius(radius, chartInstance, iChartOption, legend);
    } else {
      return radius;
    }
  } else {
    var _radius = [];
    switch (pieType) {
      case 'pie':
        _radius = ['0%', '50%'];
        break;
      case 'circle':
        _radius = ['44%', '50%'];
        _radius = setCircleRadius(_radius, chartInstance, iChartOption, legend);
        break;
      case 'multi-circle':
        _radius = ['44%', '50%'];
        break;
      default:
        _radius = ['0%', '50%'];
        break;
    }
    return _radius;
  }
}

/**
 * 根据圆环粗细的规范重新计算圆盘图的圆环类型的内外半径
 */
function setCircleRadius(radius, chartInstance, iChartOption, legend) {
  var width = chartInstance == null ? void 0 : chartInstance.getWidth == null ? void 0 : chartInstance.getWidth();
  var height = chartInstance == null ? void 0 : chartInstance.getHeight == null ? void 0 : chartInstance.getHeight();
  var canvasRadius = width > height ? height / 2 : width / 2;
  var adaptive = iChartOption == null ? void 0 : iChartOption.adaptive;
  // 暂时用来只开放华为云主题
  var theme = iChartOption == null ? void 0 : iChartOption.theme;
  var barWidth = iChartOption.barWidth || chartToken.barWidth;

  // 2.自适应根据圆环占比部分决定圆环粗细
  if (adaptive && theme.includes('hdesign')) {
    // TODO 下面部分没有用到
    if (theme.includes('hdesign') || theme.includes('bpit')) {
      if (legend.orient === 'horizontal') {
        // 上面圆环占比的部分
        var circleSection = height - 16 - (legend.bottom !== 'auto' ? legend.bottom : 4);
        if (circleSection >= 452) {
          barWidth = 16;
        } else if (circleSection > 296) {
          barWidth = 12;
        } else {
          barWidth = 8;
        }
      } else {
        // 左边圆环占比的部分
        var _circleSection = width * 0.6;
        if (_circleSection >= 271) {
          barWidth = 16;
        } else if (_circleSection > 178) {
          barWidth = 12;
        } else {
          barWidth = 8;
        }
      }
    }
    // 为了3计算字号算出内直径
    iChartOption.barWidth = barWidth;
  }
  var outerRing = isArray(radius) ? radius[1] || radius[0] : radius;
  if (isString(outerRing) && outerRing.indexOf('%') > -1) {
    outerRing = Number(outerRing.slice(0, -1)) / 100 * canvasRadius;
  }
  // -2去除borderwidth带来的粗细影响
  var innerRing = Number(outerRing) - barWidth - 2;
  return [innerRing, outerRing];
}

/**
 * 数据为零时添加背景
 */
function handleEmptyData(data, series, center, radius, stillShowZeroSum, legend, colorArr) {
  var total = data.reduce(function (pre, cur) {
    pre = pre + cur.value;
    return pre;
  }, 0);
  if (total === 0) {
    if (stillShowZeroSum === false) {
      series.forEach(function (item) {
        item.label = false;
        item.itemStyle.borderWidth = chartToken.borderWidthShowZero;
      });
      series.push({
        type: 'pie',
        radius: radius,
        center: center,
        emptyCircleStyle: {
          color: chartToken.colorShowZero
        },
        silent: true,
        animation: false
      });
    } else {
      legend.data !== undefined && legend.data.forEach(function (item, index) {
        item.itemStyle = {
          color: colorArr[index]
        };
      });
      series.forEach(function (item) {
        item.color = chartToken.colorShowZero;
      });
    }
  }
}
function getNewRadius(radius, chartInstance) {
  if (isNumber(radius)) {
    return radius;
  } else if (isString(radius)) {
    return radius.endsWith('%') ? percentToDecimal(radius) * (Math.min(chartInstance == null ? void 0 : chartInstance.getWidth == null ? void 0 : chartInstance.getWidth(), chartInstance == null ? void 0 : chartInstance.getHeight == null ? void 0 : chartInstance.getHeight()) / 2) : parseFloat(radius);
  } else if (isArray(radius)) {
    var decimalRadiusArr = radius.map(function (r) {
      return isNumber(r) ? r / Math.min(chartInstance == null ? void 0 : chartInstance.getWidth == null ? void 0 : chartInstance.getWidth(), chartInstance == null ? void 0 : chartInstance.getHeight == null ? void 0 : chartInstance.getHeight()) : r.endsWith('%') ? percentToDecimal(r) : parseFloat(r);
    });
    var decimalRadius = decimalRadiusArr[0] === 0 ? decimalRadiusArr[1] : decimalRadiusArr[0];
    return decimalRadius * (Math.min(chartInstance == null ? void 0 : chartInstance.getWidth == null ? void 0 : chartInstance.getWidth(), chartInstance == null ? void 0 : chartInstance.getHeight == null ? void 0 : chartInstance.getHeight()) / 2);
  }
}

// 余弦定理计算最小1px时的角度
function minAngle(radius, chartInstance) {
  var newRadius = getNewRadius(radius, chartInstance);
  var cosA = (Math.pow(newRadius, 2) + Math.pow(newRadius, 2) - Math.pow(3, 2)) / (2 * newRadius * newRadius);
  var angleAInRadians = Math.acos(cosA);
  var minAngle = angleAInRadians * (180 / Math.PI);
  return minAngle;
}

// 合并默认值seriesInit到series
function mergeDefaultSeries(seriesUnit) {
  for (var key in seriesInit()) {
    if (Object.hasOwnProperty.call(seriesInit(), key)) {
      if (key === 'itemStyle') {
        var series = cloneDeep(seriesInit());
        seriesUnit[key] = merge(series.itemStyle, seriesUnit.itemStyle);
      }
      if (seriesUnit[key] === undefined) {
        seriesUnit[key] = seriesInit()[key];
      }
    }
  }
}

// 给某个data指定的颜色
function setColor(iChartOption) {
  var data = iChartOption.data;
  var initColorGroup = iChartOption.initColor.concat();
  var colorData = iChartOption.dataRules && iChartOption.dataRules.color;
  if (colorData && isArray(initColorGroup)) {
    var _loop = function _loop(key) {
      data.forEach(function (item, index) {
        if (item.name === key && initColorGroup[index] && colorData[key]) {
          initColorGroup[index] = colorData[key];
        }
      });
    };
    for (var key in colorData) {
      _loop(key);
    }
  }
  iChartOption.color = initColorGroup;
}

/**
 * 组装echarts所需要的series
 * @param {数据} data
 * @returns
 */

var config = ['label', 'labelLine', 'itemStyle', 'radius', 'center', 'silent', 'emphasis', 'stillShowZeroSum', 'selectedMode', 'roseType', 'minAngle'];
function handleSeries(pieType, iChartOption, chartInstance, position, legend) {
  var _position, _position2;
  var data = iChartOption.data,
    stillShowZeroSum = iChartOption.stillShowZeroSum,
    showZeroBgColor = iChartOption.showZeroBgColor;
  position = position || {};
  iChartOption.center = (_position = position) == null ? void 0 : _position.center;
  iChartOption.radius = (_position2 = position) == null ? void 0 : _position2.radius;

  // 组装series数据
  var series = [];
  var selfSeries = iChartOption.series;
  if (selfSeries === undefined) {
    selfSeries = [{}];
  }
  // 保留初始的颜色数组
  iChartOption.initColor = iChartOption.color;
  // 给某个data指定的颜色
  setColor(iChartOption);
  selfSeries.forEach(function (seriesItem) {
    var seriesUnit = cloneDeep(seriesItem);
    var temp = cloneDeep(iChartOption);
    // 处理属性的优先级
    config.forEach(function (name) {
      var existValue = merge(temp[name], seriesUnit[name]);
      if (existValue !== undefined) {
        seriesUnit[name] = existValue;
      }
    });
    seriesUnit.data = seriesUnit.data || iChartOption.data;
    seriesUnit.radius = handleRadius(pieType, seriesUnit.radius, chartInstance, iChartOption, legend);
    seriesUnit.minAngle = seriesUnit.minAngle !== undefined ? seriesUnit.minAngle : minAngle(seriesUnit.radius, chartInstance);
    setLabel(seriesUnit, seriesUnit.label, seriesUnit.data);
    if (iChartOption.seriesName) seriesUnit.name = iChartOption.seriesName;
    // 和默认配置合并
    mergeDefaultSeries(seriesUnit);
    series.push(seriesUnit);
  });
  // 数据和为0
  if (!showZeroBgColor) {
    handleEmptyData(data, series, series[0].center, series[0].radius, stillShowZeroSum, legend, iChartOption.color);
  }
  return series;
}
export { handleSeries as default, seriesInit };
