import { codeToRGB, getColor, changeRgbaOpacity } from '../../util/color.js';
import cloneDeep from '../../util/cloneDeep.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

function handleResObj(item, colors, index) {
  var resObj = cloneDeep(item);
  resObj.color = {
    rgba: codeToRGB(getColor(colors, index), 1),
    from: 1,
    to: 0.2
  };
  return resObj;
}
function handleTempLegend(tempLegend, legendOffset, index) {
  if (tempLegend.orient === 'horizontal') {
    var offset = legendOffset || 30;
    var bottom = parseFloat(tempLegend.bottom) - index * parseFloat(offset);
    if (tempLegend.bottom.toString().indexOf('%') !== -1) {
      tempLegend.bottom = bottom + "%";
    } else {
      tempLegend.bottom = bottom;
    }
  } else {
    var _offset = legendOffset || 120;
    var left = parseFloat(tempLegend.left) + index * parseFloat(_offset);
    if (tempLegend.left.toString().indexOf('%') !== -1) {
      tempLegend.left = left + "%";
    } else {
      tempLegend.left = left;
    }
  }
}
function handleTempSeriesObj(item) {
  var tempSeriesObj = cloneDeep(item);
  // 优先使用自定义颜色
  tempSeriesObj.itemStyle = {
    color: item.iColor || item.color.rgba
  };
  return tempSeriesObj;
}

/**
 * 递归遍历数据
 * @param {*} data
 * @param {*} innerData
 * @param {*} innerIndex
 */
function installInnerData(data, innerData, innerIndex) {
  data.children && data.children.forEach(function (citem, cindex) {
    if (!innerData[innerIndex]) {
      innerData[innerIndex] = [];
    }
    var colorFrom = data.color.from - (data.color.from - data.color.to) / (data.children.length + 1) * (cindex + 1);
    var colorTo = data.color.from - (data.color.from - data.color.to) / (data.children.length + 1) * (cindex + 2);
    // 保存自定义颜色
    if (citem.color) {
      citem.iColor = citem.color;
    }
    citem.color = {
      rgba: changeRgbaOpacity(data.color.rgba, colorFrom),
      from: colorFrom,
      to: colorTo
    };
    innerData[innerIndex].push(citem);
    // 如果还有子层，则继续递归遍历
    if (citem.children) {
      installInnerData(citem, innerData, innerIndex + 1);
    }
  });
}

// 针对多重圆环图表需求，图表需要进行特殊处理
function handleMulti(type, baseOption, legend, data) {
  if (type === 'multi-circle') {
    var colors = baseOption.color;
    // 给源数据添加颜色属性
    var outer = data.map(function (item, index) {
      var resObj = handleResObj(item, colors, index);
      return resObj;
    });
    // 组装子层数据，给每个子数据赋值颜色
    var inner = [];
    var innerIndex = 0;
    outer.forEach(function (data) {
      installInnerData(data, inner, innerIndex);
    });
    // 组装series
    inner.forEach(function (innerData, innerIndex) {
      // 添加外层data的颜色，需要按序补充，不然会导致颜色异常
      baseOption.series[0].data.forEach(function (item, index) {
        if (item.color) {
          item.itemStyle = {
            color: item.color
          };
        } else {
          item.itemStyle = {
            color: colors[index]
          };
        }
      });
      var tempSeries = cloneDeep(baseOption.series[0]);
      tempSeries.data = innerData.map(function (item) {
        var tempSeriesObj = handleTempSeriesObj(item);
        return tempSeriesObj;
      });
      var innerDiff = parseFloat(tempSeries.radius[1]) - parseFloat(tempSeries.radius[0]);
      tempSeries.radius = tempSeries.radius.map(function (item) {
        return parseFloat(item) + innerDiff * (innerIndex + 1) + "%";
      });
      baseOption.series.push(tempSeries);
    });
    baseOption.series.forEach(function (i) {
      i.label = {
        show: false
      };
      i.labelLine = {
        show: false
      };
    });
    // 组装legend
    var dataArray = [outer].concat(inner);
    var originLegend = baseOption.legend;
    var legendOffset = legend.offset;
    baseOption.legend = [];
    dataArray.forEach(function (array, index) {
      var tempLegend = cloneDeep(originLegend);
      var tempLegendData = array.map(function (item) {
        return item.name;
      });
      tempLegend.data = tempLegendData;
      handleTempLegend(tempLegend, legendOffset, index);
      baseOption.legend.push(tempLegend);
    });
  }
}
export { handleMulti as default };
