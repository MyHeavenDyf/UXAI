import tooltip from '../../option/config/tooltip/index.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
/**
 * 配置鼠标悬浮提示框
 */
function handleTooltip(iChartOpt, chartName) {
  var basicTip = tooltip(iChartOpt, chartName);
  return basicTip;
}
function setMiniGauge(baseOpt, iChartOpt) {
  var _baseOpt$series, _baseOpt$series$;
  if (iChartOpt.mini && (_baseOpt$series = baseOpt.series) != null && (_baseOpt$series$ = _baseOpt$series[0]) != null && _baseOpt$series$.detail) {
    baseOpt.series[0].detail.show = false;
  } else {
    baseOpt.series[0].detail.show = true;
  }
}
export { handleTooltip, setMiniGauge };
