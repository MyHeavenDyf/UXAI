import '../../feature/token/index.js';
import defendXSS from '../../util/defendXSS.js';
import '../../util/constants.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

/**
 * Tips提示框回调函数
 */
function toolTipFormatter(params) {
  // 矩形部分不显示toolTip
  if (params.seriesIndex > 1) {
    return;
  }
  var htmlString = "<div style=\"margin-bottom:4px;\">" + defendXSS(params.name) + "</div>";
  htmlString += "\n\t\t<div>\n\t\t\t<span style=\"display:inline-block;width:10px;height:10px;border-radius:5px;background-color:" + defendXSS(params.color) + ";\">\n\t\t\t</span>\n\t\t\t<span style=\"margin-left:5px;\">\n                            <span style=\"display:inline-block;margin-right:8px;min-width:60px;\">" + defendXSS(params.seriesName) + "</span>\n\t\t\t<span style=\"font-weight:bold\">\n\t\t\t\t" + defendXSS(params.value) + "\n\t\t\t</span>\n\t\t</div>\n\t";
  return htmlString;
}
function handleTooltip(baseOpts, iChartOpt) {
  var _iChartOpt$tooltip;
  if (!iChartOpt.tipHtml && !(iChartOpt != null && (_iChartOpt$tooltip = iChartOpt.tooltip) != null && _iChartOpt$tooltip.formatter)) {
    baseOpts.tooltip.formatter = toolTipFormatter;
  }
}

/**
 * 设置柱状图的方向
 */
function setDirection(baseOption, direction) {
  if (direction && direction === 'horizontal') {
    var temp = baseOption.xAxis;
    baseOption.xAxis = baseOption.yAxis;
    baseOption.yAxis = temp;
  }
}
export { handleTooltip, setDirection };
