function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import { appendNode, createEl, className, appendEL } from './util.js';
import TimeLine from './TimeLine.js';
import { CHART_TYPE } from '../../util/constants.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var GanttChart = /*#__PURE__*/function () {
  function GanttChart() {
    // 图表的父容器
    this.container = void 0;
    // 配置项
    this.option = void 0;
    // 移动的初始距离
    this.timeLine = void 0;
  }
  var _proto = GanttChart.prototype;
  // 初始化
  _proto.init = function init(container) {
    this.container = container;
  }
  // 设置图表的配置项
;
  _proto.setOption = function setOption(option) {
    if (this.container) {
      appendNode(this.container, '');
    }
    this.option = option;
    // 图表内容区的像素宽度
    this.chartWidth = this.container.offsetWidth - 108 - 28;
    // 图表内容区的像素高度
    this.chartHeight = this.container.offsetHeight - 56;
    this.render();
  };
  _proto.render = function render() {
    var wrapper = createEl('div');
    className(wrapper, 'ev_GanttChart_wrapper');
    appendEL(this.container, wrapper);
    this.timeLine = new TimeLine(wrapper, this.option, this.chartWidth, this.chartHeight);
    this.timeLine.init();
  };
  return GanttChart;
}();
_defineProperty(GanttChart, "name", CHART_TYPE.GANTT);
export { GanttChart as default };
