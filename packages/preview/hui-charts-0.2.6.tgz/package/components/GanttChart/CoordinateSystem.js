import { createEl, addClass, appendEL, appendNode, appendText, setStyle, innerTooltip, handlePercent, handleLeft, handleFillColor, getChartPostLabel } from './util.js';
import { BAR_HEIGHT, BORDER_RADIUS, SPACE } from './constant.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var CoordinateSystem = /*#__PURE__*/function () {
  function CoordinateSystem(wrapper, option, canvasWidth, canvasHeight) {
    var _this = this;
    this.wrapper = null;
    this.option = {};
    this.canvas = null;
    // 是否鼠标移动
    this.isMove = false;
    // 内部canva画笔对象
    this.canvasCtx = null;
    // 提示框是否显示
    this.isShow = false;
    this.lineSpace = 0;
    // 用来保存canvas y轴坐标
    this.cavasRowCoordinates = [];
    // 移动时的坐标
    this.mousePosition = {
      x: 0,
      y: 0
    };
    //   提示框
    this.tip = void 0;
    //    提示框内容区
    this.tipContent = void 0;
    //   两个手柄之间的差值;
    this.currentTotalTime = 0;
    //   手柄选中的时间范围
    this.timeScope = 0;
    this.canvasMove = function (e) {
      _this.isMove = true;
      _this.mousePosition.x = e.offsetX;
      _this.mousePosition.y = e.offsetY;
      _this.resetCanvas(_this.currentTotalTime, _this.timeScope);
    };
    this.canvasLeave = function () {
      _this.isMove = false;
      setStyle(_this.tip, 'visibility', 'hidden');
      setStyle(_this.tip, 'opacity', 0);
      setStyle(_this.canvas, 'cursor', 'default');
    };
    this.tipMouseLeave = function () {
      setStyle(_this.tip, 'visibility', 'hidden');
      setStyle(_this.tip, 'opacity', 0);
      setStyle(_this.canvas, 'cursor', 'default');
    };
    this.wrapper = wrapper;
    this.option = option;
    this.canvasWidth = canvasWidth;
    this.canvasHeight = canvasHeight;
  }

  /**
   *
   * @param {string} className 类名名称
   */
  var _proto = CoordinateSystem.prototype;
  _proto.createDom = function createDom(className, domName) {
    var node = createEl(domName || 'div');
    addClass(node, className);
    return node;
  };
  _proto.addClassName = function addClassName(node, className) {
    addClass(node, className);
  };
  _proto.addDom = function addDom(container, node) {
    appendEL(container, node);
  };
  _proto.clearDom = function clearDom(node) {
    appendNode(node, '');
  };
  _proto.addText = function addText(node, text) {
    appendText(node, text);
  };
  _proto.renderCoordinatesAxis = function renderCoordinatesAxis(body) {
    var _this2 = this;
    var axisWrapper = this.createDom('ev_GanttChart_axisWrapper');
    this.addDom(body, axisWrapper);
    var axis = this.createDom('ev_GanttChart_axis', 'ul');
    this.addDom(axisWrapper, axis);
    // 生成坐标轴子项
    if (this.option && this.option.data) {
      this.option.data.forEach(function (dataItem) {
        var axisItem = _this2.createDom('ev_GanttChart_axisItem', 'li');
        _this2.addText(axisItem, dataItem.name);
        _this2.addDom(axis, axisItem);
      });
    }
  };
  _proto.renderChartItem = function renderChartItem(chartItemWrapper) {
    var _this3 = this;
    this.option.data.forEach(function () {
      // 图表的数据子项
      var chartItem = _this3.createDom('ev_GanttChart_chartItem');

      // 牵引线设置
      var tractionLineWrapper = _this3.createDom('ev_GanttChart_tractionLineWrapper');
      // 牵引点
      var towingPoint = _this3.createDom('ev_GanttChart_towingPoint');
      // 牵引线
      var tractionLine = _this3.createDom('ev_GanttChart_tractionLine');
      _this3.addDom(tractionLineWrapper, towingPoint);
      _this3.addDom(tractionLineWrapper, tractionLine);
      // 图表的柱子
      var chartPostWrapper = _this3.createDom('ev_GanttChart_chartPostWrapper');
      _this3.addDom(chartItem, chartPostWrapper);
      _this3.addDom(chartItem, tractionLineWrapper);
      _this3.addDom(chartItemWrapper, chartItem);
    });
  }

  // 生成图表的主体
;
  _proto.renderBody = function renderBody(chartItemWrapper) {
    if (this.option && this.option.data) {
      this.renderChartItem(chartItemWrapper);
    }
  };
  _proto.getLineSpace = function getLineSpace() {
    var lineSpace;
    if (this.option.data.length < 2) {
      lineSpace = 0;
    } else {
      var isOverHigh = this.canvasHeight - 28 * this.option.data.length <= 0;
      lineSpace = (isOverHigh ? 0 : this.canvasHeight - 28 * this.option.data.length) / (this.option.data.length - 1);
    }
    return lineSpace;
  }

  // 绘制圆角矩形
;
  _proto.drawRoundRect = function drawRoundRect(x, y, width, height, radius) {
    this.canvasCtx.beginPath();
    this.canvasCtx.arc(x + radius, y + radius, radius, Math.PI, Math.PI * 3 / 2);
    this.canvasCtx.lineTo(width - radius + x, y);
    this.canvasCtx.arc(width - radius + x, radius + y, radius, Math.PI * 3 / 2, Math.PI * 2);
    this.canvasCtx.lineTo(width + x, height + y - radius);
    this.canvasCtx.arc(width - radius + x, height - radius + y, radius, 0, Math.PI * 1 / 2);
    this.canvasCtx.lineTo(radius + x, height + y);
    this.canvasCtx.arc(radius + x, height - radius + y, radius, Math.PI * 1 / 2, Math.PI);
  };
  _proto.renderRowItemPoint = function renderRowItemPoint(rowItemWidth, postItem, xCoordinates, yCoordinates) {
    if (rowItemWidth > 8 + 4 + 8) {
      this.canvasCtx.beginPath();
      this.canvasCtx.arc(xCoordinates + 10, yCoordinates + 10, 2, 0, Math.PI * 2);
      var color;
      // 设置牵引点的颜色
      switch (postItem.status) {
        case 'during':
          color = '#DBDFF2';
          break;
        case 'success':
          color = '#AFEDCE';
          break;
        case 'stop':
          color = '#E4E4E4';
          break;
        case 'waiting':
          color = '#FCDBAA';
          break;
        default:
          color = '#F3DADA';
          break;
      }
      this.canvasCtx.fillStyle = color;
      this.canvasCtx.fill();
    }
  };
  _proto.renderRowItemLabel = function renderRowItemLabel(differenceTime, rowItemWidth, xCoordinates, yCoordinates) {
    var label = getChartPostLabel(differenceTime);
    var labelWidth = Math.round(this.canvasCtx.measureText(label).width + 8);
    if (rowItemWidth - (8 + 4 + 8) >= labelWidth) {
      this.canvasCtx.fillStyle = '#FFF';
      this.canvasCtx.fillText(label, xCoordinates + (rowItemWidth - labelWidth), yCoordinates + 14);
    }
  };
  _proto.setTipContent = function setTipContent(node, dataIndex, postIndex) {
    if (this.option.tipHtml) {
      appendNode(node, this.option.tipHtml(this.option.data, dataIndex, postIndex));
    } else {
      appendNode(node, innerTooltip(this.option.data, dataIndex, postIndex));
    }
  };
  _proto.renderRowItem = function renderRowItem(yCoordinates, postItem, postIndex, dataIndex, currentTotalTime, timeScope) {
    // 开始时间
    var startTime = new Date(postItem.startTime).getTime();
    // 结束时间
    var endTime = new Date(postItem.endTime).getTime();
    // 当前数据项的起止时间毫秒数
    var postItemTime = {
      startTime: startTime,
      endTime: endTime
    };
    var differenceTime = endTime - startTime;
    var currentTime = new Date(this.option.currentTime).getTime();
    // 确定占比
    var percent = handlePercent(postItemTime, currentTime, currentTotalTime, timeScope);
    // 占比为0直接不用执行
    if (percent === 0) return;
    var chartPostWidth = this.canvasWidth * percent;
    // 处理宽度四舍五入为0的情况
    var rowItemWidth = Math.round(chartPostWidth) === 0 ? 1 : Math.round(chartPostWidth);
    var left = handleLeft(postItemTime, currentTime, currentTotalTime, timeScope);
    var xCoordinates = Math.round(left * this.canvasWidth);
    // 处理宽度过小圆角不显示
    var borderRadius = rowItemWidth < 4 ? 0 : BORDER_RADIUS;
    this.drawRoundRect(xCoordinates, yCoordinates, rowItemWidth, BAR_HEIGHT, borderRadius);
    // 填充颜色
    this.canvasCtx.fillStyle = handleFillColor(postItem);
    this.canvasCtx.fill();
    // 判断鼠标位移的时候是否在元素上面
    if (this.isMove) {
      if (this.canvasCtx.isPointInPath(this.mousePosition.x, this.mousePosition.y)) {
        this.isShow = true;
        if (this.isShow) {
          this.setTipContent(this.tipContent, dataIndex, postIndex);
          setStyle(this.tip, 'visibility', 'visible');
          setStyle(this.tip, 'opacity', 1);
          setStyle(this.canvas, 'cursor', 'pointer');
          var top = dataIndex * (this.lineSpace + 28) + 16 + 40;
          var transform = "translate3d(" + (this.mousePosition.x + 2) + "px, " + (this.mousePosition.y - top) + "px, 0px)";
          setStyle(this.tip, 'transform', transform);
        }
      } else {
        if (!this.isShow) {
          setStyle(this.tip, 'visibility', 'hidden');
          setStyle(this.tip, 'opacity', 0);
          setStyle(this.canvas, 'cursor', 'default');
        }
      }
    }
    // 绘制牵引点
    this.renderRowItemPoint(rowItemWidth, postItem, xCoordinates, yCoordinates);
    this.renderRowItemLabel(differenceTime, rowItemWidth, xCoordinates, yCoordinates);
  };
  _proto.renderChartRow = function renderChartRow(dataItem, dataIndex, yCoordinates, currentTotalTime, timeScope) {
    var _this4 = this;
    dataItem.data.forEach(function (postItem, postIndex) {
      // 绘制每行的单项数据
      _this4.renderRowItem(yCoordinates, postItem, postIndex, dataIndex, currentTotalTime, timeScope);
    });
  };
  _proto.resetCanvas = function resetCanvas(currentTotalTime, timeScope) {
    var _this5 = this;
    if (currentTotalTime) {
      this.currentTotalTime = currentTotalTime;
    }
    if (timeScope) {
      this.timeScope = timeScope;
    }
    if (this.option.data && this.option.data.length === 0) return;
    // 清空画布
    this.canvasCtx.clearRect(0, 0, this.canvasWidth, this.canvasHeight);
    // 绘制每行数据
    this.option.data.forEach(function (item, index) {
      _this5.renderChartRow(item, index, _this5.cavasRowCoordinates[index].yStart, currentTotalTime, timeScope);
    });
    // 用来重置鼠标移动tooltip出现后的判定条件
    this.isShow = false;
  };
  _proto.paintCanvas = function paintCanvas() {
    var _this6 = this;
    if (this.option.data) {
      var lineSpace = this.getLineSpace();
      this.lineSpace = lineSpace;
      // 计算每行的y轴坐标范围
      this.option.data.forEach(function (item, index) {
        var yRow = {
          yStart: SPACE * (2 * index + 1) + index * (BAR_HEIGHT + lineSpace)
        };
        _this6.cavasRowCoordinates.push(yRow);
      });

      // 重新绘制cancas
      this.resetCanvas();
    }
  };
  _proto.init = function init() {
    var body = this.createDom('ev_GanttChart_body');
    this.addDom(this.wrapper, body);
    // 生成坐标轴
    this.renderCoordinatesAxis(body);
    //  右边的图表
    var chartWrapper = this.createDom('ev_GanttChart_chartWrapper');
    this.addDom(body, chartWrapper);
    // 图表的子项数据
    var chartItemWrapper = this.createDom('ev_GanttChart_chartItemWrapper');
    this.addDom(chartWrapper, chartItemWrapper);
    this.renderBody(chartItemWrapper);
    // // 生成canvas
    var cavas = this.createDom('ev_GanttChart_canvas', 'canvas');
    this.canvas = cavas;
    cavas.onmousemove = this.canvasMove;
    cavas.onmouseleave = this.canvasLeave;
    cavas.id = 'ev_GanttChart_cavs';
    // // 设置画布像素宽高
    cavas.width = this.canvasWidth;
    cavas.height = this.canvasHeight;
    this.addDom(chartWrapper, cavas);
    var ctx = cavas.getContext('2d');
    this.canvasCtx = ctx;
    // 处理绘制
    this.paintCanvas();
    // // 生成底部的tooltip

    var tooltip = this.createDom('ev_GanttChart_tooltipContainer');
    this.addDom(chartWrapper, tooltip);
    this.tip = tooltip;
    var toolTipContent = this.createDom('ev_GanttChart_toolTipContent');
    this.addDom(tooltip, toolTipContent);
    this.tipContent = toolTipContent;
    this.tip.onmouseleave = this.tipMouseLeave;
  };
  return CoordinateSystem;
}();
export { CoordinateSystem as default };
