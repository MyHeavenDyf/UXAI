import { appendHTML } from '../../util/dom.js';
import { insertIcon } from './insertIcon.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

function initContainer(dom, option) {
  var container = "\n    <div class=\"mc-container " + option.layout + " " + option.alignment + "\" id=\"mc-container\">\n        <div class=\"mc-content\">\n            <div class=\"mc-current\">\n                <div class=\"mc-current-text\"></div>\n            </div>\n            <div class=\"mc-scales\"></div>\n        </div>\n        <div class=\"mc-btn mc-btn-prev\">\n            <img src='" + insertIcon('prev') + "'>\n        </div>\n        <div class=\"mc-btn mc-btn-next\">\n            <img src='" + insertIcon('next') + "'>\n        </div>\n    </div>";
  appendHTML(dom, container);
}
export { initContainer };
