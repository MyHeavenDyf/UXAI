import { isArray } from '../../util/type.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

function handleSeries(baseOpt, iChartOpt) {
  var series = [];
  var data = iChartOpt.data;
  var color = iChartOpt.color;
  var roam = iChartOpt.roam;
  var padding = iChartOpt.padding;
  var optionLabel = iChartOpt.label || {};
  var label = Object.assign({
    fontFamily: 'HarmonyHeiTi',
    fontSize: '14px',
    align: 'center',
    formatter: '{b}',
    fontStyle: 'normal'
  }, optionLabel);
  baseOpt.color = color;
  if (data && isArray(data)) {
    var seriesItem = {
      data: data,
      type: 'treemap',
      name: 'data',
      roam: roam || false,
      nodeClick: roam ? 'zoomToNode' : false,
      breadcrumb: {
        show: false
      },
      top: padding[0],
      right: padding[1],
      bottom: padding[2],
      left: padding[3],
      label: label,
      itemStyle: {
        borderRadius: 4,
        gapWidth: 1,
        borderColor: 'transparent'
      },
      levels: [{
        color: color
      }]
    };
    series.push(seriesItem);
  }
  baseOpt.series = series;
}
export { handleSeries };
