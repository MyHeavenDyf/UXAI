function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import merge, { mergeSeries } from '../../util/merge.js';
import LineChart from '../LineChart/index.js';
import BarChart from '../BarChart/index.js';
import init from '../../option/init/index.js';
import cloneDeep from '../../util/cloneDeep.js';
import base from '../../option/base/index.js';
import updateWidth from './barChartOption.js';
import RectCoordSys from '../../option/RectSys/index.js';
import { CHART_TYPE, ADAPTIVE_THEME } from '../../util/constants.js';
import Token from '../../feature/token/index.js';
import xkey from '../../option/config/xAxis/xkey.js';
import xdata from '../../option/config/xAxis/xdata.js';
import ldata from '../../option/config/legend/ldata.js';
import ydata from '../../option/config/yAxis/ydata.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var BarLineChart = /*#__PURE__*/function () {
  function BarLineChart(iChartOption, chartInstance) {
    this.baseOption = {};
    this.baseOption = cloneDeep(base);
    this.chartInstance = chartInstance;
    // 组装 iChartOption, 补全默认值
    this.iChartOption = init(iChartOption);
    // 根据 iChartOption 组装 baseOption
    this.updateOption();
  }
  var _proto = BarLineChart.prototype;
  _proto.updateOption = function updateOption() {
    var iChartOption = this.iChartOption;
    // 装载除series之外的其他配置
    RectCoordSys(this.baseOption, this.iChartOption, CHART_TYPE.BAR, this.chartInstance);
    // x轴key值
    var xAxisKey = xkey(iChartOption);
    // x轴数据
    var xAxisData = xdata(iChartOption.data, xAxisKey);
    // 图例数据
    var legendData = ldata(iChartOption.data, xAxisKey);
    // 连线的数据
    ydata(iChartOption.data, legendData);
    // 赋值数据
    this.baseOption.legend.data = iChartOption.legend.data || legendData;
    this.baseOption.xAxis.forEach(function (item) {
      item.data = xAxisData;
    });
    // 合并用户自定义series
    mergeSeries(iChartOption, this.baseOption);
  }

  // 根据渲染出的结果，二次计算option
;
  _proto.updateOptionAgain = function updateOptionAgain() {
    var _baseOption$dataZoom, _baseOption$dataZoom$, _this$iChartOption$it;
    var baseOption = this.baseOption;
    var iChartOption = this.iChartOption;
    var lineOption = iChartOption.lineOption;
    var barOption = iChartOption.barOption;
    var lineDataName = lineOption.dataName;
    var barDataName = barOption.dataName;
    var series = [];

    // 折线图数据
    if (lineDataName && lineDataName.length > 0) {
      var newLineOption = merge(iChartOption, lineOption);
      var lineChartBaseOpt = new LineChart(newLineOption, {}, this.chartInstance);
      var lineBaseOption = lineChartBaseOpt.getOption();
      var lineSeries = lineBaseOption.series;
      var num = 0;
      var lineColor = lineOption.lineColor;
      var baseColor = Token.config.colorState.colorSuccess;
      lineDataName.forEach(function (lineName) {
        for (var i = 0; i < lineSeries.length; i++) {
          if (lineSeries[i].name === lineName) {
            series.push(lineSeries[i]);
            if (lineColor) {
              var color = lineColor[num] ? lineColor[num] : lineColor[0];
              lineSeries[i].color = color;
            } else {
              lineSeries[i].color = baseColor;
            }
            num++;
          }
        }
      });
    }
    // 柱状图数据
    if (barDataName && lineDataName.length > 0) {
      var newBarOption = merge(iChartOption, barOption);
      var barChartBaseOpt = new BarChart(newBarOption, {}, this.chartInstance);
      var barBaseOption = barChartBaseOpt.getOption();
      var barSeries = barBaseOption.series;
      barDataName.forEach(function (lineName) {
        for (var i = 0; i < barSeries.length; i++) {
          if (barSeries[i].name === lineName) {
            series.push(barSeries[i]);
          }
        }
      });
    }
    baseOption.series = series;

    // 如果用户自定义了 barWidth 或 存在 dataZoom，则不主动刷新柱宽
    if (!((_baseOption$dataZoom = baseOption.dataZoom) != null && (_baseOption$dataZoom$ = _baseOption$dataZoom[0]) != null && _baseOption$dataZoom$.show) && !((_this$iChartOption$it = this.iChartOption.itemStyle) != null && _this$iChartOption$it.barWidth) && ADAPTIVE_THEME.includes(this.iChartOption.theme)) {
      updateWidth(baseOption, this.chartInstance, this.iChartOption);
    }
  };
  _proto.getOption = function getOption() {
    return this.baseOption;
  };
  _proto.setOption = function setOption() {}

  // 自适应柱条宽度
;
  _proto.resize = function resize(callback) {
    var _this$baseOption$data, _this$baseOption$data2, _this$iChartOption$it2;
    // 如果用户自定义了 barWidth 或 存在 dataZoom，则不主动刷新柱宽
    if (!((_this$baseOption$data = this.baseOption.dataZoom) != null && (_this$baseOption$data2 = _this$baseOption$data[0]) != null && _this$baseOption$data2.show) && !((_this$iChartOption$it2 = this.iChartOption.itemStyle) != null && _this$iChartOption$it2.barWidth) && ADAPTIVE_THEME.includes(this.iChartOption.theme)) {
      updateWidth(this.baseOption, this.chartInstance, this.iChartOption);
      callback && callback(this.baseOption, {
        notMerge: false
      });
    }
  };
  return BarLineChart;
}();
_defineProperty(BarLineChart, "name", CHART_TYPE.BARLINE);
export { BarLineChart as default };
