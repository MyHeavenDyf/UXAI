import { getColor } from '../../util/color.js';
import chartToken from './chartToken.js';
import handleMarkPoint from './handleMarkPoint.js';
import { isObject } from '../../util/type.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

function handleSeries(baseOpt, iChartOpt) {
  var series = [];
  var errorSeries = handleMarkPoint(iChartOpt);
  var data = iChartOpt.data;
  // 设置iChartOpt中未超过markPoint点的数据
  data && isObject(data) && Object.keys(data).forEach(function (item) {
    var seriesItem = {
      name: item,
      symbolSize: iChartOpt.symbolSize || chartToken.symbolSize,
      data: data[item],
      type: 'scatter',
      emphasis: {
        itemStyle: {
          color: chartToken.color,
          borderWidth: chartToken.symbolBorderWidth
        },
        focus: 'series',
        scale: 1.3
      },
      itemStyle: {
        color: function color(param) {
          return getColor(iChartOpt.color, param.seriesIndex);
        },
        borderColor: function borderColor() {},
        borderWidth: 0
      }
    };
    series.push(seriesItem);
  });
  series.push.apply(series, errorSeries);
  baseOpt.series = series;
}
export { handleSeries };
