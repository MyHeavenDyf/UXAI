import xAxis from '../../option/config/xAxis/index.js';
import yAxis from '../../option/config/yAxis/index.js';
import grid from '../../option/config/grid/index.js';
import tooltip from '../../option/config/tooltip/index.js';
import defendXSS from '../../util/defendXSS.js';
import { CHART_TYPE } from '../../util/constants.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

/**
 * Tips提示框回调函数
 */
function toolTipFormatter(params) {
  var data = params.data;
  var x = data[0],
    y = data[1],
    name = data[2];
  var htmlStrings = "<div style=\"margin-bottom:4px;\">\n  \u540D\u79F0" + (name || '') + "\n                            </div>";
  htmlStrings += "\n                            <div>\n                                <span style=\"display:inline-block;margin-right:8px;min-width:60px;\">x\u7EF4\u5EA6</span>\n                                <span>" + defendXSS(x) + "</span>\n                            </div>";
  htmlStrings += "\n                            <div>\n                                <span style=\"display:inline-block;margin-right:8px;min-width:60px;\">y\u7EF4\u5EA6</span>\n                                <span>" + defendXSS(y) + "</span>\n                            </div>";
  return htmlStrings;
}
function handleXaxis(baseOpt, iChartOpt) {
  var basicXaxis = xAxis(iChartOpt);
  basicXaxis[0].type = 'value';
  baseOpt.xAxis = basicXaxis;
}
function handleYaxis(baseOpt, iChartOpt) {
  var basicYaxis = yAxis(baseOpt, iChartOpt, CHART_TYPE.SCATTER);
  baseOpt.yAxis = basicYaxis;
}
function handleTooltip(baseOpts, iChartOpt) {
  var _iChartOpt$tooltip;
  var basicTooltip = tooltip(iChartOpt, CHART_TYPE.SCATTER);
  if (!iChartOpt.tipHtml && !(iChartOpt != null && (_iChartOpt$tooltip = iChartOpt.tooltip) != null && _iChartOpt$tooltip.formatter)) {
    basicTooltip.formatter = toolTipFormatter;
  }
  basicTooltip.trigger = 'item';
  baseOpts.tooltip = basicTooltip;
}
function handleGrid(baseOpt, iChartOpt) {
  var basicGrid = grid(iChartOpt);
  baseOpt.grid = basicGrid;
}
export { handleGrid, handleTooltip, handleXaxis, handleYaxis };
