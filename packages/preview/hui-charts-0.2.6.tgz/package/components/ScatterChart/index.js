function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import { handleSeries } from './handleSeries.js';
import { handleXaxis, handleYaxis, handleGrid, handleTooltip } from './handleOptipn.js';
import init from '../../option/init/index.js';
import RectCoordSys from '../../option/RectSys/index.js';
import { CHART_TYPE } from '../../util/constants.js';
import { mergeSeries } from '../../util/merge.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var ScatterChart = /*#__PURE__*/function () {
  function ScatterChart(iChartOption, chartInstance) {
    this.baseOption = {};
    this.iChartOption = {};
    this.iChartOption = init(iChartOption);
    this.chartInstance = chartInstance;
    // 根据 iChartOption 组装 baseOption
    this.updateOption();
  }
  var _proto = ScatterChart.prototype;
  _proto.updateOption = function updateOption() {
    var iChartOption = this.iChartOption;
    // 图表数据
    var data = [];
    Object.keys(iChartOption.data).forEach(function (v) {
      data.push.apply(data, iChartOption.data[v]);
    });
    if (!data.length) return;
    // 图例数据
    RectCoordSys(this.baseOption, iChartOption, CHART_TYPE.SCATTER, this.chartInstance);
    // 图表x轴
    handleXaxis(this.baseOption, iChartOption);
    // 图表y轴
    handleYaxis(this.baseOption, iChartOption);
    // 设置chartpadding
    handleGrid(this.baseOption, iChartOption);
    //  图表鼠标悬浮提示框
    handleTooltip(this.baseOption, iChartOption);
    // 图表的series
    handleSeries(this.baseOption, iChartOption);
    // 合并用户自定义series
    mergeSeries(iChartOption, this.baseOption);
  };
  _proto.getOption = function getOption() {
    return this.baseOption;
  };
  _proto.setOption = function setOption() {};
  return ScatterChart;
}();
_defineProperty(ScatterChart, "name", CHART_TYPE.SCATTER);
export { ScatterChart as default };
