function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import init from '../../option/init/index.js';
import setSeries from './handleSeries.js';
import { setDirection, setTooltip } from './handleOption.js';
import RectCoordSys from '../../option/RectSys/index.js';
import { CHART_TYPE } from '../../util/constants.js';
import { mergeSeries } from '../../util/merge.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var BoxplotChart = /*#__PURE__*/function () {
  function BoxplotChart(iChartOption) {
    this.baseOption = {};
    this.iChartOption = {};
    this.iChartOption = init(iChartOption);
    this.updateOption();
  }
  var _proto = BoxplotChart.prototype;
  _proto.updateOption = function updateOption() {
    var iChartOption = this.iChartOption;
    // 装载除series之外的其他配置
    RectCoordSys(this.baseOption, this.iChartOption, CHART_TYPE.BOXPLOT);
    // 箱形图data必须设为undefined
    this.baseOption.xAxis[0].data = undefined;
    // 提示框trigger设为item
    this.baseOption.tooltip.trigger = 'item';
    setSeries(this.baseOption, iChartOption);
    // 横向
    setDirection(this.baseOption, iChartOption.direction);
    // 提示框
    setTooltip(this.baseOption);
    // 合并用户自定义series
    mergeSeries(iChartOption, this.baseOption);
  };
  _proto.getOption = function getOption() {
    return this.baseOption;
  };
  return BoxplotChart;
}();
_defineProperty(BoxplotChart, "name", CHART_TYPE.BOXPLOT);
export { BoxplotChart as default };
