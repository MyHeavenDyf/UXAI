import merge from '../../util/merge.js';
import { getEdge, getAngle } from '../../util/math.js';
import defendXSS from '../../util/defendXSS.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var INIT_RADIUS = {
  min: 200,
  gap: 200,
  angle: 30,
  direction: 'bottom'
};
var DIRECTION_ANGLE = {
  top: 180,
  left: -90,
  right: 90,
  bottom: 0
};
var LINE_STYLE = {
  color: '#BBBBBB'
};
var NodeManager = /*#__PURE__*/function () {
  function NodeManager(dom, option, selected) {
    // 圆环容器
    this.dom = void 0;
    // 数据
    this.data = void 0;
    // 圆环细节 
    this.radius = void 0;
    // 每层选中index
    this.selected = void 0;
    // 每层旋转角度
    this.angles = void 0;
    this.dom = dom;
    this.selected = selected;
    this.data = option.data;
    this.radius = merge(INIT_RADIUS, option.radius);
    this.render = option.render;
    this.autoRotate = option.autoRotate;
    this.lineStyle = merge(LINE_STYLE, option.lineStyle);
    this.angles = [];
    // 余弦定理算出第一层圆圈中两个点之间的直线距离
    this.distance = getEdge(this.radius.min, this.radius.min, this.radius.angle);
    this.createWarppers();
    this.createInitNodes();
  }

  // 创建层级圆环
  var _proto = NodeManager.prototype;
  _proto.createWarppers = function createWarppers() {
    var _this = this;
    // 最顶层的圆环的位置
    this.depth = this.getDataDepth(this.data, 0);
    for (var index = 0; index < this.depth; index++) {
      var _this$autoRotate;
      var radius = this.radius.min + this.radius.gap * index;
      var width = defendXSS(radius * 2);
      var zindex = defendXSS(100 - index);
      var inertia = (_this$autoRotate = this.autoRotate) == null ? void 0 : _this$autoRotate.inertia;
      // 圆环
      var warpper = "<div class=\"ozc_warpper " + (inertia === false ? 'ozc_no_inertia' : '') + "\" style='width: " + width + "px;height: " + width + "px;z-index: " + zindex + "; transform: translateX(-50%) translateY(-50%) rotate(0deg);'></div>";
      this.dom.insertAdjacentHTML('beforeend', warpper);
    }
    this.warppers = this.dom.getElementsByClassName('ozc_warpper');
    Array.from(this.warppers).forEach(function (element) {
      element.style.setProperty('--lineColor', _this.lineStyle.color);
    });
  }

  // 创建初始节点和布局
;
  _proto.createInitNodes = function createInitNodes() {
    this.createBoss();
    var data = [this.data];
    for (var level = 0; level < this.depth; level++) {
      var _data$preSelect;
      var preSelect = this.selected[level - 1] || 0;
      var nextSelect = this.selected[level] || 0;
      data = ((_data$preSelect = data[preSelect]) == null ? void 0 : _data$preSelect.children) || [];
      this.createLevel(data, nextSelect, level);
    }
  }

  // 绘制最顶层管理者 
;
  _proto.createBoss = function createBoss() {
    var boss = this.createNode(this.data, 'left: 50%;top: 50%;transform: translateX(-50%) translateY(-50%);');
    this.dom.appendChild(boss);
  }

  /**
   * 绘制每层员工dom
   * @param {整层数据} data 
   * @param {选中dom下标} index 
   * @param {圆环容器} warpper 
   */;
  _proto.createLevel = function createLevel(data, selectedIndex, warpperIndex) {
    var _this2 = this;
    var warpper = this.warppers[warpperIndex];
    if (!data || data.length == 0) {
      return;
    } else {
      warpper.style.display = 'block';
    }
    var radius = this.radius.min + warpperIndex * this.radius.gap;
    var distance = this.distance + warpperIndex * 10;
    var angleUnit = getAngle(radius, radius, distance)[2];
    var initAngle = selectedIndex * angleUnit * -1 + DIRECTION_ANGLE[this.radius.direction];
    this.angles[warpperIndex] = angleUnit;
    data.forEach(function (user, i) {
      var center = {
        x: radius,
        y: radius
      };
      var angle = initAngle + angleUnit * i;
      var left = center.x + radius * Math.sin(Math.PI * angle / 180);
      var top = center.y + radius * Math.cos(Math.PI * angle / 180);
      var style = "left: " + left + "px;top: " + top + "px;";
      var node = _this2.createNode(user, style, warpperIndex, i);
      warpper.appendChild(node);
    });
  }

  // 刷新数据和DOM
;
  _proto.refreshWarpper = function refreshWarpper(warpperIndex, selected) {
    this.selected = selected;
    for (var level = warpperIndex + 1; level < this.depth; level++) {
      this.warppers[level].style.transform = 'translateX(-50%) translateY(-50%) rotate(0deg)';
      this.warppers[level].innerHTML = '';
      var depthData = this.getDepthData(this.data, level);
      var nextSelect = this.selected[level] || 0;
      this.createLevel(depthData, nextSelect, level);
    }
  };
  _proto.createNode = function createNode(data, style, warpperIndex, nodeIndex) {
    var _this$autoRotate2;
    var node = document.createElement('div');
    node.setAttribute('style', style);
    var inertia = (_this$autoRotate2 = this.autoRotate) == null ? void 0 : _this$autoRotate2.inertia;
    var nodeClass = inertia === false ? 'ozc_card ozc_no_inertia' : 'ozc_card';
    node.setAttribute('class', nodeClass);
    node.setAttribute('data-node-index', nodeIndex);
    node.setAttribute('data-warpper-index', warpperIndex);
    var state = {
      boss: warpperIndex == undefined,
      selected: this.selected[warpperIndex] === nodeIndex ? true : false
    };
    this.render && this.render(node, data, state);
    return node;
  }

  // 获得指定层级的数据
;
  _proto.getDepthData = function getDepthData(data, targetDepth) {
    var result = [data];
    for (var level = 0; level < this.depth; level++) {
      var _result$preSelect;
      var preSelect = this.selected[level - 1] || 0;
      result = ((_result$preSelect = result[preSelect]) == null ? void 0 : _result$preSelect.children) || [];
      if (level === targetDepth) {
        break;
      }
    }
    return result;
  }

  // 根据数据计算出层级深度
;
  _proto.getDataDepth = function getDataDepth(data, depth) {
    var _this3 = this;
    if (data && data.children && data.children.length > 0) {
      depth++;
      var childDepths = data.children.map(function (child) {
        return _this3.getDataDepth(child, depth);
      });
      depth = Math.max.apply(Math, childDepths);
    }
    return depth;
  };
  return NodeManager;
}();
export { INIT_RADIUS, NodeManager as default };
