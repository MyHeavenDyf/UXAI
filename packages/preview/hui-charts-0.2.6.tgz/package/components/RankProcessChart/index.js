function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function _inheritsLoose(t, o) { t.prototype = Object.create(o.prototype), t.prototype.constructor = t, _setPrototypeOf(t, o); }
function _setPrototypeOf(t, e) { return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) { return t.__proto__ = e, t; }, _setPrototypeOf(t, e); }
import BaseChart from '../BaseChart/index.js';
import { createSvgElement, updateSvgs, getColorsFromToken } from './utils.js';
import { createTooltip } from './handleTooltip.js';
import { renderHeader } from './handleHeader.js';
import { createRowList } from './handleRowList.js';
import { createScrollArea } from './handleScroll.js';
import { getMainChartStyles } from './style.js';
import { isArray } from '../../util/type.js';
import debounce from '../../util/debounce.js';
import { resolveOption, isUpdate } from './handleOption.js';
import { DEFAULT_OPTION, DEFAULT_SCROLL_INFO, HEADER } from './constants.js';
import cloneDeep from '../../util/cloneDeep.js';
import chartToken from './chartToken.js';
var RankProcessChart = /*#__PURE__*/function (_BaseChart) {
  function RankProcessChart() {
    var _this;
    _this = _BaseChart.call(this) || this;
    _this.dom = null; // 图表容器
    _this.option = _extends({}, DEFAULT_OPTION); // 本次的配置选项
    _this.lastOption = _extends({}, DEFAULT_OPTION); // 上次的配置选项
    _this.renderCallBack = null; // 渲染完成回调函数
    return _this;
  }

  // 初始化图表容器
  _inheritsLoose(RankProcessChart, _BaseChart);
  var _proto = RankProcessChart.prototype;
  _proto.init = function init(dom) {
    this.dom = dom;
    this.width = dom.clientWidth || 0;
    this.height = dom.clientHeight || 0;

    // 获取样式配置
    this.styles = getMainChartStyles(chartToken);
    if (this.svg) {
      this.dom.appendChild(this.svg);
      return;
    }

    // 创建根SVG元素
    this.svg = createSvgElement('svg', this.styles.getSvgStyles(), this.dom);
  }

  // 合并配置选项
;
  _proto.setSimpleOption = function setSimpleOption(name, option) {
    if (!option || typeof option !== 'object') option = DEFAULT_OPTION;

    // 把合并的逻辑放在handleOption中
    this.resolvedOption = resolveOption(this.option, option, this.width, this.height);
  }

  // 图表渲染
;
  _proto.render = function render() {
    var _this2 = this;
    if (this.shouldSkipRender()) {
      this.update();
      return;
    }
    var _this$resolvedOption = this.resolvedOption,
      titleName = _this$resolvedOption.titleName,
      valueName = _this$resolvedOption.valueName,
      percentName = _this$resolvedOption.percentName,
      data = _this$resolvedOption.data,
      tooltip = _this$resolvedOption.tooltip,
      color = _this$resolvedOption.color,
      paddingConfig = _this$resolvedOption.paddingConfig,
      contentWidth = _this$resolvedOption.contentWidth,
      contentHeight = _this$resolvedOption.contentHeight;

    // 挂载tooltip
    this.tooltip = createTooltip(this.svg, this.resolvedOption.theme, tooltip);
    this.contentGroup = createSvgElement('svg', this.styles.getContentGroupStyles(paddingConfig.left, paddingConfig.top, contentWidth, contentHeight), this.svg);
    this.clipPath = createSvgElement('clipPath', this.styles.getClipPath(), this.svg);
    this.clipRect = createSvgElement('rect', this.styles.getClipRect(contentWidth, contentHeight), this.clipPath);
    this.contentGroup.setAttribute('clip-path', 'url(#contentClipPath)');

    // 创建虚拟列表
    this.rowList = createRowList({
      data: data,
      colorArray: color,
      containerWidth: contentWidth,
      scrollCallback: function scrollCallback() {
        return {
          // 闭包获取scrollArea中的属性，需要时调用回调获取
          scrollY: _this2.scrollArea ? _this2.scrollArea.scrollY : DEFAULT_SCROLL_INFO.SCROLLY,
          // 当前滚动位置
          viewHeight: contentHeight - HEADER.HEIGHT // 可视区域高度
        };
      }
    });

    // 创建滚动区域
    this.scrollArea = createScrollArea(this.svg, this.contentGroup, this.rowList, contentWidth, contentHeight, paddingConfig);

    // 渲染首部
    this.headerGroup = renderHeader(this.contentGroup, contentWidth, titleName, valueName, percentName);
    this.svg.appendChild(this.contentGroup);

    // 监听页面变化
    this.setResize();
    this.renderCallBack ? this.renderCallBack() : '';

    // 更新渲染缓存
    this.updateRenderCache();
  };
  _proto.shouldSkipRender = function shouldSkipRender() {
    // 如果所有组件已经渲染，则可以跳过渲染，走更新流程
    if (this.contentGroup && this.rowList && this.scrollArea && this.headerGroup) {
      return true;
    }
    return false;
  }

  // 更新渲染缓存
;
  _proto.updateRenderCache = function updateRenderCache() {
    this.lastOption = cloneDeep(this.option);
  };
  _proto.resizeHandler = function resizeHandler() {
    var newWidth = this.dom.clientWidth;
    var newHeight = this.dom.clientHeight;
    if (newWidth && newHeight) {
      this.width = newWidth;
      this.height = newHeight;
      var _resolveOption = resolveOption(this.option, this.option, newWidth, newHeight),
        paddingConfig = _resolveOption.paddingConfig,
        contentWidth = _resolveOption.contentWidth,
        contentHeight = _resolveOption.contentHeight;
      updateSvgs([{
        el: this.contentGroup,
        attrs: this.styles.updateContentGroup(paddingConfig.left, paddingConfig.top, contentWidth, contentHeight)
      }, {
        el: this.clipRect,
        attrs: this.styles.updateClipRect(contentWidth, contentHeight)
      }]);
      if (this.headerGroup) this.headerGroup.resize(contentWidth);
      if (this.rowList) this.rowList.resize(contentWidth);
      if (this.scrollArea) this.scrollArea.resize(contentWidth, contentHeight, paddingConfig);
    }
  };
  _proto.setResize = function setResize() {
    this.resizeHandler();
    this.resizeObserver = new ResizeObserver(debounce(this.resizeHandler.bind(this), 100));
    this.resizeObserver.observe(this.dom);
  }

  // 更新样式和颜色
;
  _proto.updateStyles = function updateStyles() {
    var _this3 = this;
    // 动态获取最新的 chartToken
    import('../../feature/token/index.js').then(function (Token) {
      var latestChartToken = Token["default"].getTokenByName('RankProcessChart');

      // 更新时优先使用用户设置的颜色，如果没有则使用主题颜色
      var colorArray = null;
      if (_this3.option.color && _this3.option.color.length > 0) {
        colorArray = _this3.option.color;
      } else {
        colorArray = getColorsFromToken();
      }
      if (_this3.headerGroup) _this3.headerGroup.updateStyles(latestChartToken);
      if (_this3.rowList) _this3.rowList.updateStyles(latestChartToken, colorArray);
      if (_this3.scrollArea) _this3.scrollArea.updateStyles(latestChartToken);
      if (_this3.tooltip) _this3.tooltip.updateStyles(_this3.option.theme);
    });
  }

  // 更新布局
;
  _proto.updateLayout = function updateLayout() {
    this.resizeHandler();
  };
  _proto.update = function update() {
    var _this4 = this;
    // 判断哪些属性需要更新
    var updates = isUpdate(this.option, this.lastOption);
    if (updates) {
      var _resolveOption2 = resolveOption(this.option, this.option, this.width, this.height),
        titleName = _resolveOption2.titleName,
        valueName = _resolveOption2.valueName,
        percentName = _resolveOption2.percentName,
        data = _resolveOption2.data,
        paddingConfig = _resolveOption2.paddingConfig,
        contentWidth = _resolveOption2.contentWidth,
        contentHeight = _resolveOption2.contentHeight;
      if (updates.includes('data') || updates.includes('sort') || updates.includes('padding')) {
        this.rowList.updateRows({
          data: data,
          containerWidth: contentWidth,
          scrollCallback: function scrollCallback() {
            return {
              scrollY: _this4.scrollArea ? _this4.scrollArea.scrollY : DEFAULT_SCROLL_INFO.SCROLLY,
              viewHeight: contentHeight - HEADER.HEIGHT
            };
          }
        });
      }
      if (updates.includes('data') || updates.includes('color') || updates.includes('padding')) {
        this.scrollArea.updateScrollArea({
          width: contentWidth,
          height: contentHeight,
          paddingConfig: paddingConfig
        });
      }
      if (updates.includes('titleName') || updates.includes('valueName') || updates.includes('percentName') || updates.includes('padding')) {
        this.headerGroup.updateText({
          titleName: titleName,
          valueName: valueName,
          percentName: percentName,
          headerWidth: contentWidth
        });
      }
      if (updates.includes('theme') || updates.includes('color')) {
        this.updateStyles();
      }
      if (updates.includes('padding')) {
        this.updateLayout();
      }
      this.updateRenderCache();
    }
  }

  // 设置渲染完成回调
;
  _proto.onRenderReady = function onRenderReady(callback) {
    if (callback && typeof callback === 'function') {
      this.renderCallBack = callback;
    }
  }

  // 刷新图表配置
;
  _proto.refresh = function refresh(newoption) {
    this.setSimpleOption(newoption);
    this.render();
  }

  // 仅刷新数据
;
  _proto.refreshData = function refreshData(newData) {
    if (!isArray(newData)) {
      newData = [newData];
    }
    this.option.data = newData;
    this.refresh(this.option);
  }

  // 卸载图表内容
;
  _proto.uninstall = function uninstall() {
    this.svg.innerHTML = '';
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
      this.resizeObserver = null;
    }
    if (this.scrollArea) {
      this.scrollArea.destroy();
    }
  }

  // 销毁图表
;
  _proto.destroy = function destroy() {
    if (this.dom) {
      this.uninstall();
      this.dom.innerHTML = '';
      if (this.tooltip) {
        this.tooltip.destroy();
      }
      this.option = _extends({}, DEFAULT_OPTION);
    }
  };
  return RankProcessChart;
}(BaseChart);
export { RankProcessChart as default };
