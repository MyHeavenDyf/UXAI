import Token from '../../feature/token/index.js';
import { CHART_TYPE } from '../../util/constants.js';
var chartToken = Token.getTokenByName(CHART_TYPE.RANKPROCESS);
export { chartToken as default };
