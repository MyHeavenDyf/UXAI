import { calcColumnX, createSvgElement, updateSvgs } from './utils.js';
import { HEADER, TEXT } from './constants.js';
import { getHeaderStyles } from './style.js';
import chartToken from './chartToken.js';
var HeaderRow = /*#__PURE__*/function () {
  function HeaderRow(option) {
    var titleName = option.titleName,
      valueName = option.valueName,
      percentName = option.percentName,
      headerWidth = option.headerWidth;
    this.headerFields = [titleName, valueName, percentName];
    this.headerWidth = headerWidth;
    this.headerHeight = HEADER.HEIGHT;
    this.padding = TEXT.PADDING;

    // 获取样式配置
    this.styles = getHeaderStyles(chartToken);
    // 计算文本的X坐标位置
    this.columnX = calcColumnX(TEXT.FLEX_SPACE, this.headerWidth, this.padding);
  }
  var _proto = HeaderRow.prototype;
  _proto.render = function render() {
    this.headerRow = createSvgElement('g');
    this.renderBg(); // 渲染首部背景
    this.renderText(); // 渲染首部文本

    return this.headerRow;
  };
  _proto.renderBg = function renderBg() {
    this.headerBg = createSvgElement('rect', this.styles.getHeaderBg(this.headerWidth, this.headerHeight), this.headerRow);
  };
  _proto.renderText = function renderText() {
    var _this = this;
    // 存放svg文本元素
    this.textElements = [];
    this.textContainer = createSvgElement('g', this.styles.getHeaderContainer(this.headerHeight), this.headerRow);
    var textStyles = this.styles.getHeaderText(this.columnX);
    this.headerFields.forEach(function (text, index) {
      var content = createSvgElement('text', textStyles[index], _this.textContainer);
      content.textContent = text;
      _this.textElements.push(content);
    });
  }

  // 重新计算布局
;
  _proto.recalculateLayout = function recalculateLayout(width) {
    this.headerWidth = width;
    this.columnX = calcColumnX(TEXT.FLEX_SPACE, width, this.padding);
  }

  // 自适应计算布局
;
  _proto.resize = function resize(newWidth) {
    var _this2 = this;
    this.recalculateLayout(newWidth);
    updateSvgs([{
      el: this.headerBg,
      attrs: this.styles.updateHeaderBg(newWidth)
    }].concat(this.textElements.map(function (text, index) {
      return {
        el: text,
        attrs: _this2.styles.updateHeaderText(_this2.columnX)[index]
      };
    })));
  }

  // 更新主题样式
;
  _proto.updateStyles = function updateStyles(latestChartToken) {
    this.styles = getHeaderStyles(latestChartToken);
    var newStyle = this.styles.getThemeUpdates();
    updateSvgs([{
      el: this.headerBg,
      attrs: newStyle.headerBg
    }].concat(this.textElements.map(function (text) {
      return {
        el: text,
        attrs: newStyle.headerText
      };
    })));
  }

  // 更新内容
;
  _proto.updateText = function updateText(options) {
    var _this3 = this;
    var titleName = options.titleName,
      valueName = options.valueName,
      percentName = options.percentName,
      headerWidth = options.headerWidth;

    // 更新文本字段
    var newFields = [titleName, valueName, percentName];
    this.headerFields = newFields;

    // 更新文本内容
    this.textElements.forEach(function (text, index) {
      text.textContent = _this3.headerFields[index];
    });

    // 如果宽度变化，调用resize更新布局
    this.resize(headerWidth);
  };
  return HeaderRow;
}();
function renderHeader(svg, containerWidth, titleName, valueName, percentName) {
  // 参数验证
  if (!svg || !containerWidth || containerWidth <= 0) {
    return null;
  }
  var headerRow = new HeaderRow({
    titleName: titleName || '名称',
    valueName: valueName || '数值',
    percentName: percentName || '百分比',
    headerWidth: containerWidth
  });
  var headerGroup = headerRow.render();
  svg.appendChild(headerGroup);
  return headerRow;
}
export { renderHeader };
