function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import cloneDeep from '../../util/cloneDeep.js';
import chartToken from './chartToken.js';
import { getDataWidthNoObject, judgeFilterAreaSeries } from './AreaChart/bottomArea.js';
import getTooltipContentHtmlStr, { validateName } from '../../option/config/tooltip/formatter.js';
import { isArray, isObject } from '../../util/type.js';
import { getColor } from '../../util/color.js';
import mobile from '../../util/mobile.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 给图例和x轴赋值
function handleData(baseOpt, legendData, xAxisData) {
  if (!baseOpt.legend.data) {
    baseOpt.legend.data = legendData;
  }
  baseOpt.xAxis.forEach(function (item) {
    item.data = xAxisData;
  });
}
function onlyOnePoint(baseOption) {
  baseOption.series.forEach(function (itemObj) {
    if (itemObj.data.length === 1) {
      itemObj.showSymbol = true;
      itemObj.itemStyle.opacity = 1;
    }
  });
}
function isNullValue(value) {
  return value === '' || value === undefined || value === null;
}

// 实现离散数据的markLine变色功能
function addDiscreteVisualMap(baseOption, iChartOption, actualSeriesIndex, seriesIndex, discreteVisualMap) {
  var area = iChartOption.area;
  var visualMap = baseOption.visualMap;
  // 如果是面积图不做处理
  if (area) return;
  if (visualMap && visualMap.lenth !== 0) {
    var newVisualMapItem = visualMap[seriesIndex] ? cloneDeep(visualMap[seriesIndex]) : null;
    if (newVisualMapItem) {
      newVisualMapItem.seriesIndex = actualSeriesIndex;
      discreteVisualMap.push(newVisualMapItem);
    }
  }
}

// 针对离散数据, 创建同名Series, 显示离散数据的单个点
function discrete(iChartOption, baseOption) {
  // 创建同名Series
  if (iChartOption.discrete) {
    // 记录实际的真实数据产生的sereis的
    var actualSeriesIndex = baseOption.series.length - 1;
    var discreteSeries = [];
    var discreteVisualMap = [];
    baseOption.series.forEach(function (series, seriesIndex) {
      var newSeries = cloneDeep(series);
      newSeries.symbolSize = chartToken.symbolSizeSM;
      newSeries.itemStyle.borderWidth = chartToken.borderZero;
      newSeries.itemStyle.opacity = 1;
      newSeries.showSymbol = true;
      newSeries.showAllSymbol = true;
      newSeries.emphasis = {
        itemStyle: {
          opacity: 0
        }
      };
      var discreteData = [];
      var seriesData = getDataWidthNoObject(newSeries.data);
      for (var index = 0; index < seriesData.length; index++) {
        var pre = seriesData[index - 1];
        var next = seriesData[index];
        var cur = seriesData[index + 1];
        if (!isNullValue(pre) || !isNullValue(cur)) {
          discreteData.push(null);
        } else {
          discreteData.push(next);
        }
      }
      newSeries.data = discreteData;
      actualSeriesIndex++;
      addDiscreteVisualMap(baseOption, iChartOption, actualSeriesIndex, seriesIndex, discreteVisualMap);
      discreteSeries.push(newSeries);
    });
    baseOption.series = [].concat(baseOption.series, discreteSeries);
    baseOption.visualMap = [].concat(baseOption.visualMap, discreteVisualMap);
  }
}
function defaultFormatter(params, color, iChartOpt, hideEmpty, tooltip) {
  var _iChartOpt$theme;
  var config = {
    title: '',
    children: [],
    hideEmpty: hideEmpty
  };
  var seriesNames = [];
  if (isArray(params)) {
    params.forEach(function (item, index) {
      var _iChartOpt$legend;
      var value = item.value;
      var name = item.seriesName;
      var type = (_iChartOpt$legend = iChartOpt.legend) == null ? void 0 : _iChartOpt$legend.icon;
      if ((iChartOpt.area || iChartOpt.discrete) && seriesNames.includes(name)) {
        return;
      } else {
        seriesNames.push(name);
        if (isObject(value)) {
          iChartOpt.data.forEach(function (data) {
            var _value;
            if (data.product === ((_value = value) == null ? void 0 : _value.product)) {
              value = data[name];
            }
          });
        }
        if (index === 0) {
          config.title = item.name;
        }
        var iconColor = validateName(value) ? item.color : getColor(color, item.seriesIndex);
        var dataItem = {
          name: name,
          value: value,
          iconColor: iconColor,
          type: type
        };
        config.children.push(dataItem);
      }
    });
  } else if (isObject(params)) {
    var _iChartOpt$legend2;
    var dataItem = {
      name: params.seriesName || '',
      value: params.value || '',
      iconColor: validateName(params.value) ? params.color : getColor(color, params.seriesIndex),
      type: (_iChartOpt$legend2 = iChartOpt.legend) == null ? void 0 : _iChartOpt$legend2.icon
    };
    config.children.push(dataItem);
    config.title = params.name;
  }
  var isMobile = iChartOpt.isMobile || mobile();
  var isHdesign = (_iChartOpt$theme = iChartOpt.theme) == null ? void 0 : _iChartOpt$theme.includes('hdesign');
  config.isMobile = iChartOpt.adaptive && isHdesign && isMobile;
  return getTooltipContentHtmlStr(config, tooltip);
}

// 阈值场景将data中的数据转为obj，需要转换回来
function coverObjDataToInit(params) {
  if (params && isArray(params) && params.length !== 0) {
    return params.map(function (item) {
      var data = isObject(item.data) ? item.data.value : item.data;
      return _extends({}, item, {
        data: data
      });
    });
  }
  return params;
}
function setTooltip(baseOpt, iChartOpt, legendData) {
  var discrete = iChartOpt.discrete,
    predict = iChartOpt.predict,
    tipHtml = iChartOpt.tipHtml,
    tooltip = iChartOpt.tooltip,
    color = iChartOpt.color;
  // 判断面积图是否要过滤series
  var filterArea = judgeFilterAreaSeries(iChartOpt);
  var isFilter = discrete || predict || filterArea;
  var formatter = tipHtml || (tooltip == null ? void 0 : tooltip.formatter) || (tooltip == null ? void 0 : tooltip.valueFormatter);
  baseOpt.tooltip.formatter = function (echartsParams, ticket, callback) {
    var _baseOpt$tooltip;
    var params = echartsParams;
    if (isFilter) {
      var lineNumber = legendData.length;
      params = echartsParams.slice(0, lineNumber);
    }
    var initParams = coverObjDataToInit(params);
    return formatter && typeof formatter === 'function' ? formatter(initParams, ticket, callback) : defaultFormatter(initParams, color, iChartOpt, (_baseOpt$tooltip = baseOpt.tooltip) == null ? void 0 : _baseOpt$tooltip.hideEmpty, baseOpt.tooltip);
  };
}
export { discrete, handleData, onlyOnePoint, setTooltip };
