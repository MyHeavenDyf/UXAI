import min from '../../util/sort/min.js';
import max from '../../util/sort/max.js';
import { isArray, isNumber } from '../../util/type.js';
import { getColor } from '../../util/color.js';
import Token from '../../feature/token/index.js';
import chartToken from './chartToken.js';
import { mergeVisualMapPieces } from '../../option/config/visualMap/index.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

function handleVisualMapItem(_ref) {
  var index = _ref.index,
    topColor = _ref.topColor,
    top = _ref.top,
    bottom = _ref.bottom,
    bottomColor = _ref.bottomColor,
    vmColor = _ref.vmColor,
    defaultColor = _ref.defaultColor;
  var visualMapItem = {
    show: false,
    type: 'piecewise',
    dimension: 1,
    seriesIndex: index,
    pieces: [{
      gte: top,
      // 大于 top 的
      color: topColor
    }, {
      gt: bottom,
      lt: top,
      // 小于 top, 大于 bottom 的，为正常颜色
      color: defaultColor
    }, {
      lte: bottom,
      // 小于 bottom
      color: bottomColor
    }],
    outOfRange: {
      color: vmColor
    }
  };
  return visualMapItem;
}
function setVisualMap(legendData, seriesData, iChartOpt, baseOpt, chartsIns) {
  var visualMap = [];
  var colors = iChartOpt.color,
    markLine = iChartOpt.markLine;
  if (!markLine) return visualMap;
  if (isArray(markLine)) {
    legendData.forEach(function (legend, index) {
      var _visualMapItem$pieces;
      var visualMapItem = {
        show: false,
        type: 'piecewise',
        dimension: 1,
        seriesIndex: index,
        outOfRange: {
          color: colors[index]
        }
      };
      mergeVisualMapPieces(visualMapItem, markLine, colors, legend);
      var vmColor = Token.config.colorState.colorError;
      var seriesUnit = baseOpt.series[index];
      var data = seriesData[legend];
      var defaultColor = getColor(colors, index);
      if (((_visualMapItem$pieces = visualMapItem.pieces) == null ? void 0 : _visualMapItem$pieces.length) > 0) {
        transformPiecesData(seriesUnit, data, defaultColor, visualMapItem.pieces, vmColor);
        visualMap.push(visualMapItem);
      }
    });
  } else {
    var topValue = markLine.top;
    var bottomValue = markLine.bottom;
    var vmColor = Token.config.colorState.colorError;
    var topColor = markLine.topColor || vmColor;
    var bottomColor = markLine.bottomColor || vmColor;
    if (!isNumber(topValue)) {
      topValue = undefined;
    }
    if (!isNumber(bottomValue)) {
      bottomValue = undefined;
    }
    if (topValue === undefined && bottomValue === undefined) {
      return visualMap;
    }
    if (topValue !== undefined && bottomValue !== undefined && bottomValue >= topValue) {
      throw new Error('阈值线bottom的值必须小于阈值线top的值');
    }
    legendData.forEach(function (legendName, index) {
      var data = seriesData[legendName];
      var minData = chartsIns.getYAxisMinValue(chartsIns.chartInstance, 0);
      var maxData = chartsIns.getYAxisMaxValue(chartsIns.chartInstance, 0);
      minData = minData !== undefined ? minData : min(data);
      maxData = maxData !== undefined ? maxData : max(data);
      if (minData === undefined || maxData === undefined) {
        return visualMap;
      }
      var defaultColor = getColor(colors, index);
      var bottom = bottomValue;
      var top = topValue;
      if (markLine.topUse && markLine.topUse.indexOf(legendName) === -1) {
        top = undefined;
      }
      if (markLine.bottomUse && markLine.bottomUse.indexOf(legendName) === -1) {
        bottom = undefined;
      }
      if (top === undefined && bottom === undefined) {
        return;
      }
      // 阈值无下限
      if (bottom === undefined) {
        bottom = Math.min(top - 0.01, minData - 0.01);
      }
      // 阈值无上限
      if (top === undefined) {
        top = Math.max(bottom + 0.01, maxData + 0.01);
      }
      // 根据数据大小映射颜色
      var visualMapItem = handleVisualMapItem({
        index: index,
        topColor: topColor,
        top: top,
        bottom: bottom,
        bottomColor: bottomColor,
        vmColor: vmColor,
        defaultColor: defaultColor
      });
      visualMap.push(visualMapItem);
      var seriesUnit = baseOpt.series[index];
      //  阈值情景下hover的emphasis中itemstyle要在数据中单独设置，覆盖通用emphasis配置
      transformData(seriesUnit, data, defaultColor, {
        topColor: topColor,
        top: top,
        bottom: bottom,
        bottomColor: bottomColor
      });
    });
  }
  return visualMap;
}
function transformData(seriesUnit, data, defaultColor, markLineConfig) {
  var topColor = markLineConfig.topColor,
    top = markLineConfig.top,
    bottom = markLineConfig.bottom,
    bottomColor = markLineConfig.bottomColor;
  var newData = data.map(function (item) {
    var borderColor = defaultColor;
    if (bottom < item && item < top) {
      return item;
    }
    if (item >= top) {
      borderColor = topColor;
    }
    if (item <= bottom) {
      borderColor = bottomColor;
    }
    return {
      value: item,
      emphasis: {
        itemStyle: {
          borderColor: borderColor,
          color: chartToken.maskColor,
          opacity: 1
        }
      }
    };
  });
  seriesUnit.data = newData;
}
function transformPiecesData(seriesUnit, data, defaultColor, VMpieces, vmColor) {
  var newData = data.map(function (item) {
    var borderColor = defaultColor;
    VMpieces.forEach(function (pieces) {
      var lt = pieces.lt,
        lte = pieces.lte,
        gt = pieces.gt,
        gte = pieces.gte,
        color = pieces.color,
        min = pieces.min,
        max = pieces.max,
        value = pieces.value;
      if (min !== undefined) lte = min;
      if (max !== undefined) gte = max;
      if (gte !== undefined || gt !== undefined) {
        if ((item > gt || item >= gte) && (lt !== undefined && item < lt || lte !== undefined && item <= lte)) {
          borderColor = color || vmColor;
        } else if ((item > gt || item >= gte) && lte === undefined && lt === undefined) {
          borderColor = color || vmColor;
        } else {
          return item;
        }
      } else if ((lt !== undefined && item < lt || lt !== undefined && item <= lt) && gte === undefined && gt === undefined) {
        borderColor = color || vmColor;
      } else {
        return item;
      }
      if (value !== undefined && item === value) {
        borderColor = color || vmColor;
      }
    });
    return {
      value: item,
      emphasis: {
        itemStyle: {
          borderColor: borderColor,
          color: chartToken.maskColor,
          opacity: 1
        }
      }
    };
  });
  seriesUnit.data = newData;
}
export { setVisualMap };
