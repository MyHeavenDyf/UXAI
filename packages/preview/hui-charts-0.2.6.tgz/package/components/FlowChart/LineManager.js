var _LineFactory;
import LineRound from './LineRound.js';
import LineBezier from './LineBezier.js';
import LineDirect from './LineDirect.js';
import { createTransLine, transLine } from './LineMode.js';
import { NODE_ID_PREFIX } from './NodeManager.js';
import { attr, createSvgByTag, addClass } from './util.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

var LINE_ID_PREFIX = 'fc-line-';
var TYPE_ROUND = 'Round';
var TYPE_BEZIER = 'Bezier';
var TYPE_Direct = 'Direct';
var TYPE_STRAIGHT = 'Straight';
var defaultStyle = {
  width: 1,
  color: '#c2c2c2',
  type: TYPE_ROUND
};
var LineFactory = (_LineFactory = {}, _LineFactory[TYPE_ROUND] = LineRound, _LineFactory[TYPE_Direct] = LineDirect, _LineFactory[TYPE_BEZIER] = LineBezier, _LineFactory[TYPE_STRAIGHT] = LineRound, _LineFactory);

// 流程线仅支持直线和折线图
var transLineType = ['Direct', 'Round', 'Straight'];
var LineManager = /*#__PURE__*/function () {
  function LineManager(data, container, tagContainer, containerPosn, option) {
    // 连线样式
    this.style = void 0;
    // 连线数据计算器
    this.lineCreator = void 0;
    // 连线方向
    this.direction = void 0;
    this.data = data;
    this.option = option;
    this.tagContainer = tagContainer;
    this.direction = option.direction;
    this.initColor(option);
    this.style = Object.assign({}, defaultStyle, option.lineStyle);
    this.createLineCreator(container);
    this.initArrow();
    this.container = container;
    this.containerPosn = containerPosn;
    this.getLineAlignStyle(data.edges);
    this.createLines(data.edges);
    this.connectVirtualLine(data.edges);
    this.createTags(data.edges);
  }
  var _proto = LineManager.prototype;
  _proto.initColor = function initColor(option) {
    if (option.theme && option.theme === 'dark') {
      defaultStyle.color = '#ffffff';
    }
  };
  _proto.initArrow = function initArrow() {
    var arrow = document.getElementById('markerArrow');
    var color = this.style.color || '#c2c2c2';
    attr(arrow, 'fill', color);
  }

  /**
   * 生成连线数据计算器
   */;
  _proto.createLineCreator = function createLineCreator(container) {
    if (this.style.type === TYPE_STRAIGHT) {
      this.style.radius = 0;
    }
    var CreatorClass = LineFactory[this.style.type];
    this.lineCreator = new CreatorClass(this.style, {
      gContainer: container,
      tagContainer: this.tagContainer
    });
  }

  /**
   *
   * 计算连线的对齐方式，是向前对齐，还是向后对齐
   */;
  _proto.getLineAlignStyle = function getLineAlignStyle(edges) {
    edges.forEach(function (edge) {
      if (!edge.alignType) {
        var sameSource = edges.filter(function (item) {
          return item.source === edge.source && item !== edge;
        });
        if (sameSource.length > 0) {
          edge.alignType = 'source';
          sameSource.forEach(function (item) {
            item.alignType = 'source';
          });
        }
      }
    });
    edges.forEach(function (edge) {
      if (!edge.alignType) {
        edge.alignType = 'target';
      }
    });
  }

  /**
   * 计算连线数据
   */;
  _proto.setData = function setData(edge) {
    var _edge$lineStyle;
    if (edge != null && (_edge$lineStyle = edge.lineStyle) != null && _edge$lineStyle.type) {
      var _edge$lineStyle2;
      // edge节点应用自身设置的连线样式
      var CreatorClass = LineFactory[edge == null ? void 0 : (_edge$lineStyle2 = edge.lineStyle) == null ? void 0 : _edge$lineStyle2.type];
      var lineCreator = new CreatorClass(edge == null ? void 0 : edge.lineStyle, {
        gContainer: this.container,
        tagContainer: this.tagContainer
      });
      return lineCreator.setData(edge, this.data, this.direction);
    } else {
      this.lineCreator.setData(edge, this.data, this.direction);
    }
    // 用户自定义edge位置修正
    if (edge.offset) {
      edge.offset(edge);
    }
  }

  /**
   * 拼接连线信息
   */;
  _proto.setPath = function setPath(edge) {
    var _edge$lineStyle3;
    if (edge != null && (_edge$lineStyle3 = edge.lineStyle) != null && _edge$lineStyle3.type) {
      var _edge$lineStyle4;
      // edge节点应用自身设置的连线样式
      var CreatorClass = LineFactory[edge == null ? void 0 : (_edge$lineStyle4 = edge.lineStyle) == null ? void 0 : _edge$lineStyle4.type];
      var lineCreator = new CreatorClass(edge == null ? void 0 : edge.lineStyle, {
        gContainer: this.container,
        tagContainer: this.tagContainer
      });
      return lineCreator.setPath(edge);
    } else {
      return this.lineCreator.setPath(edge);
    }
  }

  // 根据数据创建连线
;
  _proto.createLines = function createLines(edges) {
    var _this = this;
    edges.forEach(function (edge) {
      _this.setData(edge);
      var path = _this.createLine(edge);
      _this.container.appendChild(path);
    });
  }

  // 创建连线dom
;
  _proto.createLine = function createLine(edge) {
    var _edge$lineStyle5;
    var path = createSvgByTag('path');
    var id = LINE_ID_PREFIX + edge.source + '-to-' + edge.target;
    var d = this.setPath(edge);
    edge.id = id;
    attr(path, 'd', d);
    attr(path, 'id', id);
    if (this.style.color) {
      attr(path, 'stroke', this.style.color);
    }
    if (this.style.dash || this.style.mode === 'dash') {
      attr(path, 'stroke-dasharray', 5);
    }
    if (edge.lineStyle && edge.lineStyle.color) {
      attr(path, 'stroke', edge.lineStyle.color);
    }
    if (edge.lineStyle && (edge.lineStyle.dash || edge.lineStyle.mode === 'dash')) {
      attr(path, 'stroke-dasharray', 5);
    }
    if (edge.lineStyle && edge.lineStyle.dash === false) {
      attr(path, 'stroke-dasharray', 0);
    }
    if (this.style.width) {
      attr(path, 'stroke-width', this.style.width + 'px');
    }
    if (edge.lineStyle && edge.lineStyle.width) {
      attr(path, 'stroke-width', edge.lineStyle.width + 'px');
    }
    addClass(path, 'fc-line');
    // type为Direct  不添加箭头
    var noDirect = (edge == null ? void 0 : (_edge$lineStyle5 = edge.lineStyle) == null ? void 0 : _edge$lineStyle5.type) === TYPE_Direct || this.style.type === TYPE_Direct;
    addClass(path, noDirect ? 'fc-noArrow' : '');
    if (this.isTransLine(edge)) {
      var _edge$lineStyle6;
      path = createTransLine(d, transLine(edge, id, ((_edge$lineStyle6 = edge.lineStyle) == null ? void 0 : _edge$lineStyle6.transPattern) || this.style.transPattern));
    } else {
      var childNode = document.getElementById(edge.id);
      !!childNode && document.getElementById('fc-trans-container').removeChild(childNode);
    }
    return path;
  }

  // 是否是流程线
;
  _proto.isTransLine = function isTransLine(edge) {
    var isTrans = false;
    if (transLineType.includes(this.style.type)) {
      if (this.style.mode === 'trans') {
        isTrans = true;
        if ('lineStyle' in edge && 'mode' in edge.lineStyle) {
          if (edge.lineStyle.mode !== 'trans') {
            isTrans = false;
          }
        }
      } else {
        if ('lineStyle' in edge && 'mode' in edge.lineStyle && edge.lineStyle.mode === 'trans') {
          isTrans = true;
        }
      }
    }
    return isTrans;
  }

  // 将两段虚拟连线链接起来
;
  _proto.connectVirtualLine = function connectVirtualLine(edges) {
    var _this2 = this;
    // 取出所有 target 为 virtual 的连线
    var targetVirtualEdges = edges.filter(function (edge) {
      return edge.target.includes('virtual');
    });
    // 取出所有 source 为  virtual 的连线
    var sourceVirtualEdges = edges.filter(function (edge) {
      return edge.source.includes('virtual');
    });
    targetVirtualEdges.forEach(function (targetEdge) {
      var sourceEdge = sourceVirtualEdges.filter(function (item) {
        return item.source === targetEdge.target;
      })[0];
      var targetEdgeDom = _this2.container.querySelector("#" + targetEdge.id);
      var sourceEdgeDom = _this2.container.querySelector("#" + sourceEdge.id);
      sourceEdgeDom.remove();
      var newPath = targetEdgeDom.getAttribute('d') + ' L' + sourceEdgeDom.getAttribute('d').slice(1);
      var newId = LINE_ID_PREFIX + targetEdge.source + '-to-' + sourceEdge.target;
      targetEdgeDom.setAttribute('d', newPath);
      targetEdgeDom.setAttribute('id', newId);
    });
  };
  _proto.createTags = function createTags(edges) {
    var _this3 = this;
    edges.forEach(function (edge) {
      _this3.option.renderTag && _this3.option.renderTag(_this3.tagContainer, edge);
    });
  }

  // 更新连线
;
  _proto.updateLine = function updateLine(domId) {
    var _this4 = this;
    var nodeId = domId == null ? void 0 : domId.replace(NODE_ID_PREFIX, '');
    this.data.edges.forEach(function (edge) {
      if (edge.source === nodeId || edge.target === nodeId) {
        var _document$getElementB;
        _this4.setData(edge);
        var id = LINE_ID_PREFIX + edge.source + '-to-' + edge.target;
        if (_this4.isTransLine(edge)) {
          var _edge$lineStyle7;
          var parentNode = document.getElementById('fc-trans-container');
          var updateChild = document.getElementById(id);
          updateChild && parentNode.removeChild(updateChild);
          createTransLine(_this4.setPath(edge), transLine(edge, id, ((_edge$lineStyle7 = edge.lineStyle) == null ? void 0 : _edge$lineStyle7.transPattern) || _this4.style.transPattern));
        }
        (_document$getElementB = document.getElementById(id)) == null ? void 0 : _document$getElementB.setAttribute('d', _this4.setPath(edge));
      }
    });
  }

  // 更新所有连线
;
  _proto.updateAllLine = function updateAllLine() {
    var _this5 = this;
    this.data.nodes.forEach(function (node) {
      var _node$dom;
      var domId = ((_node$dom = node.dom) == null ? void 0 : _node$dom.id) || node.id;
      _this5.updateLine(domId);
    });
  };
  return LineManager;
}();
export { LineManager as default };
