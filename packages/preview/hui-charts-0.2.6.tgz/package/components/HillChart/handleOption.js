import Token from '../../feature/token/index.js';
import { codeToRGB, codeToHex } from '../../util/color.js';
import merge from '../../util/merge.js';
import chartToken from './chartToken.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 配置数据
function handleData(iChartOption, baseOpt) {
  var dataName = [];
  iChartOption.data.forEach(function (item) {
    dataName.push(item.name);
  });
  baseOpt.xAxis.data = dataName;
  baseOpt.series[0].data = iChartOption.data;
}

// 配置山峰颜色及透明度
function handleColor(iChartOption, baseOpt) {
  // 配置显示的颜色
  baseOpt.series[0].itemStyle = {
    // opacity: iChartOption.opacity,
    normal: {
      color: function color(params) {
        return codeToRGB(codeToHex(iChartOption.color[params.dataIndex % iChartOption.color.length]), iChartOption.opacity || 0.8);
      }
    }
  };
}

// 配置文本
function handleText(iChartOption, baseOpt) {
  // 山峰头部文本
  baseOpt.series[0].label = {
    normal: {
      show: iChartOption.text && iChartOption.text.show === true ? iChartOption.text && iChartOption.text.show : false,
      position: 'top',
      textStyle: {
        fontSize: iChartOption.text && iChartOption.text.fontSize ? iChartOption.text && iChartOption.text.fontSize : 12,
        color: iChartOption.text && iChartOption.text.fontColor ? iChartOption.text.fontColor : chartToken.labelColor
      }
    }
  };
}

// 配置ChartPadding
function handlePadding(iChartOption, baseOpt) {
  baseOpt['grid'] = {
    top: iChartOption.padding[0],
    right: iChartOption.padding[1],
    bottom: iChartOption.padding[2],
    left: iChartOption.padding[3],
    containLabel: true
  };
}

// 配置相邻山峰间隔
function handleCoincide(iChartOption, baseOpt) {
  baseOpt.series[0]['barCategoryGap'] = iChartOption.coincide ? iChartOption.coincide : '-100%';
}
var setColorStops = function setColorStops(color, opacity, index, colors) {
  if (!color || index >= colors.length) {
    throw new Error('Invalid color configuration');
  }
  return !opacity ? color : codeToRGB(codeToHex(color), opacity || 0.8);
};

// 配置渐变色
function setGradientColor(baseOpt, color, gradientColor, opacity, iChartOption) {
  if (gradientColor) {
    baseOpt.series[0].itemStyle = {
      normal: {
        color: function color(params) {
          return {
            type: 'linear',
            x: 0,
            y: 0,
            x2: 0,
            y2: 1,
            colorStops: [{
              offset: 0,
              color: setColorStops(gradientColor[params.dataIndex % gradientColor.length], opacity, params.dataIndex, gradientColor)
            }, {
              offset: 1,
              color: setColorStops(iChartOption.color[params.dataIndex % iChartOption.color.length], opacity, params.dataIndex, iChartOption.color)
            }],
            globalCoord: false
          };
        }
      }
    };
  }
}
var colorWhole = function colorWhole(baseOpt, item, markLine, colorError, index) {
  baseOpt.series[0].data[index] = {
    value: item,
    itemStyle: {
      color: markLine.color || colorError
    }
  };
};
var colorExcess = function colorExcess(baseOpt, iChartOpt, item, index, i) {
  var markLine = iChartOpt.markLine,
    color = iChartOpt.color,
    opacity = iChartOpt.opacity;
  var colorError = Token.config.colorState.colorError;
  baseOpt.series[0].data[index] = {
    value: item,
    itemStyle: {
      color: {
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        type: 'linear',
        colorStops: [{
          offset: 0,
          color: markLine.color || colorError
        }, {
          offset: (item - markLine[i]) / item,
          color: markLine.color || colorError
        }, {
          offset: (item - markLine[i]) / item,
          color: codeToRGB(codeToHex(color[index % color.length]), opacity || 0.8)
        }, {
          offset: 1,
          color: codeToRGB(codeToHex(color[index % color.length]), opacity || 0.8)
        }]
      }
    }
  };
};
var reviseMarkLineData = function reviseMarkLineData(baseOpt, iChartOpt, i) {
  var markLine = iChartOpt.markLine;
  var colorError = Token.config.colorState.colorError;
  baseOpt.series[0].data.forEach(function (item, index) {
    if (item > markLine[i] && i === 'top') {
      // 整体变色
      if (markLine.topWholeColor) {
        colorWhole(baseOpt, item, markLine, colorError, index);
      } else {
        // 超出部分变色
        colorExcess(baseOpt, iChartOpt, item, index, i);
      }
    } else if (item < markLine[i] && i === 'bottom') {
      // 低于bottom的直接整体变色，不用判断
      colorWhole(baseOpt, item, markLine, colorError, index);
    }
  });
};

// 配置阈值线(整体变色，超过部分变色)
function handleMarkLine(baseOpt, iChartOpt) {
  var markLine = iChartOpt.markLine;
  if (markLine) {
    for (var i in markLine) {
      if (i === 'top' || i === 'bottom') {
        // series插入阈值线
        baseOpt.series[0].markLine.data.push({
          yAxis: markLine[i]
        });
        // 重置数据
        reviseMarkLineData(baseOpt, iChartOpt, i);
      }
    }
    // 合并属性
    merge(baseOpt.series[0].markLine, markLine);
  }
}
export { handleCoincide, handleColor, handleData, handleMarkLine, handlePadding, handleText, setGradientColor };
