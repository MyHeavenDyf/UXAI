function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import getBaseOption from './baseOption.js';
import { handleData, handleColor, handleText, handlePadding, handleCoincide, setGradientColor, handleMarkLine } from './handleOption.js';
import { handleEmphasis } from './handleSeries.js';
import init from '../../option/init/index.js';
import { title } from '../../option/config/rectTitle/index.js';
import tooltip from '../../option/config/tooltip/index.js';
import xAxis from '../../option/config/xAxis/index.js';
import yAxis from '../../option/config/yAxis/index.js';
import { CHART_TYPE } from '../../util/constants.js';
import { mergeSeries } from '../../util/merge.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var HillChart = /*#__PURE__*/function () {
  function HillChart(iChartOption, chartInstance) {
    this.baseOption = {};
    this.iChartOption = {};
    this.baseOption = getBaseOption();
    // 组装 iChartOption, 补全默认值
    this.iChartOption = init(iChartOption);
    // 根据 iChartOption 组装 baseOption
    this.updateOption(iChartOption, chartInstance);
  }
  var _proto = HillChart.prototype;
  _proto.updateOption = function updateOption(iChartOption, chartInstance) {
    // 是否显示坐标轴
    // 配置x轴
    this.baseOption.xAxis = xAxis(iChartOption)[0];
    if (iChartOption.axis && iChartOption.axis.show) {
      // 配置y轴
      this.baseOption.yAxis = yAxis(this.baseOption, iChartOption, CHART_TYPE.HILL);
    } else {
      this.baseOption.xAxis['axisLine'] = {
        show: false
      };
      this.baseOption.xAxis['axisTick'] = {
        show: false
      };
      this.baseOption.yAxis.show = false;
      // 配置标题
      this.baseOption.title = title(iChartOption, CHART_TYPE.HILL, iChartOption.yAxis && iChartOption.yAxis.nameTextStyle);
    }
    // 配置数据
    handleData(iChartOption, this.baseOption);
    // 配置山峰颜色及透明度
    handleColor(iChartOption, this.baseOption);
    // 配置文本
    handleText(iChartOption, this.baseOption);
    // 配置ChartPadding
    handlePadding(iChartOption, this.baseOption);
    // 配置相邻山峰间隔
    handleCoincide(iChartOption, this.baseOption);
    // 配置悬浮提示框
    this.baseOption.tooltip = tooltip(iChartOption, CHART_TYPE.HILL);
    this.baseOption.tooltip.trigger = 'item';
    // 配置渐变色
    setGradientColor(this.baseOption, iChartOption.color, iChartOption.gradientColor, iChartOption.opacity, iChartOption);
    // 配置阈值线
    handleMarkLine(this.baseOption, iChartOption);
    // 配置高亮状态
    handleEmphasis(this.baseOption, iChartOption);
    // 合并用户自定义series
    mergeSeries(iChartOption, this.baseOption);
  };
  _proto.getOption = function getOption() {
    return this.baseOption;
  };
  _proto.setOption = function setOption() {};
  return HillChart;
}();
_defineProperty(HillChart, "name", CHART_TYPE.HILL);
export { HillChart as default };
