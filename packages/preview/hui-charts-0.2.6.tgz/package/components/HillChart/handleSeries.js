function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import Token from '../../feature/token/index.js';
import merge from '../../util/merge.js';
import chartToken from './chartToken.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

/**
 * 配置山峰图高亮状态
 * @param {*} baseOpt
 * @param {*} iChartOpt
 */
var handleEmphasis = function handleEmphasis(baseOpt, iChartOpt) {
  var emphasis = iChartOpt.emphasis;
  var defaultEmphasis = {
    disabled: true,
    label: {
      // 为啥是蓝色待确定
      color: Token.config.colorState.colorInfo
    },
    itemStyle: {
      borderColor: chartToken.emphasisItemBorderColor,
      borderWidth: 2
    }
  };
  merge(defaultEmphasis, emphasis);
  baseOpt.series[0] = _extends({}, baseOpt.series[0], {
    emphasis: defaultEmphasis
  });
};
export { handleEmphasis };
