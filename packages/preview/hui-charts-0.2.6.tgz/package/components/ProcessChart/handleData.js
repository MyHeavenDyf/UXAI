function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import { CHARTTYPENAME } from './BaseOption.js';
import max from '../../util/sort/max.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
// 处理有minWidth极限值的情况下给echarts渲染的数据
function handleLimitVal(data, iChartOpt, demarcatedValue) {
  var dataItem = _extends({}, data, {
    _initValue: undefined
  });
  var minWidth = iChartOpt.minWidth;
  // 数据的最小宽度是一个百分比，用于控制数据之间差距过大导致部分数据显示不明显，导致无法交互的情况
  if (minWidth) {
    var limitValue = demarcatedValue * (parseInt(minWidth) / 100);
    if (data.value && data.value < limitValue) {
      dataItem.value = limitValue;
      dataItem._initValue = data.value;
    }
  }
  return dataItem;
}
function handleDoubleSideData(dataSet, data, iChartOpt, demarcatedValue) {
  data.forEach(function (item) {
    dataSet.seriesName.push(item.name);
    var childBarName = [];
    var childBarData = [];
    if (item.children && item.children.length !== 0) {
      item.children.forEach(function (el) {
        childBarName.push(el.name);
        var innerDataItem = handleLimitVal(el, iChartOpt, demarcatedValue);
        childBarData.push(innerDataItem);
      });
      dataSet.barName.push(childBarName);
      dataSet.barData.push(childBarData);
    }
  });
}
function handleBasicProcessData(iChartOpt, dataSet, data, doubleSide, dataMax) {
  // 内部显示进度的最大值
  var demarcatedValue = dataMax || 100;
  dataSet.maxValue = demarcatedValue;
  if (doubleSide) {
    handleDoubleSideData(dataSet, data, iChartOpt, demarcatedValue);
    return;
  }
  data.forEach(function (dataItem) {
    dataSet.barName.push(dataItem.name);
    var innerDataItem = handleLimitVal(dataItem, iChartOpt, demarcatedValue);
    dataSet.barData.push(innerDataItem);
  });
}
function getSerirsDataMax(dataSet, data, dataMax) {
  var sumValueMax;
  var sumValue = [];
  data.forEach(function (el) {
    var _sumValue = 0;
    el.children.forEach(function (child) {
      if (child.value) {
        _sumValue += child.value;
      }
    });
    sumValue.push(_sumValue);
  });
  sumValueMax = max(sumValue);
  if (dataMax && dataMax > sumValueMax) {
    sumValueMax = dataMax;
  }
  dataSet.maxValue = sumValueMax;
  dataSet.sumValue = sumValue;
}
function setMaxValueAgain(dataSet, dataMax) {
  var sum = [];
  var len = dataSet.seriesName.length;
  var _loop = function _loop(i) {
    var sumValue = 0;
    dataSet.barData.forEach(function (item) {
      if (item[i].value) {
        sumValue += item[i].value;
      }
    });
    sum.push(sumValue);
  };
  for (var i = 0; i < len; i++) {
    _loop(i);
  }
  var maxValue = max(sum);
  if (dataMax && dataMax > maxValue) {
    maxValue = dataMax;
  }
  dataSet.maxValue = maxValue;
}
function handleStackProcessData(iChartOpt, dataSet, data, dataMax) {
  // 获取系列名称
  data.forEach(function (element) {
    dataSet.seriesName.push(element.name);
  });
  // 单独系列名称
  data[0].children.forEach(function (el) {
    dataSet.barName.push(el.type);
  });
  // 单一系列各项数据用来获取数据的标定值
  getSerirsDataMax(dataSet, data, dataMax);
  // 对各系列数据进行组装分类
  dataSet.barName.forEach(function (type) {
    // 每个系列单独的数据
    var seriesData = [];
    data.forEach(function (child) {
      var childItem = child.children.find(function (el) {
        return el.type === type;
      });
      var innerChidItem = handleLimitVal(childItem, iChartOpt, dataSet.maxValue);
      seriesData.push(innerChidItem);
    });
    dataSet.barData.push(seriesData);
  });
  // 在有minwidth的情景下重新去计算所有系列求和的最大值
  if (iChartOpt.minWidth) {
    setMaxValueAgain(dataSet, dataMax);
  }
}
function handleData(iChartOpt, doubleSide) {
  var data = iChartOpt.data,
    name = iChartOpt.name;
  if (!data) return null;
  if (data && data.length > 0) {
    // 数据集合
    var dataSet = {
      // 图表子项数据
      barData: [],
      // 图表的标题数据
      barName: [],
      // 图表的最大值
      maxValue: undefined,
      // 图表的系列名称
      seriesName: []
    };
    // 当前图表单个系列数据的最大值，用来做数据占比
    var dataMax = iChartOpt.calibrationValue || iChartOpt.max;
    if (name === CHARTTYPENAME.ProcessBarChart) {
      handleBasicProcessData(iChartOpt, dataSet, data, doubleSide, dataMax);
    } else {
      handleStackProcessData(iChartOpt, dataSet, data, dataMax);
    }
    return dataSet;
  }
}
export { handleData as default };
