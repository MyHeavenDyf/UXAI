function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
import { BASICUNIT, SERIES_NAME, CHARTTYPENAME, getMarkLineSeries, getDataNameSeries, getBackgroundSeries, getDataSeries, getDoubleBackgroundSeries, getDoubleDataNameSeries } from './BaseOption.js';
import { getColor } from '../../util/color.js';
import merge from '../../util/merge.js';
import { getTextWidth } from '../../util/dom.js';
import chartToken from './chartToken.js';
import Token from '../../feature/token/index.js';
import { isString } from '../../util/type.js';
import { percentToDecimal } from '../../util/math.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

function setStateBarColor(data, stateList) {
  var min = stateList[0];
  var max = stateList[stateList.length - 1];
  var stateColorGroup = getThemeStateColorGroup();
  var successColor = stateColorGroup.success;
  // 最大值和最小值相等代表就一个值
  if (min.value === max.value) {
    var resState = min.state;
    return data < min.value ? successColor : stateColorGroup[resState];
  } else {
    if (data < min.value) {
      return successColor;
    }
    if (data > max.value) {
      var _resState = max.state;
      return stateColorGroup[_resState];
    }
    var len = stateList.length;
    var color;
    for (var i = 0; i < len; i++) {
      if (stateList[i].value >= data) {
        var index = i > 0 ? i - 1 : 0;
        var _resState2 = stateList[index].state;
        color = stateColorGroup[_resState2];
        break;
      }
    }
    return color;
  }
}
function getStateList(state) {
  // 值与状态对应数组
  var stateList = [];
  for (var k in state) {
    if (Object.hasOwnProperty.call(state, k)) {
      var stateItem = {
        state: k,
        value: state[k]
      };
      stateList.push(stateItem);
    }
  }
  stateList.sort(function (a, b) {
    return a.value - b.value;
  });
  return stateList;
}
function getBarColor(data, iChartOpt, index) {
  // dataGroup暂不对外放，使用之后常规进度图的柱子颜色应用一个颜色
  var state = iChartOpt.state,
    color = iChartOpt.color,
    _iChartOpt$dataGroup = iChartOpt.dataGroup,
    dataGroup = _iChartOpt$dataGroup === void 0 ? false : _iChartOpt$dataGroup;
  if (state) {
    var stateList = getStateList(state);
    return setStateBarColor(data, stateList);
  } else {
    return getColor(color, dataGroup ? 0 : index);
  }
}
function getMarkValue(value, dataSet) {
  if (!value) return dataSet.maxValue / 2;
  if (isString(value)) {
    return value.endsWith('%') ? dataSet.maxValue * percentToDecimal(value) : parseInt(value);
  }
  return value;
}
function getThemeStateColorGroup() {
  var _Token$config$colorSt = Token.config.colorState,
    colorError = _Token$config$colorSt.colorError,
    colorAlert = _Token$config$colorSt.colorAlert,
    colorWarning = _Token$config$colorSt.colorWarning,
    colorSuccess = _Token$config$colorSt.colorSuccess;
  var stateColorGroup = {
    error: colorError,
    warning: colorAlert,
    subwarning: colorWarning,
    success: colorSuccess
  };
  return stateColorGroup;
}
function getThemeStatusColor(status) {
  if (status === void 0) {
    status = 'success';
  }
  var stateColorGroup = getThemeStateColorGroup();
  return stateColorGroup[status];
}
function getMarkColor(dataItem, markVal, markLine) {
  var _dataItem$_initValue;
  var _markLine$status = markLine.status,
    status = _markLine$status === void 0 ? 'success' : _markLine$status,
    color = markLine.color;
  var data = (_dataItem$_initValue = dataItem._initValue) != null ? _dataItem$_initValue : dataItem.value;
  if (data && data > markVal) {
    return '#FFFFFF';
  }
  if (color) return color;
  var statusColor = getThemeStatusColor(status);
  return statusColor;
}
function setMarkLine(series, iChartOpt, dataSet, stack) {
  if (stack) return;
  var markLine = iChartOpt.markLine,
    barWidth = iChartOpt.barWidth;
  if (!markLine) return;
  var markSeries = getMarkLineSeries();
  var markValue = getMarkValue(markLine.value, dataSet);
  var data = dataSet.barData.map(function (item) {
    var markColor = getMarkColor(item, markValue, markLine);
    return {
      name: item.name,
      value: markValue,
      itemStyle: {
        color: markColor
      }
    };
  });
  if (barWidth) {
    markSeries.symbolSize = [2, barWidth / 2];
  }
  markSeries.data = data;
  series.push(markSeries);
}
function createPlaceholderArray(length, fillVal) {
  return new Array(length).fill(fillVal);
}
function setStackBgLabelFormatter(params, dataSet, iChartOpt) {
  // 系列名称为null不显示文本(数据缺省功能)
  var name = dataSet.seriesName[params.dataIndex];
  if (name === null || name === undefined) return '';
  // 兼容之前暴露的自定义右侧文本显示的功能，计划后期去除
  if (iChartOpt.text && iChartOpt.text.labelText) return iChartOpt.text.labelText[params.dataIndex];
  if (iChartOpt.unit) return "" + dataSet.sumValue[params.dataIndex] + iChartOpt.unit;
  return "" + dataSet.sumValue[params.dataIndex];
}
function setBgLabelFormatter(params, dataSet, iChartOpt, stack) {
  var _dataSet$barData$para;
  if (stack) return setStackBgLabelFormatter(params, dataSet, iChartOpt);
  var innerVal = (_dataSet$barData$para = dataSet.barData[params.dataIndex]._initValue) != null ? _dataSet$barData$para : dataSet.barData[params.dataIndex].value;
  if (innerVal === null || innerVal === undefined) return '';
  var innerUnit = iChartOpt.unit || iChartOpt.unit === '' ? iChartOpt.unit : BASICUNIT;
  return "" + innerVal + innerUnit;
}
function setText(bgSeries, dataSet, iChartOpt, stack) {
  if (iChartOpt.text) {
    merge(bgSeries.label, iChartOpt.text);
    var formatter = iChartOpt.text.formatter;
    if (stack) return;
    // 右侧为背景的lable为了让用户自定义的formatter获取的params获得中间数据的value去做了内部覆盖处理
    if (formatter) {
      bgSeries.label.formatter = function (params) {
        var _dataSet$barData$data;
        var dataIndex = params.dataIndex;
        var value = (_dataSet$barData$data = dataSet.barData[dataIndex]._initValue) != null ? _dataSet$barData$data : dataSet.barData[dataIndex].value;
        var inerParams = _extends({}, params, {
          value: value,
          data: value
        });
        return formatter(inerParams);
      };
    }
  }
}

// 设置占位用的数据名称和背景series
function setPlaceholderSeries(series, dataSet, iChartOpt, stack, eChartInstance) {
  var dataNumber = stack ? dataSet.seriesName.length : dataSet.barData.length;
  var nameSeries = getDataNameSeries(stack);
  nameSeries.data = createPlaceholderArray(dataNumber, 0);
  // 标题文本显示省略
  if (iChartOpt.title) merge(nameSeries.label, iChartOpt.title);
  var bgSeries = getBackgroundSeries(stack);
  bgSeries.data = createPlaceholderArray(dataNumber, dataSet.maxValue);
  bgSeries.label.formatter = function (params) {
    return setBgLabelFormatter(params, dataSet, iChartOpt, stack);
  };
  setNameSeriesWidth(nameSeries, dataSet, iChartOpt, eChartInstance);
  setText(bgSeries, dataSet, iChartOpt, stack);
  series.push(nameSeries);
  series.push(bgSeries);
}

// 设置name的宽度
function setNameSeriesWidth(nameSeries, dataSet, iChartOpt, eChartInstance) {
  var _iChartOpt$label, _eChartInstance$getMo, _eChartInstance$getMo2, _eChartInstance$getMo3, _eChartInstance$_dom, _iChartOpt$padding, _iChartOpt$padding2;
  // 用户设置了宽度 或者为双向进度图时跳出
  if ((_iChartOpt$label = iChartOpt.label) != null && _iChartOpt$label.width || iChartOpt.type === 'double-sides') return;
  var innerUnit = iChartOpt.unit || iChartOpt.unit === '' ? iChartOpt.unit : BASICUNIT;
  var maxLength = 0;
  dataSet.barData.forEach(function (item) {
    var val = item._initValue || item.value;
    var len = val ? val.toString().length : 0;
    if (len >= maxLength) maxLength = len;
  });
  var str = '8'.repeat(maxLength) + innerUnit; //使用数字8代替计算占宽
  var valueWidth = getTextWidth(str, 14);
  var instanceRect = eChartInstance.getModel == null ? void 0 : (_eChartInstance$getMo = eChartInstance.getModel()) == null ? void 0 : (_eChartInstance$getMo2 = _eChartInstance$getMo.getComponent('grid')) == null ? void 0 : (_eChartInstance$getMo3 = _eChartInstance$getMo2.coordinateSystem) == null ? void 0 : _eChartInstance$getMo3.getRect == null ? void 0 : _eChartInstance$getMo3.getRect();
  var domWidth = (instanceRect == null ? void 0 : instanceRect.width) || ((eChartInstance == null ? void 0 : eChartInstance.getWidth()) || (eChartInstance == null ? void 0 : (_eChartInstance$_dom = eChartInstance._dom) == null ? void 0 : _eChartInstance$_dom.clientWidth)) - ((iChartOpt == null ? void 0 : (_iChartOpt$padding = iChartOpt.padding) == null ? void 0 : _iChartOpt$padding[1]) || 0) - ((iChartOpt == null ? void 0 : (_iChartOpt$padding2 = iChartOpt.padding) == null ? void 0 : _iChartOpt$padding2[3]) || 0);
  var nameWidth = domWidth - valueWidth - 16; // 16为名称与数值之间的间隙
  nameSeries.label.width = nameWidth;
}
function setDataSeries(series, dataSet, iChartOpt, stack) {
  if (stack) {
    // 处理堆叠情况下图表的两端圆角情况,在数据项中加入圆角的配置
    setStackBordRadius(dataSet);
    dataSet.barData.forEach(function (item, index) {
      var unitSeries = getDataSeries(stack);
      unitSeries.data = item;
      unitSeries.itemStyle.borderRadius = undefined;
      unitSeries.itemStyle.borderWidth = chartToken.borderWidth;
      unitSeries.itemStyle.borderColor = chartToken.borderColor;
      unitSeries.itemStyle.color = getColor(iChartOpt.color, index);
      //堆叠柱状图需要重新赋值name
      unitSeries.name = dataSet.barName[index];
      unitSeries.stack = 'total';
      unitSeries.label.formatter = function (params) {
        var _params$data$_initVal;
        var value = (_params$data$_initVal = params.data._initValue) != null ? _params$data$_initVal : params.data.value;
        return value || '';
      };
      unitSeries.label.show = true;
      // 中间的图元的文本样式
      if (iChartOpt.label) merge(unitSeries.label, iChartOpt.label);
      series.push(unitSeries);
    });
    return;
  }
  var dataSeries = getDataSeries();
  dataSeries.data = dataSet.barData;
  dataSeries.itemStyle.color = function (params) {
    var _dataItem$_initValue2;
    var dataItem = dataSet.barData[params.dataIndex];
    var data = (_dataItem$_initValue2 = dataItem._initValue) != null ? _dataItem$_initValue2 : dataItem.value;
    return getBarColor(data, iChartOpt, params.dataIndex);
  };
  series.push(dataSeries);
}
function setStackBordRadius(dataSet) {
  var barData = dataSet.barData,
    seriesName = dataSet.seriesName;
  var borderRadius = chartToken.borderRadius;
  // 每行的总数据
  var total = [];
  var _loop = function _loop(row) {
    var rowData = [];
    barData.forEach(function (item, col) {
      if (item[row].value) {
        var dataInfo = {
          col: col,
          row: row,
          value: item[row].value
        };
        rowData.push(dataInfo);
      }
    });
    total.push(rowData);
  };
  for (var row = 0; row < seriesName.length; row++) {
    _loop(row);
  }
  total.forEach(function (to) {
    var tolen = to.length;
    if (tolen !== 0) {
      // 每行只有一个有效数据
      if (tolen === 1) {
        barData[to[0].col][to[0].row] = _extends({}, barData[to[0].col][to[0].row], {
          value: barData[to[0].col][to[0].row].value,
          itemStyle: {
            borderRadius: borderRadius
          }
        });
      } else {
        barData[to[0].col][to[0].row] = _extends({}, barData[to[0].col][to[0].row], {
          value: barData[to[0].col][to[0].row].value,
          itemStyle: {
            borderRadius: [borderRadius, 0, 0, borderRadius]
          }
        });
        barData[to[to.length - 1].col][to[to.length - 1].row] = _extends({}, barData[to[to.length - 1].col][to[to.length - 1].row], {
          value: barData[to[to.length - 1].col][to[to.length - 1].row].value,
          itemStyle: {
            borderRadius: [0, borderRadius, borderRadius, 0]
          }
        });
      }
    }
  });
}
function handleDoubleLabel(params, iChartOpt, dataSet, index) {
  var name = params.name,
    dataIndex = params.dataIndex;
  var innerVal = dataSet.barData[index][dataIndex]._initValue || dataSet.barData[index][dataIndex].value;
  if (innerVal === null || innerVal === undefined) return '';
  var innerUnit = iChartOpt.unit || iChartOpt.unit === '' ? iChartOpt.unit : BASICUNIT;
  var val = "" + innerVal + innerUnit;
  return "{name|" + name + "}\n{value|" + val + "}";
}
function getMaxValLength(dataSet, iChartOpt, index) {
  var maxLength = 0;
  var innerUnit = iChartOpt.unit || iChartOpt.unit === '' ? iChartOpt.unit : BASICUNIT;
  dataSet.barData[index].forEach(function (item) {
    var val = "" + (item._initValue || item.value) + innerUnit;
    var len = getTextWidth(val, 14);
    if (len >= maxLength) maxLength = len;
  });
  return maxLength;
}
function setBarWidth(baseOpt, iChartOpt) {
  var barWidth = iChartOpt.barWidth;
  if (barWidth) {
    baseOpt.series.forEach(function (serie) {
      if (serie.name === SERIES_NAME.markLine) {
        serie.symbolSize = [2, barWidth / 2];
      } else {
        serie.barWidth = barWidth;
      }
    });
  }
}
function setDoublePlaceholderSeries(series, dataSet, iChartOpt, left, index) {
  var bgSeries = getDoubleBackgroundSeries(left);
  bgSeries.data = createPlaceholderArray(dataSet.barData[index].length, dataSet.maxValue);
  bgSeries.label.formatter = function (params) {
    return handleDoubleLabel(params, iChartOpt, dataSet, index);
  };
  var coefficent = left ? -1 : 1;
  var valWidth = getMaxValLength(dataSet, iChartOpt, index) * coefficent;
  var offsetX = valWidth + 10 * coefficent;
  bgSeries.label.offset = [offsetX, 9];
  series.push(bgSeries);
}
function setDoubleDataSeries(series, dataSet, iChartOpt, left, index) {
  var dataSeries = getDoubleDataNameSeries(left);
  dataSeries.data = dataSet.barData[index];
  dataSeries.name = dataSet.seriesName[index];
  dataSeries.itemStyle.color = getColor(iChartOpt.color, index);
  series.push(dataSeries);
}
function setDoubleSideSeries(series, iChartOpt, dataSet) {
  dataSet.seriesName.forEach(function (item, itemIndex) {
    var left = itemIndex % 2 === 0;
    setDoublePlaceholderSeries(series, dataSet, iChartOpt, left, itemIndex);
    setDoubleDataSeries(series, dataSet, iChartOpt, left, itemIndex);
  });
}
function setCommonSeries(series, iChartOpt, dataSet, eChartInstance) {
  var stack = iChartOpt.name === CHARTTYPENAME.StackProcessBarChart;
  setPlaceholderSeries(series, dataSet, iChartOpt, stack, eChartInstance);
  setDataSeries(series, dataSet, iChartOpt, stack);
  setMarkLine(series, iChartOpt, dataSet, stack);
}
function handleSeries(baseOpt, iChartOpt, dataSet, doubleSide, eChartInstance) {
  var series = [];
  doubleSide ? setDoubleSideSeries(series, iChartOpt, dataSet) : setCommonSeries(series, iChartOpt, dataSet, eChartInstance);
  baseOpt.series = series;
  setBarWidth(baseOpt, iChartOpt);
}
export { handleSeries as default, getBarColor, getStateList, setNameSeriesWidth, setStateBarColor };
