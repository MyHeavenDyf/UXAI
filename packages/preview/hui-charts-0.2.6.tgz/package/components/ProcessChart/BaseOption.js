import chartToken from './chartToken.js';
import base$1 from '../../option/config/yAxis/base.js';
import base from '../../option/config/xAxis/base.js';
import merge from '../../util/merge.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 进度图的图表类型名称
var CHARTTYPENAME = {
  ProcessBarChart: 'ProcessBarChart',
  StackProcessBarChart: 'StackProcessBarChart'
};
// 标识是否为双向进度图
var PROCESSBARTYPE = 'double-sides';
// 基础进度图的默认单位
var BASICUNIT = '%';
var SERIES_NAME = {
  markLine: 'markLine',
  background: 'background',
  seriesName: 'seriesName'
};
function getBarWidth(stack) {
  return stack ? chartToken.stackBarWidth : chartToken.barWidth;
}

// 文本与柱子居中对齐，文本与柱子的间距8（行高一半4+间距4）
function getOffsetY() {
  return chartToken.fontSize + 4; //默认是8
}

// 进度图数据名称的series
function getDataNameSeries(stack) {
  if (stack === void 0) {
    stack = false;
  }
  var barWidth = getBarWidth(stack);
  var offset = getOffsetY();
  return {
    // 用来做前面的文本显示
    name: SERIES_NAME.seriesName,
    type: 'bar',
    barWidth: barWidth,
    barGap: '-100%',
    // 这条series不响应鼠标事件
    silent: true,
    label: {
      show: true,
      color: chartToken.nameColor,
      position: [0, -offset],
      fontSize: chartToken.fontSize,
      overflow: 'truncate',
      formatter: function formatter(params) {
        return params.name === 'null' || params.name === 'undefined' ? '' : params.name;
      }
    },
    data: undefined
  };
}
// 进度图背景柱子的series
function getBackgroundSeries(stack) {
  if (stack === void 0) {
    stack = false;
  }
  var barWidth = getBarWidth(stack);
  var offset = getOffsetY();
  return {
    // 底色 +右侧label文本显示
    name: SERIES_NAME.background,
    type: 'bar',
    barWidth: barWidth,
    barGap: '-100%',
    itemStyle: {
      color: chartToken.itemBgEmpty,
      borderRadius: chartToken.borderRadius
    },
    cursor: 'auto',
    emphasis: {
      disabled: true
    },
    label: {
      distance: 0,
      show: true,
      color: chartToken.labelColor,
      offset: [0, -offset],
      position: 'insideTopRight',
      fontSize: chartToken.fontSize,
      formatter: undefined
    },
    data: undefined
  };
}

// 用于显示基础进度图的实际数据的series
function getDataSeries(stack) {
  if (stack === void 0) {
    stack = false;
  }
  var barWidth = getBarWidth(stack);
  return {
    name: 'data',
    type: 'bar',
    zlevel: 2,
    barWidth: barWidth,
    cursor: 'pointer',
    itemStyle: {
      borderRadius: chartToken.borderRadius,
      color: undefined
    },
    data: undefined,
    label: {
      distance: 0,
      show: false,
      fontSize: chartToken.labelFontSize,
      color: chartToken.labelColor,
      formatter: undefined
    }
  };
}
function getDoubleBackgroundSeries(left) {
  if (left === void 0) {
    left = true;
  }
  return {
    // 左侧底色
    name: SERIES_NAME.background,
    type: 'bar',
    xAxisIndex: left ? 0 : 1,
    yAxisIndex: left ? 0 : 1,
    barWidth: chartToken.barWidth,
    barGap: '-100%',
    itemStyle: {
      color: chartToken.itemBgEmpty,
      borderRadius: left ? [chartToken.borderRadius, 0, 0, chartToken.borderRadius] : [0, chartToken.borderRadius, chartToken.borderRadius, 0]
    },
    emphasis: {
      disabled: true
    },
    label: {
      show: true,
      offset: [0, 0],
      position: left ? 'insideBottomLeft' : 'insideBottomRight',
      formatter: undefined,
      rich: {
        name: {
          fontSize: chartToken.fontSize,
          color: chartToken.nameColor,
          lineHeight: 14,
          padding: [0, 0, 20, 0]
        },
        value: {
          fontSize: chartToken.fontSize,
          color: chartToken.labelColor,
          fontWeight: 'bold',
          align: left ? 'left' : 'right'
        }
      }
    },
    data: undefined
  };
}
function getDoubleDataNameSeries(left) {
  if (left === void 0) {
    left = true;
  }
  return {
    name: undefined,
    xAxisIndex: left ? 0 : 1,
    yAxisIndex: left ? 0 : 1,
    type: 'bar',
    zlevel: 2,
    barWidth: chartToken.barWidth,
    itemStyle: {
      borderRadius: left ? [chartToken.borderRadius, 0, 0, chartToken.borderRadius] : [0, chartToken.borderRadius, chartToken.borderRadius, 0],
      color: undefined
    },
    data: undefined,
    emphasis: {
      disabled: true
    },
    label: {
      show: false
    }
  };
}
function getDoubleXaxis() {
  var left = base();
  var extraLeft = {
    type: 'value',
    gridIndex: 0,
    inverse: true,
    axisLabel: {
      show: false
    },
    splitLine: {
      show: true
    },
    max: 'dataMax'
  };
  merge(left, extraLeft);
  var right = base();
  var extraRight = {
    type: 'value',
    gridIndex: 1,
    axisLabel: {
      show: false
    },
    splitLine: {
      show: true
    },
    max: 'dataMax'
  };
  merge(right, extraRight);
  return [left, right];
}
function getDoubleYaxis() {
  var left = base$1();
  var extraLeft = {
    type: 'category',
    gridIndex: 0,
    inverse: true,
    axisLabel: {
      show: false
    },
    splitLine: {
      show: false
    },
    axisLine: {
      show: true
    },
    position: 'right',
    data: undefined
  };
  merge(left, extraLeft);
  var right = base$1();
  var extraRight = {
    type: 'category',
    gridIndex: 1,
    show: false,
    inverse: true,
    data: undefined
  };
  merge(right, extraRight);
  return [left, right];
}
function getDoubleGrid() {
  return [
  // 左边的坐标系
  {
    left: '4%',
    width: '46%',
    top: 0,
    bottom: 0,
    containLabel: false
  },
  // 右边的坐标系
  {
    right: '4%',
    width: '46%',
    top: 0,
    bottom: 0,
    containLabel: false
  }];
}

// 标线的series
function getMarkLineSeries() {
  return {
    type: 'scatter',
    symbol: 'roundRect',
    name: SERIES_NAME.markLine,
    silent: true,
    symbolSize: [2, chartToken.barWidth / 2],
    zlevel: 999,
    data: undefined,
    color: undefined
  };
}
export { BASICUNIT, CHARTTYPENAME, PROCESSBARTYPE, SERIES_NAME, getBackgroundSeries, getDataNameSeries, getDataSeries, getDoubleBackgroundSeries, getDoubleDataNameSeries, getDoubleGrid, getDoubleXaxis, getDoubleYaxis, getMarkLineSeries };
