import Node from './Node.js';
import { renderSvgDom } from './util.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var Manager = /*#__PURE__*/function () {
  function Manager(svgContainer, nodeContainer, config, initalData) {
    // svg容器
    this.svgContainer = void 0;
    // 节点的容器
    this.nodeContainer = void 0;
    //   配置项
    this.config = void 0;
    //  节点数据
    this.initalData = void 0;
    //   河流节点
    this.nodes = void 0;
    //   连接带节点
    this.belts = void 0;
    // 数据是否合法
    this.legal = true;
    // svg节点容器
    this.svgNodeGroup = void 0;
    // svg渐变色容器
    this.svgNodeGradientDefs = void 0;
    // svg连接带容器
    this.svgBeltPathGroup = void 0;
    // svg连接带渐变色容器
    this.svgBeltGradientDefs = void 0;
    this.svgContainer = svgContainer;
    this.nodeContainer = nodeContainer;
    this.config = config;
    this.initalData = initalData;
    this.nodes = [];
    this.belts = [];
    this.checkInitalData();
    this.initSvgGroupContainer();
  }
  var _proto = Manager.prototype;
  _proto.initSvgGroupContainer = function initSvgGroupContainer() {
    if (!this.legal) return;
    // 节点组
    var nodeGroup = renderSvgDom('g', {
      id: 'rc_nodeGroup'
    });
    // 用来包裹path的组
    var pathGroup = renderSvgDom('g', {
      id: 'rc_pathGroup'
    });
    // 用来包裹node渐变色的组
    var nodeGradientGroup = renderSvgDom('g', {
      id: 'rc_nodeGradientGroup'
    });
    // 用来包裹link渐变色的组
    var linkGradientGroup = renderSvgDom('g', {
      id: 'rc_linkGradientGroup'
    });
    // 放置node渐变色def
    var nodeGradientDefs = renderSvgDom('defs');
    // 放置link渐变色def
    var linkGradientDefs = renderSvgDom('defs');
    nodeGradientGroup.appendChild(nodeGradientDefs);
    linkGradientGroup.appendChild(linkGradientDefs);
    this.svgContainer.appendChild(nodeGroup);
    this.svgContainer.appendChild(pathGroup);
    this.svgContainer.appendChild(nodeGradientGroup);
    this.svgContainer.appendChild(linkGradientGroup);
    this.svgNodeGroup = nodeGroup;
    this.svgNodeGradientDefs = nodeGradientDefs;
    this.svgBeltPathGroup = pathGroup;
    this.svgBeltGradientDefs = linkGradientDefs;
  }

  // 检查数据是否合规
;
  _proto.checkInitalData = function checkInitalData() {
    if (!this.initalData) return this.legal = false;
    var _this$initalData = this.initalData,
      nodes = _this$initalData.nodes,
      links = _this$initalData.links;
    if (!nodes || !links) return this.legal = false;
    if (nodes && nodes.length === 0 || links && links.length === 0) this.legal = false;
  };
  _proto.createNode = function createNode(initialNode) {
    return new Node(initialNode, this.config, this.initalData, this.belts);
  };
  _proto.addNode = function addNode(node) {
    this.nodes.push(node);
  };
  _proto.findInitalNode = function findInitalNode(name) {
    return this.initalData.nodes.find(function (item) {
      return item.name === name;
    });
  };
  _proto.findNode = function findNode(name) {
    return this.nodes.find(function (item) {
      return item.name === name;
    });
  }

  // 检查节点是否已存在this.nodes,没有就新建节点
;
  _proto.checkNodeExist = function checkNodeExist(name, initalNode) {
    var targetNode = this.findNode(name);
    if (!targetNode) {
      var initNode = initalNode ? initalNode : this.findInitalNode(name);
      var newNode = this.createNode(initNode);
      this.addNode(newNode);
      targetNode = newNode;
    }
    return targetNode;
  }

  // 增加节点的依赖关系
;
  _proto.addNodeDependency = function addNodeDependency(dependency, node, isParent) {
    var _this = this;
    if (isParent === void 0) {
      isParent = true;
    }
    if (dependency && dependency.length > 0) {
      dependency.forEach(function (name) {
        var targetNode = _this.checkNodeExist(name);
        isParent ? node.setParent(targetNode) : node.setChildren(targetNode);
      });
    }
  };
  _proto.addNodeParent = function addNodeParent(parentName, node) {
    this.addNodeDependency(parentName, node);
  };
  _proto.addNodeChildren = function addNodeChildren(childrenName, node) {
    this.addNodeDependency(childrenName, node, false);
  };
  _proto.init = function init() {
    if (!this.legal) return;
    this.initNodes();
    this.initBelts();
  };
  _proto.initNodes = function initNodes() {
    var _this2 = this;
    this.initalData.nodes.forEach(function (initialNode) {
      var node = _this2.checkNodeExist(initialNode.name, initialNode);
      var parentName = [];
      var childrenName = [];
      _this2.initalData.links.forEach(function (link) {
        if (link.target === initialNode.name) {
          parentName.push(link.source);
        }
        if (link.source === initialNode.name) {
          childrenName.push(link.target);
        }
      });
      _this2.addNodeParent(parentName, node);
      _this2.addNodeChildren(childrenName, node);
    });
  };
  _proto.initBelts = function initBelts() {
    this.nodes.forEach(function (node) {
      node.initBelts();
    });
  };
  _proto.renderNodes = function renderNodes() {
    var _this3 = this;
    this.nodes.forEach(function (node) {
      return node.render(_this3.nodeContainer, _this3.svgNodeGroup, _this3.svgNodeGradientDefs);
    });
  };
  _proto.renderBelts = function renderBelts() {
    var _this4 = this;
    this.belts.forEach(function (belt) {
      return belt.render(_this4.svgBeltPathGroup, _this4.svgBeltGradientDefs);
    });
  }

  // 绘制节点和连接带
;
  _proto.render = function render() {
    this.renderNodes();
    this.renderBelts();
  };
  return Manager;
}();
export { Manager as default };
