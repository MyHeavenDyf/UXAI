function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import baseOption from './baseOption.js';
import Manager from './Manager.js';
import { initWrapper, setChartSize } from './util.js';
import { CHART_TYPE } from '../../util/constants.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var RiverChart = /*#__PURE__*/function () {
  function RiverChart() {
    // 配置项
    this.option = {};
    // 整个图表容器
    this.container = null;
    // 图表的外层wrapper
    this.wrapper = null;
    // 节点的容器
    this.nodeContainer = null;
    // svg容器
    this.svgElement = null;
    // 图表容器大小
    this.containerSize = {
      width: 0,
      height: 0
    };
    this.manager = null;
  }
  var _proto = RiverChart.prototype;
  // 初始化
  _proto.init = function init(container) {
    this.container = container;
    this.beforeRender();
    var _this = this;
    initWrapper(this.container, _this);
    // 算出容器的大小
    var size = container.getBoundingClientRect();
    this.containerSize.width = size.width;
    this.containerSize.height = size.height;
  };
  _proto.beforeRender = function beforeRender() {
    // 刷新图表的时候清空内部的节点
    if (this.container) this.container.innerHTML = '';
  }

  // 设置图表的配置项
;
  _proto.setOption = function setOption(option) {
    this.option = Object.assign(baseOption(), option);
    setChartSize(this.svgElement, this.nodeContainer, this.option);
    if (this.svgElement) this.svgElement.innerHTML = '';
    if (this.nodeContainer) this.nodeContainer.innerHTML = '';
    this.render();
  };
  _proto.render = function render() {
    var _this$option = this.option,
      data = _this$option.data,
      width = _this$option.width;
    if (!width) {
      this.option.width = this.containerSize.width;
      this.option.height = this.containerSize.height;
    }
    this.manager = new Manager(this.svgElement, this.nodeContainer, this.option, data);
    this.manager.init();
    this.manager.render();
  };
  _proto.destory = function destory() {
    this.container.innerHTML = '';
    this.manager = null;
  };
  return RiverChart;
}();
_defineProperty(RiverChart, "name", CHART_TYPE.RIVER);
export { RiverChart as default };
