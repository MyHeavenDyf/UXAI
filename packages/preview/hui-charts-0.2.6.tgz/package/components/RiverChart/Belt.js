import { renderSvgDom, getSmoothPathD, getPathD } from './util.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

// 河流的连接带
var Belt = /*#__PURE__*/function () {
  function Belt(node, config, isLeft) {
    // 连接带的名字
    this.name = void 0;
    //  起点信息
    this.start = void 0;
    // 终点信息
    this.end = void 0;
    // 当前连接带的位置
    this.isLeft = void 0;
    this.颜色 = void 0;
    this.color = void 0;
    // 归属节点是否有子节点
    this.hasNodes = void 0;
    // 图表配置
    this.config = void 0;
    // 归属节点
    this.belongNode = void 0;
    this.belongNode = node;
    this.config = config;
    this.isLeft = isLeft;
    this.hasNodes = !!(node.initalNode.nodes && node.initalNode.nodes.length > 0);
  }
  var _proto = Belt.prototype;
  _proto.init = function init(name, start, end) {
    this.setName(name);
    this.setStart(start);
    this.setEnd(end);
  };
  _proto.setName = function setName(name) {
    this.name = name;
  };
  _proto.setStart = function setStart(start) {
    this.start = start;
  };
  _proto.setEnd = function setEnd(end) {
    this.end = end;
  }

  //  当前的belongNode没有父子节点，颜色取决于当前belongNode.nodes的首尾node颜色
;
  _proto.setCommonColor = function setCommonColor() {
    var _this$config = this.config,
      statusColor = _this$config.statusColor,
      background = _this$config.background;
    var color = background;
    if (this.hasNodes) {
      var len = this.belongNode.initalNode.nodes.length;
      var itemNode = this.isLeft ? this.belongNode.initalNode.nodes[0] : this.belongNode.initalNode.nodes[len - 1];
      color = statusColor[itemNode.status];
    }
    this.color = color;
  };
  _proto.setGradientColor = function setGradientColor(parentNode) {
    var _this$config2 = this.config,
      statusColor = _this$config2.statusColor,
      background = _this$config2.background;
    var colorList = [];
    var initalNode = this.belongNode.initalNode;
    var startColor = background,
      endColor = background;
    if (initalNode.nodes && initalNode.nodes.length !== 0) {
      var itemNode = initalNode.nodes[0];
      endColor = statusColor[itemNode.status];
    }
    var parentInitalNode = parentNode.initalNode;
    if (parentInitalNode.nodes && parentInitalNode.nodes.length !== 0) {
      var len = parentInitalNode.nodes.length;
      var _itemNode = parentInitalNode.nodes[len - 1];
      startColor = statusColor[_itemNode.status];
    }
    var start = {
      percent: '0%',
      color: startColor
    };
    var end = {
      percent: '100%',
      color: endColor
    };
    colorList.push(start);
    colorList.push(end);
    this.color = colorList;
  };
  _proto.getBeltPoint = function getBeltPoint(startLen) {
    var endLen = this.end.value;
    // 绘画的坐标点
    var point;
    if (this.config.smoothingCurves) {
      point = {
        // 连线的起点
        x1: this.start.x,
        y1: this.start.y + startLen / 2,
        // 连线的终点
        x3: this.end.x,
        y3: this.end.y + endLen / 2
      };
    } else {
      point = {
        // 前置节点起点坐标
        x1: this.start.x,
        y1: this.start.y,
        // 前置节点终点坐标
        x2: this.start.x,
        y2: this.start.y + startLen,
        // 后置节点终点坐标
        x3: this.end.x,
        y3: this.end.y,
        // 后置节点终点坐标
        x4: this.end.x,
        y4: this.end.y + endLen
      };
    }
    return point;
  };
  _proto.getLinearGradientfillColor = function getLinearGradientfillColor(svgBeltGradientDefs) {
    // 渐变的属性
    var lineGradientAttributes = {
      id: "linearGradient_" + this.name + "_node",
      x2: '100%',
      y2: '0%',
      x1: '0%',
      y1: '0%'
    };
    var lineGradientDom = renderSvgDom('linearGradient', lineGradientAttributes);
    // 生成stop
    this.color.forEach(function (el) {
      var stopAttributes = {
        offset: el.percent,
        'stop-opacity': 0.2,
        'stop-color': el.color
      };
      var stopDom = renderSvgDom('stop', stopAttributes);
      lineGradientDom.appendChild(stopDom);
    });
    svgBeltGradientDefs.appendChild(lineGradientDom);
    return "url(#linearGradient_" + this.name + "_node)";
  };
  _proto.render = function render(svgBeltPathGroup, svgBeltGradientDefs) {
    var startLen = this.start.value;
    var smoothingCurves = this.config.smoothingCurves;
    var point = this.getBeltPoint(startLen);
    // 获取路径
    var path = smoothingCurves ? getSmoothPathD(point, startLen) : getPathD(point);
    var isNotgarident = typeof this.color === 'string';
    var fillColor = this.color;
    if (!isNotgarident) {
      fillColor = this.getLinearGradientfillColor(svgBeltGradientDefs);
    }
    // 不是渐变色
    var pathAttributes = {
      id: "link_" + this.name + "_" + (this.isLeft ? 'left' : 'right'),
      fill: fillColor,
      d: path,
      opacity: isNotgarident ? 0.2 : 1
    };
    if (smoothingCurves && !(point.y1 === point.y3)) {
      pathAttributes['fill'] = 'none';
      pathAttributes['stroke'] = fillColor;
      pathAttributes['stroke-width'] = startLen;
    }
    var pathDom = renderSvgDom('path', pathAttributes);
    svgBeltPathGroup.appendChild(pathDom);
  };
  return Belt;
}();
export { Belt as default };
