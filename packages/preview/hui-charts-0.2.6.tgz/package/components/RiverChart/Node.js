import { createEl, addClass, setStyle, renderSvgDom } from './util.js';
import Belt from './Belt.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
// 河流的节点
var Node = /*#__PURE__*/function () {
  function Node(initalNode, config, initaData, belts) {
    // 节点的初始数据
    this.initalNode = void 0;
    // 节点名称
    this.name = void 0;
    // 节点的取值
    this.value = void 0;
    // 节点所在的行
    this.row = void 0;
    // 节点所在的列
    this.col = void 0;
    // 节点的配置
    this.config = void 0;
    //   节点的父节点
    this.parent = null;
    //   节点的子节点
    this.children = null;
    //   节点的x坐标
    this.x = 0;
    //   节点的y坐标
    this.y = 0;
    //   节点的宽
    this.width = 0;
    //   节点的高
    this.height = 0;
    //   节点的颜色
    this.color = void 0;
    //   节点的前后间距
    this.margin = void 0;
    //   连接带的集合
    this.belts = void 0;
    //   连接的子节点
    this.childLink = null;
    //   连接的父节点
    this.parentLink = null;
    this.belts = belts;
    this.initalNode = initalNode;
    this.config = config;
    this.links = initaData.links;
    this.name = initalNode.name;
    this.value = initalNode.value;
    this.row = initalNode.row;
    this.col = initalNode.col;
    this.margin = config.marginWidth[this.col];
    this.setColor();
    this.setPosition(initaData.nodes);
  }

  // 初次属性赋值
  var _proto = Node.prototype;
  _proto.initPorperty = function initPorperty(propertyName, value) {
    if (!this[propertyName]) this[propertyName] = value;
  }

  // 增加节点的父子节点
;
  _proto.addPorpertyValue = function addPorpertyValue(node, propertyName) {
    this.initPorperty(propertyName, []);
    this[propertyName].push(node);
  };
  _proto.setParent = function setParent(node) {
    this.addPorpertyValue(node, 'parent');
  };
  _proto.setChildren = function setChildren(node) {
    this.addPorpertyValue(node, 'children');
  }

  // 获取列的起始坐标
;
  _proto.getColStart = function getColStart(col) {
    var _this$config = this.config,
      width = _this$config.width,
      depthWidth = _this$config.depthWidth;
    // 将百分比转换为相应的数字比例
    var depthWidthNumber = depthWidth.map(function (item) {
      return parseInt(item) / 100;
    });
    // 获取当前的起点
    var depthWidthPercent = depthWidthNumber.slice(0, col).reduce(function (pre, cur) {
      return pre + cur;
    }, 0);
    return depthWidthPercent * width;
  }

  // 找出在同一列的节点
;
  _proto.getColNodes = function getColNodes(initalNodes) {
    var _this = this;
    return initalNodes.filter(function (node) {
      return node.col === _this.col;
    });
  };
  _proto.getX = function getX() {
    var colStart = this.getColStart(this.col);
    var x = colStart + this.margin.left;
    return x;
  };
  _proto.getY = function getY(colNodes) {
    var _this2 = this;
    var _this$config2 = this.config,
      nodeSpace = _this$config2.nodeSpace,
      scaleBar = _this$config2.scaleBar,
      offsetY = _this$config2.offsetY;
    var nodes = colNodes.filter(function (node) {
      return node.row < _this2.row;
    });
    var totalVal = nodes.reduce(function (pre, cur) {
      return pre + cur.value;
    }, 0);
    var y = nodeSpace * this.row + totalVal * scaleBar + offsetY;
    return y;
  };
  _proto.getWidth = function getWidth(x) {
    var space = this.config.space;
    var nextColStart = this.getColStart(this.col + 1);
    var width = nextColStart - space - this.margin.right - x;
    return width;
  };
  _proto.setColor = function setColor() {
    var _this$config3 = this.config,
      statusColor = _this$config3.statusColor,
      background = _this$config3.background;
    var nodes = this.initalNode.nodes;
    if (!nodes || nodes && nodes.length === 0) {
      this.color = background;
      return;
    }
    var length = nodes.length;
    var colors = [];
    var startColor = statusColor[nodes[0].status];
    var colorStart = {
      percent: '0%',
      color: startColor
    };
    colors.push(colorStart);
    if (length - 2 > 0) {
      var step = Math.round(100 / (length - 1));
      for (var i = 0; i < length - 2; i++) {
        var itemNodeColor = statusColor[nodes[i + 1].status];
        var offset = step * (i + 1);
        var colorItemData = {
          percent: offset + "%",
          color: itemNodeColor
        };
        colors.push(colorItemData);
      }
    }
    var EndColor = statusColor[nodes[length - 1].status];
    var colorEnd = {
      percent: '100%',
      color: EndColor
    };
    colors.push(colorEnd);
    this.color = colors;
  };
  _proto.setPosition = function setPosition(initalNodes) {
    var scaleBar = this.config.scaleBar;
    var colNodes = this.getColNodes(initalNodes);
    var x = this.getX();
    var y = this.getY(colNodes);
    var nodeWidth = this.getWidth(x);
    var height = scaleBar * this.value;
    this.x = x;
    this.y = y;
    this.width = nodeWidth;
    this.height = height;
  }
  // 生成node的dom节点
;
  _proto.renderDom = function renderDom(nodeContainer) {
    // 公共的render方法
    var renderPar = this.config.render;
    // 节点的render方法
    var render = this.initalNode.render;
    var nodeEl = createEl('div');
    addClass(nodeEl, ['rc_node', this.name]);
    setStyle(nodeEl, 'left', this.x + "px");
    setStyle(nodeEl, 'top', this.y + "px");
    setStyle(nodeEl, 'width', this.width + "px");
    setStyle(nodeEl, 'height', this.height + "px");
    var renderFn = render || renderPar;
    if (renderFn) {
      var customNode = renderFn(this);
      if (customNode) nodeEl.appendChild(customNode);
    }
    nodeContainer.appendChild(nodeEl);
  };
  _proto.renderSvg = function renderSvg(svgNodeGroup, svgNodeGradientDefs) {
    var _this$config4 = this.config,
      background = _this$config4.background,
      scaleBar = _this$config4.scaleBar;
    var fillColor = background;
    var isNotgarident = typeof this.color === 'string';
    if (!isNotgarident) {
      // 渐变的属性
      var lineGradientAttributes = {
        id: "linearGradient_" + this.name + "_node",
        x1: '0%',
        y1: '0%',
        x2: '100%',
        y2: '0%'
      };
      var lineGradientDom = renderSvgDom('linearGradient', lineGradientAttributes);
      // 生成stop
      this.color.forEach(function (el) {
        var stopAttributes = {
          offset: el.percent,
          'stop-color': el.color,
          'stop-opacity': 0.2
        };
        var stopDom = renderSvgDom('stop', stopAttributes);
        lineGradientDom.appendChild(stopDom);
      });
      svgNodeGradientDefs.appendChild(lineGradientDom);
      fillColor = "url(#linearGradient_" + this.name + "_node)";
    }
    var nodeAttributes = {
      x: this.x,
      y: this.y,
      width: this.width,
      height: this.value * scaleBar,
      fill: fillColor,
      opacity: isNotgarident ? 0.2 : 1
    };
    var nodeRect = renderSvgDom('rect', nodeAttributes);
    svgNodeGroup.appendChild(nodeRect);
  };
  _proto.render = function render(nodeContainer, svgNodeGroup, svgNodeGradientDefs) {
    this.renderDom(nodeContainer);
    this.renderSvg(svgNodeGroup, svgNodeGradientDefs);
  }
  //   获取节点之间连接的值
;
  _proto.getLinkVal = function getLinkVal(parName, childName) {
    var val = 0;
    this.links.forEach(function (item) {
      if (item.source === parName && item.target === childName) {
        val = item.value;
      }
    });
    return val;
  };
  _proto.creatBelt = function creatBelt(node, isLeft) {
    if (isLeft === void 0) {
      isLeft = true;
    }
    return new Belt(node, this.config, isLeft);
  };
  _proto.addBelt = function addBelt(belt) {
    this.belts.push(belt);
  }

  //  自身的连接带
;
  _proto.addSelfBelt = function addSelfBelt(isLeft, isLast) {
    if (isLeft === void 0) {
      isLeft = true;
    }
    if (isLast === void 0) {
      isLast = true;
    }
    var selfBelt = this.creatBelt(this, isLeft);
    var name = this.name + "_" + (isLeft ? 'l' : 'r');
    var startX = isLeft ? this.x - this.margin.left : this.x + this.width;
    var start = {
      x: startX,
      y: this.y,
      value: this.height
    };
    var lastSpace = isLast ? 0 : this.config.space;
    var endX = isLeft ? this.x : this.x + this.width + this.margin.right - lastSpace;
    var end = {
      x: endX,
      y: this.y,
      value: this.height
    };
    selfBelt.init(name, start, end);
    selfBelt.setCommonColor();
    this.addBelt(selfBelt);
  };
  _proto.initLink = function initLink(name) {
    this.initPorperty(name, []);
  };
  _proto.addLink = function addLink(name, node) {
    this[name].push(node);
  };
  _proto.getTotalLinkValue = function getTotalLinkValue(linkValue) {
    return linkValue.reduce(function (cur, pre) {
      return cur + pre.height;
    }, 0);
  }

  //   连接到父节点的连接带
;
  _proto.addParentBelt = function addParentBelt(islast) {
    if (islast === void 0) {
      islast = true;
    }
    var belt = this.creatBelt(this);
    var _this$config5 = this.config,
      scaleBar = _this$config5.scaleBar,
      marginWidth = _this$config5.marginWidth;
    // 父节点
    var parentNode = this.parent[0];
    var parX = parentNode.x;
    var parY = parentNode.y;
    var parName = parentNode.name;
    var parWidth = parentNode.width;
    var isFistLink = !parentNode.childLink;
    var marginRight = marginWidth[this.col - 1].right;
    var isSecondDepthsNode = !parentNode.parent;
    isSecondDepthsNode ? belt.setGradientColor(parentNode) : belt.setCommonColor();
    var preChilHeight = 0;
    // 没连接过生成新的childLinkList
    if (isFistLink && isSecondDepthsNode) {
      parentNode.initLink('childLink');
    } else {
      // 连接过计算之前链接的值
      preChilHeight = this.getTotalLinkValue(parentNode.childLink);
    }
    if (isSecondDepthsNode) {
      var childLink = {
        name: this.name,
        height: this.height
      };
      parentNode.addLink('childLink', childLink);
    }
    var name = isSecondDepthsNode ? parName + "_" + this.name : "" + this.name + (islast ? '_l' : '') + " ";
    var beltHeight = this.height;
    if (islast) {
      var linkVal = this.getLinkVal(parName, this.name);
      beltHeight = linkVal * scaleBar;
    }
    var start = {
      x: isSecondDepthsNode ? parX + parWidth + marginRight : this.x - this.margin.left,
      y: isSecondDepthsNode ? parY + preChilHeight : this.y,
      value: isSecondDepthsNode ? beltHeight : this.height
    };
    var end = {
      x: this.x,
      y: this.y,
      value: isSecondDepthsNode ? beltHeight : this.height
    };
    belt.init(name, start, end);
    this.addBelt(belt);
  }

  //   连接到子节点的连接带
;
  _proto.addChildrenBelt = function addChildrenBelt() {
    var _this3 = this;
    var _this$config6 = this.config,
      scaleBar = _this$config6.scaleBar,
      marginWidth = _this$config6.marginWidth,
      space = _this$config6.space;
    this.children.forEach(function (child) {
      var belt = _this3.creatBelt(child, false);
      belt.setGradientColor(_this3);
      var linkVal = _this3.getLinkVal(_this3.name, child.name);
      var linkHeight = linkVal * scaleBar;
      var childX = child.x;
      var childY = child.y;
      var childName = child.name;
      var childMarign = marginWidth[_this3.col + 1].left;
      var isFirstLinkChild = !_this3.childLink;
      var isFistLinkPar = !child.parentLink;
      var preChildHeight = 0;
      var preParentHeight = 0;
      // 判断当前节点的子节点没有连接过父节点
      if (isFistLinkPar) {
        child.initLink('parentLink');
      } else {
        preParentHeight = _this3.getTotalLinkValue(child.parentLink);
      }
      // 判断节点有没有连接过子节点
      if (isFirstLinkChild) {
        _this3.initLink('childLink');
      } else {
        preChildHeight = _this3.getTotalLinkValue(_this3.childLink);
      }
      var name = _this3.name + "_" + childName;
      var start = {
        x: _this3.x + _this3.width,
        y: _this3.y + preChildHeight,
        value: linkHeight
      };
      var end = {
        x: childX - childMarign - space,
        y: childY + preParentHeight,
        value: linkHeight
      };
      belt.init(name, start, end);
      var childLink = {
        name: child.name,
        height: linkHeight
      };
      _this3.addLink('childLink', childLink);
      var parentLink = {
        name: name,
        height: linkHeight
      };
      child.addLink('parentLink', parentLink);
      _this3.addBelt(belt);
    });
  }
  // 生成前部的连接带
;
  _proto.setBeforeBelt = function setBeforeBelt() {
    // 根节点
    if (!this.parent && this.children) {
      this.addSelfBelt();
    }
    // 最后一层节点
    if (this.parent && !this.children) {
      this.addParentBelt();
    }
    // 中间节点
    if (this.parent && this.children) {
      this.addParentBelt(false);
    }
  }
  // 生成后部的连接带
;
  _proto.setAfterBelt = function setAfterBelt() {
    // 根节点
    if (!this.parent && this.children) {
      this.addSelfBelt(false, false);
    }
    // 最后一层节点
    if (this.parent && !this.children) {
      this.addSelfBelt(false, true);
    }

    // 中间节点
    if (this.parent && this.children) {
      this.addChildrenBelt();
    }
  }

  // 生成对应节点的连接带
;
  _proto.initBelts = function initBelts() {
    this.setBeforeBelt();
    this.setAfterBelt();
  };
  return Node;
}();
export { Node as default };
