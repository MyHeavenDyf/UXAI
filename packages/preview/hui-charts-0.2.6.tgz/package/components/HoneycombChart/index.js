function _inheritsLoose(t, o) { t.prototype = Object.create(o.prototype), t.prototype.constructor = t, _setPrototypeOf(t, o); }
function _setPrototypeOf(t, e) { return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) { return t.__proto__ = e, t; }, _setPrototypeOf(t, e); }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
import BaseChart from '../BaseChart/index.js';
import NodeManager from './NodeManager.js';
import { CHART_TYPE } from '../../util/constants.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */
var HoneycombChart = /*#__PURE__*/function (_BaseChart) {
  function HoneycombChart() {
    var _this;
    _this = _BaseChart.call(this) || this;
    // 图表渲染容器
    _this.dom = null;
    // 图表配置项
    _this.option = null;
    // 图表所需数据
    _this.data = null;
    // 图表容器的宽高变化监听器
    _this.resizeObserver = null;
    // 生成节点和计算位置
    _this.nodeManager = null;
    return _this;
  }

  // 初始化图表渲染容器
  _inheritsLoose(HoneycombChart, _BaseChart);
  var _proto = HoneycombChart.prototype;
  _proto.init = function init(dom) {
    this.dom = dom;
  }

  // 初始化图表渲染配置
;
  _proto.setSimpleOption = function setSimpleOption(chartName, option) {
    this.option = option;
  }

  // 图表渲染回调
;
  _proto.render = function render() {
    this.data = this.option.data || [];
    this.initDom();
    this.setResizeObserver();
    this.renderCallBack && this.renderCallBack(this);
  }

  // 图表渲染完成时回调
;
  _proto.onRenderReady = function onRenderReady(callback) {
    this.renderCallBack = callback;
  };
  _proto.initDom = function initDom() {
    this.dom.style.padding = this.option.padding || 0;
    this.dom.insertAdjacentHTML('beforeend', '<div class="hc-container"><div class="hc-rows"></div></div>');
    if (this.data.length > 0) {
      this.nodeManager = new NodeManager(this.dom, this.option);
    }
  };
  _proto.resizeDom = function resizeDom() {
    if (this.data.length > 0) {
      Array.prototype.slice.call(this.dom.getElementsByClassName('hc-row')).forEach(function (element) {
        element.remove();
      });
      this.nodeManager.layoutNodes();
    }
  }

  // 监听容器变化
;
  _proto.setResizeObserver = function setResizeObserver() {
    var _this2 = this;
    this.resizeObserver = new ResizeObserver(function (entries) {
      _this2.resizeDom();
    });
    this.resizeObserver.observe(this.dom);
  }

  // 图表刷新，刷新配置项
;
  _proto.refresh = function refresh(option) {
    Array.prototype.slice.call(this.dom.getElementsByClassName('hc-container')).forEach(function (element) {
      element.remove();
    });
    this.option = option;
    this.data = option.data;
    this.initDom();
    this.resizeDom();
  }

  // 图表刷新，仅刷新数据
;
  _proto.refreshData = function refreshData(data) {
    Array.prototype.slice.call(this.dom.getElementsByClassName('hc-container')).forEach(function (element) {
      element.remove();
    });
    this.data = data;
    this.option.data = data;
    this.initDom();
    this.resizeDom();
  }

  // 刷新图表自适应宽度
;
  _proto.setResize = function setResize() {
    this.resizeDom();
  }

  // 销毁图表
;
  _proto.uninstall = function uninstall() {
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
      this.resizeObserver = null;
    }
    this.dom.innerHTML = '';
  };
  return HoneycombChart;
}(BaseChart);
_defineProperty(HoneycombChart, "name", CHART_TYPE.HONEYCOMB);
export { HoneycombChart as default };
