import LineChart from './components/LineChart/index.js';
import BarChart from './components/BarChart/index.js';
import PieChart from './components/PieChart/index.js';
import RadarChart from './components/RadarChart/index.js';
import GaugeChart from './components/GaugeChart/index.js';
import BubbleChart from './components/BubbleChart/index.js';
import WordCloudChart from './components/WordCloudChart/index.js';
import SankeyChart from './components/SankeyChart/index.js';
import HeatMapChart from './components/HeatMapChart/index.js';
import ScatterChart from './components/ScatterChart/index.js';
import JadeJueChart from './components/JadeJueChart/index.js';
import TreeChart from './components/TreeChart/index.js';
import TreeMapChart from './components/TreeMapChart/index.js';
import HillChart from './components/HillChart/index.js';
import GraphTreeChart from './components/GraphTreeChart/index.js';
import ProcessChart from './components/ProcessChart/index.js';
import PolarBarChart from './components/PolarBarChart/index.js';
import CircleProcessChart from './components/CircleProcessChart/index.js';
import SunburstChart from './components/SunburstChart/index.js';
import FunnelChart from './components/FunnelChart/index.js';
import LiquidfillChart from './components/LiquidfillChart/index.js';
import BoxplotChart from './components/BoxplotChart/index.js';
import RegionChart from './components/RegionChart/index.js';
import CandlestickChart from './components/CandlestickChart/index.js';
import GraphChart from './components/GraphChart/index.js';
import AssembleBubbleChart from './components/AssembleBubbleChart/index.js';
import BulletChart from './components/BulletChart/index.js';
import BarLineChart from './components/BarLineChart/index.js';
import RankProcessChart from './components/RankProcessChart/index.js';

/**
 * Copyright (c) 2024 - present OpenTiny HUICharts Authors.
 * Copyright (c) 2024 - present Huawei Cloud Computing Technologies Co., Ltd.
 *
 * Use of this source code is governed by an MIT-style license.
 *
 * THE OPEN SOURCE SOFTWARE IN THIS PRODUCT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL,
 * BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 * A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.
 *
 */

function Register() {
  this.registeredComp = {};
}
function registerComp(options) {
  this.registeredComp[options.name] = options.component;
}
function getRegisteredComp(name) {
  if (name in this.registeredComp) {
    return this.registeredComp[name];
  }
  return null;
}
Register.prototype.registerComp = registerComp;
Register.prototype.getRegisteredComp = getRegisteredComp;
var register = new Register();
var components = [{
  name: 'AreaChart',
  component: LineChart
}, {
  name: 'LineChart',
  component: LineChart
}, {
  name: 'BarChart',
  component: BarChart
}, {
  name: 'PieChart',
  component: PieChart
}, {
  name: 'GaugeChart',
  component: GaugeChart
}, {
  name: 'BubbleChart',
  component: BubbleChart
}, {
  name: 'RadarChart',
  component: RadarChart
}, {
  name: 'WordCloudChart',
  component: WordCloudChart
}, {
  name: 'HeatMapChart',
  component: HeatMapChart
}, {
  name: 'ScatterChart',
  component: ScatterChart
}, {
  name: 'SankeyChart',
  component: SankeyChart
}, {
  name: 'JadeJueChart',
  component: JadeJueChart
}, {
  name: 'TreeChart',
  component: TreeChart
}, {
  name: 'TreeMapChart',
  component: TreeMapChart
}, {
  name: 'HillChart',
  component: HillChart
}, {
  name: 'GraphTreeChart',
  component: GraphTreeChart
}, {
  name: 'ProcessChart',
  component: ProcessChart
}, {
  name: 'PolarBarChart',
  component: PolarBarChart
}, {
  name: 'CircleProcessChart',
  component: CircleProcessChart
}, {
  name: 'SunburstChart',
  component: SunburstChart
}, {
  name: 'FunnelChart',
  component: FunnelChart
}, {
  name: 'LiquidfillChart',
  component: LiquidfillChart
}, {
  name: 'BoxplotChart',
  component: BoxplotChart
}, {
  name: 'RegionChart',
  component: RegionChart
}, {
  name: 'CandlestickChart',
  component: CandlestickChart
}, {
  name: 'GraphChart',
  component: GraphChart
}, {
  name: 'AssembleBubbleChart',
  component: AssembleBubbleChart
}, {
  name: 'BulletChart',
  component: BulletChart
}, {
  name: 'BarLineChart',
  component: BarLineChart
}, {
  name: 'RankProcessChart',
  component: RankProcessChart
}];
components.forEach(function (comp) {
  register.registerComp(comp);
});
export { register as default };
